using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace THSuite.Security
{
    /// <summary>Bloqueio de propaganda, rastreadores, vírus e golpes pelo arquivo hosts.</summary>
    public partial class BlockerView : UserControl
    {
        public const string Begin = "# >>> TH Suite: bloqueio de sites (não edite entre estas linhas)";
        public const string End = "# <<< TH Suite: fim do bloqueio";

        public class BlockerSettings
        {
            public bool Gambling { get; set; }
            public bool Porn { get; set; }
            public bool Fakenews { get; set; }
            public bool Social { get; set; }
            public List<string> Custom { get; set; } = new();
            public List<string> Allow { get; set; } = new();
        }

        static string ConfigPath => Path.Combine(SuiteSettings.DataDir, "bloqueio.json");
        static string BackupPath => Path.Combine(SuiteSettings.DataDir, "hosts-original.bak");
        BlockerSettings _b = new();
        bool _busy;

        public BlockerView()
        {
            InitializeComponent();
            try { if (File.Exists(ConfigPath)) _b = JsonSerializer.Deserialize<BlockerSettings>(File.ReadAllText(ConfigPath)) ?? new(); } catch { }
            ChkGambling.IsChecked = _b.Gambling;
            ChkPorn.IsChecked = _b.Porn;
            ChkFakenews.IsChecked = _b.Fakenews;
            ChkSocial.IsChecked = _b.Social;
            TxtCustom.Text = string.Join(Environment.NewLine, _b.Custom);
            TxtAllow.Text = string.Join(Environment.NewLine, _b.Allow);
            UpdateStatus();
        }

        static int CountBlocked()
        {
            try
            {
                bool inside = false; int n = 0;
                foreach (var l in File.ReadLines(SystemChecks.HostsPath))
                {
                    if (l.StartsWith(Begin)) { inside = true; continue; }
                    if (l.StartsWith(End)) break;
                    if (inside && l.StartsWith("0.0.0.0 ")) n++;
                }
                return n;
            }
            catch { return 0; }
        }

        void UpdateStatus()
        {
            int n = CountBlocked();
            TxtBlockStatus.Text = n > 0 ? $"Ativado: {n:N0} endereços bloqueados." : "Desativado.";
            TxtBlockStatus.SetResourceReference(TextBlock.ForegroundProperty, n > 0 ? "OkSolidBrush" : "MutedBrush");
            BtnUnblock.IsEnabled = n > 0;
        }

        static List<string> Lines(string text) => text.Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(x => x.Trim().ToLowerInvariant().Replace("https://", "").Replace("http://", "").TrimEnd('/'))
            .Where(x => x.Length > 3 && x.Contains('.') && !x.Contains(' ')).Distinct().ToList();

        void SaveConfig()
        {
            _b.Gambling = ChkGambling.IsChecked == true;
            _b.Porn = ChkPorn.IsChecked == true;
            _b.Fakenews = ChkFakenews.IsChecked == true;
            _b.Social = ChkSocial.IsChecked == true;
            _b.Custom = Lines(TxtCustom.Text);
            _b.Allow = Lines(TxtAllow.Text);
            try { Directory.CreateDirectory(SuiteSettings.DataDir); File.WriteAllText(ConfigPath, JsonSerializer.Serialize(_b)); } catch { }
        }

        string ListUrl()
        {
            var parts = new List<string>();
            if (_b.Fakenews) parts.Add("fakenews");
            if (_b.Gambling) parts.Add("gambling");
            if (_b.Porn) parts.Add("porn");
            if (_b.Social) parts.Add("social");
            return parts.Count == 0
                ? "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts"
                : $"https://raw.githubusercontent.com/StevenBlack/hosts/master/alternates/{string.Join("-", parts)}/hosts";
        }

        /// <summary>Conteúdo do hosts sem a seção do TH Suite.</summary>
        static List<string> WithoutBlock(IEnumerable<string> lines)
        {
            var keep = new List<string>();
            bool inside = false;
            foreach (var l in lines)
            {
                if (l.StartsWith(Begin)) { inside = true; continue; }
                if (l.StartsWith(End)) { inside = false; continue; }
                if (!inside) keep.Add(l);
            }
            while (keep.Count > 0 && keep[^1].Trim().Length == 0) keep.RemoveAt(keep.Count - 1);
            return keep;
        }

        async void Apply_Click(object sender, RoutedEventArgs e)
        {
            if (_busy) return;
            SaveConfig();
            _busy = true;
            BtnBlock.IsEnabled = false;
            TxtBlockStatus.Text = "Baixando a lista de bloqueio...";
            try
            {
                string list;
                using (var http = new HttpClient { Timeout = TimeSpan.FromSeconds(60) })
                    list = await http.GetStringAsync(ListUrl());

                var allow = new HashSet<string>(_b.Allow, StringComparer.OrdinalIgnoreCase);
                var domains = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (var raw in list.Split('\n'))
                {
                    string l = raw.Trim();
                    if (!l.StartsWith("0.0.0.0 ")) continue;
                    string d = l[8..].Split('#')[0].Trim();
                    if (d.Length == 0 || d == "0.0.0.0" || allow.Contains(d)) continue;
                    domains.Add(d);
                }
                foreach (var c in _b.Custom) { domains.Add(c); if (!c.StartsWith("www.")) domains.Add("www." + c); }
                if (domains.Count < 1000) throw new Exception("a lista baixada parece incompleta.");

                await Task.Run(() =>
                {
                    string hosts = SystemChecks.HostsPath;
                    Directory.CreateDirectory(SuiteSettings.DataDir);
                    if (!File.Exists(BackupPath) && File.Exists(hosts)) File.Copy(hosts, BackupPath);
                    var keep = File.Exists(hosts) ? WithoutBlock(File.ReadAllLines(hosts)) : new List<string>();
                    keep.Add("");
                    keep.Add(Begin);
                    keep.Add($"# Atualizado em {DateTime.Now:dd/MM/yyyy HH:mm}");
                    keep.AddRange(domains.OrderBy(x => x).Select(d => "0.0.0.0 " + d));
                    keep.Add(End);
                    if (File.Exists(hosts)) File.SetAttributes(hosts, FileAttributes.Normal);
                    File.WriteAllLines(hosts, keep, new UTF8Encoding(false));
                });
                await Cmd.RunAsync("ipconfig.exe", "/flushdns");
                Activity.Log("Segurança", $"Bloqueio de sites ativado: {domains.Count:N0} endereços");
                UpdateStatus();
            }
            catch (Exception ex)
            {
                TxtBlockStatus.Text = "Não foi possível ativar: " + ex.Message;
            }
            BtnBlock.IsEnabled = true;
            _busy = false;
        }

        async void Remove_Click(object sender, RoutedEventArgs e)
        {
            if (_busy || !Host.Confirm("Desativar o bloqueio de sites?")) return;
            try
            {
                await Task.Run(() =>
                {
                    string hosts = SystemChecks.HostsPath;
                    var keep = WithoutBlock(File.ReadAllLines(hosts));
                    File.SetAttributes(hosts, FileAttributes.Normal);
                    File.WriteAllLines(hosts, keep, new UTF8Encoding(false));
                });
                await Cmd.RunAsync("ipconfig.exe", "/flushdns");
                Activity.Log("Segurança", "Bloqueio de sites desativado");
            }
            catch (Exception ex) { Host.Info("Não foi possível desativar: " + ex.Message); }
            UpdateStatus();
        }

        void OpenHosts_Click(object sender, RoutedEventArgs e) => Cmd.Open("notepad.exe", $"\"{SystemChecks.HostsPath}\"");
    }
}

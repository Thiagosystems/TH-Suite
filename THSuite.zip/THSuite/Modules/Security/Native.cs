using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

namespace THSuite.Security
{
    public static class Native
    {
        const uint PROCESS_QUERY_LIMITED_INFORMATION = 0x1000;

        [DllImport("kernel32.dll", SetLastError = true)]
        static extern IntPtr OpenProcess(uint access, bool inherit, int pid);

        [DllImport("kernel32.dll")]
        static extern bool CloseHandle(IntPtr h);

        [DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
        static extern bool QueryFullProcessImageName(IntPtr h, int flags, StringBuilder sb, ref int size);

        public static string? ProcessPath(int pid)
        {
            IntPtr h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, false, pid);
            if (h == IntPtr.Zero) return null;
            try
            {
                var sb = new StringBuilder(1024);
                int n = sb.Capacity;
                return QueryFullProcessImageName(h, 0, sb, ref n) ? sb.ToString() : null;
            }
            finally { CloseHandle(h); }
        }

        // ------------------------------------------------------- conexões TCP

        [StructLayout(LayoutKind.Sequential)]
        struct MIB_TCPROW_OWNER_PID
        {
            public uint State;
            public uint LocalAddr;
            public uint LocalPort;
            public uint RemoteAddr;
            public uint RemotePort;
            public uint OwningPid;
        }

        [DllImport("iphlpapi.dll", SetLastError = true)]
        static extern uint GetExtendedTcpTable(IntPtr table, ref int size, bool order, int af, int tableClass, uint reserved);

        public record TcpConn(int Pid, string Remote, int RemotePort, bool Established);

        /// <summary>Conexões TCP (IPv4) de todos os processos.</summary>
        public static List<TcpConn> TcpConnections()
        {
            const int AF_INET = 2, TCP_TABLE_OWNER_PID_ALL = 5;
            var list = new List<TcpConn>();
            int size = 0;
            GetExtendedTcpTable(IntPtr.Zero, ref size, false, AF_INET, TCP_TABLE_OWNER_PID_ALL, 0);
            IntPtr buf = Marshal.AllocHGlobal(size + 1024);
            try
            {
                size += 1024;
                if (GetExtendedTcpTable(buf, ref size, false, AF_INET, TCP_TABLE_OWNER_PID_ALL, 0) != 0) return list;
                int count = Marshal.ReadInt32(buf);
                int rowSize = Marshal.SizeOf<MIB_TCPROW_OWNER_PID>();
                IntPtr p = buf + 4;
                for (int i = 0; i < count; i++)
                {
                    var row = Marshal.PtrToStructure<MIB_TCPROW_OWNER_PID>(p);
                    p += rowSize;
                    if (row.RemoteAddr == 0) continue;
                    int port = (int)(((row.RemotePort & 0xFF) << 8) | ((row.RemotePort >> 8) & 0xFF));
                    string ip = new System.Net.IPAddress(row.RemoteAddr).ToString();
                    list.Add(new TcpConn((int)row.OwningPid, ip, port, row.State == 5));
                }
            }
            finally { Marshal.FreeHGlobal(buf); }
            return list;
        }

        // ------------------------------------------------------- ociosidade

        [StructLayout(LayoutKind.Sequential)]
        struct LASTINPUTINFO { public uint cbSize; public uint dwTime; }

        [DllImport("user32.dll")]
        static extern bool GetLastInputInfo(ref LASTINPUTINFO info);

        /// <summary>Há quantos segundos o usuário não mexe no mouse/teclado.</summary>
        public static double IdleSeconds()
        {
            var info = new LASTINPUTINFO { cbSize = (uint)Marshal.SizeOf<LASTINPUTINFO>() };
            if (!GetLastInputInfo(ref info)) return 0;
            return (unchecked((uint)Environment.TickCount) - info.dwTime) / 1000.0;
        }

        // ------------------------------------------------------- janelas

        public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

        [DllImport("user32.dll")]
        static extern bool EnumWindows(EnumWindowsProc cb, IntPtr lParam);

        [DllImport("user32.dll")]
        static extern bool IsWindowVisible(IntPtr hWnd);

        [DllImport("user32.dll")]
        static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint pid);

        public static HashSet<int> WindowPids()
        {
            var set = new HashSet<int>();
            EnumWindows((h, _) =>
            {
                if (IsWindowVisible(h)) { GetWindowThreadProcessId(h, out uint pid); set.Add((int)pid); }
                return true;
            }, IntPtr.Zero);
            return set;
        }
    }
}

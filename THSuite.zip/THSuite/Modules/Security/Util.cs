using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Runtime.CompilerServices;
using System.Security;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace THSuite.Security
{
    public abstract class Observable : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;

        protected bool Set<T>(ref T field, T value, [CallerMemberName] string? name = null)
        {
            if (EqualityComparer<T>.Default.Equals(field, value)) return false;
            field = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
            return true;
        }

        protected void Raise(string name) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }

    public static class Fmt
    {
        public static string Bytes(double bytes)
        {
            string[] u = { "B", "KB", "MB", "GB", "TB" };
            int i = 0;
            while (bytes >= 1024 && i < u.Length - 1) { bytes /= 1024; i++; }
            return i == 0 ? $"{bytes:0} B" : $"{bytes:0.#} {u[i]}";
        }

        public static string Speed(double bytesPerSec)
        {
            double bits = bytesPerSec * 8;
            if (bits >= 1_000_000) return $"{bits / 1_000_000:0.0} Mbps";
            if (bits >= 1_000) return $"{bits / 1_000:0} Kbps";
            return $"{bits:0} bps";
        }
    }

    internal static class Shell
    {
        public static async Task<(int Code, string Output)> RunAsync(string exe, string args, int timeoutMs = 60000)
        {
            var psi = new ProcessStartInfo(exe, args)
            {
                CreateNoWindow = true,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                StandardOutputEncoding = Encoding.UTF8,
                StandardErrorEncoding = Encoding.UTF8
            };
            using var p = Process.Start(psi)!;
            var outTask = p.StandardOutput.ReadToEndAsync();
            var errTask = p.StandardError.ReadToEndAsync();
            var exit = p.WaitForExitAsync();
            if (await Task.WhenAny(exit, Task.Delay(timeoutMs)) != exit)
            {
                try { p.Kill(true); } catch { }
                return (-1, "timeout");
            }
            return (p.ExitCode, await outTask + await errTask);
        }

        public static Task<(int Code, string Output)> PowerShellAsync(string script, int timeoutMs = 60000)
        {
            string full = "[Console]::OutputEncoding=[Text.Encoding]::UTF8; " + script;
            string encoded = Convert.ToBase64String(Encoding.Unicode.GetBytes(full));
            return RunAsync("powershell.exe", "-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand " + encoded, timeoutMs);
        }

        public static void Open(string target)
        {
            try { Process.Start(new ProcessStartInfo(target) { UseShellExecute = true }); } catch { }
        }

        public static void Open(string exe, string args)
        {
            try { Process.Start(new ProcessStartInfo(exe, args) { UseShellExecute = true }); } catch { }
        }
    }

    /// <summary>Iniciar com o Windows via Agendador de Tarefas (com privilégio de administrador).</summary>
    internal static class StartupManager
    {
        const string TaskName = "TH Guard";

        public static async Task SetAsync(bool enabled)
        {
            try
            {
                if (!enabled)
                {
                    await Shell.RunAsync("schtasks.exe", $"/Delete /F /TN \"{TaskName}\"");
                    return;
                }
                string exe = SecurityElement.Escape(Environment.ProcessPath!)!;
                string user = SecurityElement.Escape(WindowsIdentity.GetCurrent().Name)!;
                string xml = $@"<?xml version=""1.0"" encoding=""UTF-16""?>
<Task version=""1.2"" xmlns=""http://schemas.microsoft.com/windows/2004/02/mit/task"">
  <Triggers><LogonTrigger><Enabled>true</Enabled><UserId>{user}</UserId></LogonTrigger></Triggers>
  <Principals><Principal id=""Author""><UserId>{user}</UserId><LogonType>InteractiveToken</LogonType><RunLevel>HighestAvailable</RunLevel></Principal></Principals>
  <Settings>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
  </Settings>
  <Actions Context=""Author""><Exec><Command>{exe}</Command><Arguments>--tray</Arguments></Exec></Actions>
</Task>";
                string tmp = Path.Combine(Path.GetTempPath(), "thguard_task.xml");
                File.WriteAllText(tmp, xml, Encoding.Unicode);
                await Shell.RunAsync("schtasks.exe", $"/Create /F /TN \"{TaskName}\" /XML \"{tmp}\"");
                File.Delete(tmp);
            }
            catch { }
        }
    }
}

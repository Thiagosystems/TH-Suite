using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Management;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace THSuite.Security
{
    /// <summary>Tudo que inicia sozinho com o Windows (estilo Autoruns).</summary>
    public static class StartupScanner
    {
        static readonly string Win = Environment.GetFolderPath(Environment.SpecialFolder.Windows);

        public static async Task<List<StartupEntry>> LoadAsync(bool verifySignatures)
        {
            var list = new List<StartupEntry>();
            await Task.Run(() =>
            {
                ReadRunKeys(list);
                ReadStartupFolders(list);
                ReadServices(list);
                ReadWinlogon(list);
                ReadIfeo(list);
                ReadAppInit(list);
                ReadWmi(list);
            });
            list.AddRange(await ReadTasksAsync());

            if (verifySignatures)
                await Signatures.VerifyAsync(list.Select(e => e.FilePath).Where(File.Exists));

            foreach (var e in list) Evaluate(e);
            return list.OrderByDescending(e => e.Risk).ThenBy(e => e.Source).ThenBy(e => e.Name).ToList();
        }

        // ----------------------------------------------------------- registro

        static void ReadRunKeys(List<StartupEntry> list)
        {
            var keys = new (RegistryHive Hive, RegistryView View, string Path, string Label)[]
            {
                (RegistryHive.CurrentUser, RegistryView.Default, @"Software\Microsoft\Windows\CurrentVersion\Run", "HKCU Run"),
                (RegistryHive.CurrentUser, RegistryView.Default, @"Software\Microsoft\Windows\CurrentVersion\RunOnce", "HKCU RunOnce"),
                (RegistryHive.CurrentUser, RegistryView.Default, @"Software\Microsoft\Windows\CurrentVersion\Policies\Explorer\Run", "HKCU Policies Run"),
                (RegistryHive.LocalMachine, RegistryView.Registry64, @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", "HKLM Run"),
                (RegistryHive.LocalMachine, RegistryView.Registry64, @"SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce", "HKLM RunOnce"),
                (RegistryHive.LocalMachine, RegistryView.Registry64, @"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer\Run", "HKLM Policies Run"),
                (RegistryHive.LocalMachine, RegistryView.Registry32, @"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", "HKLM Run (32 bits)"),
                (RegistryHive.LocalMachine, RegistryView.Registry32, @"SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce", "HKLM RunOnce (32 bits)"),
            };

            foreach (var (hive, view, path, label) in keys)
            {
                try
                {
                    using var b = RegistryKey.OpenBaseKey(hive, view);
                    using var k = b.OpenSubKey(path);
                    if (k == null) continue;
                    string hiveName = hive == RegistryHive.CurrentUser ? "HKCU" : "HKLM";
                    string realPath = view == RegistryView.Registry32 ? path.Replace(@"SOFTWARE\", @"SOFTWARE\WOW6432Node\") : path;
                    foreach (var name in k.GetValueNames())
                    {
                        string cmd = k.GetValue(name)?.ToString() ?? "";
                        if (cmd.Length == 0) continue;
                        list.Add(new StartupEntry
                        {
                            Source = "Registro",
                            Name = name.Length > 0 ? name : "(padrão)",
                            Command = cmd,
                            FilePath = Rules.ExtractPath(cmd),
                            Location = $@"{hiveName}\{realPath}",
                            RegHive = hiveName,
                            RegKey = realPath,
                            RegValue = name,
                            Enabled = !DisabledByTaskManager(hive, name, view == RegistryView.Registry32 ? "Run32" : "Run")
                        });
                    }
                }
                catch { }
            }
        }

        /// <summary>O Gerenciador de Tarefas desativa itens em StartupApproved (byte ímpar = desativado).</summary>
        static bool DisabledByTaskManager(RegistryHive hive, string name, string sub)
        {
            try
            {
                using var b = RegistryKey.OpenBaseKey(hive, RegistryView.Registry64);
                using var k = b.OpenSubKey($@"Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\{sub}");
                return k?.GetValue(name) is byte[] data && data.Length > 0 && (data[0] & 1) == 1;
            }
            catch { return false; }
        }

        static void ReadStartupFolders(List<StartupEntry> list)
        {
            foreach (var dir in new[] { Environment.GetFolderPath(Environment.SpecialFolder.Startup),
                                        Environment.GetFolderPath(Environment.SpecialFolder.CommonStartup) })
            {
                if (!Directory.Exists(dir)) continue;
                foreach (var f in Directory.GetFiles(dir))
                {
                    if (Path.GetFileName(f).Equals("desktop.ini", StringComparison.OrdinalIgnoreCase)) continue;
                    var (target, args) = ResolveShortcut(f);
                    list.Add(new StartupEntry
                    {
                        Source = "Pasta Inicializar",
                        Name = Path.GetFileNameWithoutExtension(f),
                        Command = target.Length > 0 ? $"\"{target}\" {args}".Trim() : f,
                        FilePath = target.Length > 0 ? target : f,
                        Location = f
                    });
                }
            }
        }

        public static (string Target, string Args) ResolveShortcut(string path)
        {
            if (!path.EndsWith(".lnk", StringComparison.OrdinalIgnoreCase)) return (path, "");
            try
            {
                var type = Type.GetTypeFromProgID("WScript.Shell");
                if (type == null) return ("", "");
                dynamic shell = Activator.CreateInstance(type)!;
                dynamic lnk = shell.CreateShortcut(path);
                return ((string)lnk.TargetPath, (string)lnk.Arguments);
            }
            catch { return ("", ""); }
        }

        static void ReadServices(List<StartupEntry> list)
        {
            try
            {
                using var root = Registry.LocalMachine.OpenSubKey(@"SYSTEM\CurrentControlSet\Services");
                if (root == null) return;
                foreach (var name in root.GetSubKeyNames())
                {
                    try
                    {
                        using var k = root.OpenSubKey(name);
                        if (k == null) continue;
                        int type = k.GetValue("Type") is int t ? t : 0;
                        int start = k.GetValue("Start") is int st ? st : 3;
                        if ((type & 0x30) == 0 || start != 2) continue; // só serviços (não drivers) com início automático
                        string image = k.GetValue("ImagePath")?.ToString() ?? "";
                        string path = Rules.ExtractPath(image);

                        // svchost: o código real fica na ServiceDll
                        if (Path.GetFileName(path).Equals("svchost.exe", StringComparison.OrdinalIgnoreCase))
                        {
                            using var par = k.OpenSubKey("Parameters");
                            string dll = Environment.ExpandEnvironmentVariables(par?.GetValue("ServiceDll")?.ToString() ?? "");
                            if (dll.Length == 0 || Rules.InWindows(dll)) continue;
                            path = dll;
                        }
                        else if (Rules.InWindows(path)) continue;

                        list.Add(new StartupEntry
                        {
                            Source = "Serviço",
                            Name = k.GetValue("DisplayName")?.ToString() is string dn && !dn.StartsWith("@") ? dn : name,
                            Command = image,
                            FilePath = path,
                            Location = $@"HKLM\SYSTEM\CurrentControlSet\Services\{name}",
                            ServiceName = name
                        });
                    }
                    catch { }
                }
            }
            catch { }
        }

        static void ReadWinlogon(List<StartupEntry> list)
        {
            try
            {
                using var k = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon");
                string shell = k?.GetValue("Shell")?.ToString() ?? "explorer.exe";
                string userinit = k?.GetValue("Userinit")?.ToString() ?? "";
                if (!shell.Trim().Equals("explorer.exe", StringComparison.OrdinalIgnoreCase))
                    list.Add(new StartupEntry
                    {
                        Source = "Winlogon", Name = "Shell (deveria ser explorer.exe)", Command = shell,
                        FilePath = Rules.ExtractPath(shell), Location = @"HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon"
                    });
                string expected = Path.Combine(Win, "system32", "userinit.exe");
                var parts = userinit.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
                if (parts.Any(p => !p.Equals(expected, StringComparison.OrdinalIgnoreCase) && !p.Equals("userinit.exe", StringComparison.OrdinalIgnoreCase)))
                    list.Add(new StartupEntry
                    {
                        Source = "Winlogon", Name = "Userinit (deveria ser só userinit.exe)", Command = userinit,
                        FilePath = Rules.ExtractPath(parts.Last()), Location = @"HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon"
                    });
            }
            catch { }
        }

        static void ReadIfeo(List<StartupEntry> list)
        {
            try
            {
                const string path = @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Image File Execution Options";
                using var root = Registry.LocalMachine.OpenSubKey(path);
                if (root == null) return;
                foreach (var exe in root.GetSubKeyNames())
                {
                    using var k = root.OpenSubKey(exe);
                    string dbg = k?.GetValue("Debugger")?.ToString() ?? "";
                    if (dbg.Length == 0) continue;
                    list.Add(new StartupEntry
                    {
                        Source = "Sequestro de programa",
                        Name = $"{exe} abre outro programa no lugar",
                        Command = dbg,
                        FilePath = Rules.ExtractPath(dbg),
                        Location = $@"HKLM\{path}\{exe}",
                        RegHive = "HKLM",
                        RegKey = $@"{path}\{exe}",
                        RegValue = "Debugger"
                    });
                }
            }
            catch { }
        }

        static void ReadAppInit(List<StartupEntry> list)
        {
            try
            {
                const string path = @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Windows";
                using var k = Registry.LocalMachine.OpenSubKey(path);
                string dlls = k?.GetValue("AppInit_DLLs")?.ToString() ?? "";
                bool load = k?.GetValue("LoadAppInit_DLLs") is int v && v == 1;
                if (dlls.Trim().Length > 0 && load)
                    list.Add(new StartupEntry
                    {
                        Source = "AppInit_DLLs", Name = "DLL carregada em todos os programas", Command = dlls,
                        FilePath = Rules.ExtractPath(dlls.Split(',', ' ')[0]), Location = $@"HKLM\{path}",
                        RegHive = "HKLM", RegKey = path, RegValue = "AppInit_DLLs"
                    });
            }
            catch { }
        }

        static void ReadWmi(List<StartupEntry> list)
        {
            try
            {
                var scope = new ManagementScope(@"\\.\root\subscription");
                using var searcher = new ManagementObjectSearcher(scope, new ObjectQuery("SELECT * FROM __EventConsumer"));
                foreach (ManagementObject mo in searcher.Get())
                {
                    using (mo)
                    {
                        string name = mo["Name"]?.ToString() ?? "";
                        if (name == "SCM Event Log Consumer") continue;
                        string cls = mo.ClassPath.ClassName;
                        string cmd = cls switch
                        {
                            "CommandLineEventConsumer" => mo["CommandLineTemplate"]?.ToString() ?? "",
                            "ActiveScriptEventConsumer" => "Script: " + (mo["ScriptText"]?.ToString() ?? mo["ScriptFileName"]?.ToString() ?? ""),
                            _ => cls
                        };
                        list.Add(new StartupEntry
                        {
                            Source = "WMI",
                            Name = name,
                            Command = cmd.Length > 400 ? cmd[..400] + "..." : cmd,
                            FilePath = cls == "CommandLineEventConsumer" ? Rules.ExtractPath(cmd) : "",
                            Location = $@"root\subscription · {cls}"
                        });
                    }
                }
            }
            catch { }
        }

        static async Task<List<StartupEntry>> ReadTasksAsync()
        {
            var list = new List<StartupEntry>();
            var (_, output) = await Shell.PowerShellAsync(
                "Get-ScheduledTask | ForEach-Object { [pscustomobject]@{ N = $_.TaskName; P = $_.TaskPath; S = [string]$_.State; " +
                "H = [bool]$_.Settings.Hidden; A = (($_.Actions | Where-Object { $_.Execute } | ForEach-Object { ('\"' + $_.Execute + '\" ' + $_.Arguments).Trim() }) -join ' | ') } } | " +
                "ConvertTo-Json -Compress", 120000);

            int start = output.IndexOfAny(new[] { '[', '{' });
            if (start < 0) return list;
            try
            {
                using var doc = JsonDocument.Parse(output[start..]);
                var items = doc.RootElement.ValueKind == JsonValueKind.Array
                    ? doc.RootElement.EnumerateArray().ToList()
                    : new List<JsonElement> { doc.RootElement };
                foreach (var e in items)
                {
                    string name = e.GetProperty("N").GetString() ?? "";
                    string tpath = e.GetProperty("P").GetString() ?? "\\";
                    string state = e.GetProperty("S").GetString() ?? "";
                    bool hidden = e.TryGetProperty("H", out var h) && h.ValueKind == JsonValueKind.True;
                    string action = e.TryGetProperty("A", out var a) ? a.GetString() ?? "" : "";
                    if (action.Length == 0) continue;
                    string file = Rules.ExtractPath(action.Split(" | ")[0]);

                    // Tarefas da Microsoft só entram se algo parecer errado (malware se esconde ali)
                    bool msPath = tpath.StartsWith(@"\Microsoft\", StringComparison.OrdinalIgnoreCase);
                    if (msPath && (Rules.InWindows(file) || Rules.InProgramFiles(file)) && Rules.SuspiciousScript(action) == null
                        && Rules.MinerCommand(action) == null)
                        continue;

                    list.Add(new StartupEntry
                    {
                        Source = hidden ? "Tarefa agendada (oculta)" : "Tarefa agendada",
                        Name = name,
                        Command = action,
                        FilePath = file,
                        Location = tpath + name,
                        TaskName = tpath + name,
                        Enabled = !state.Equals("Disabled", StringComparison.OrdinalIgnoreCase)
                    });
                }
            }
            catch { }
            return list;
        }

        // ------------------------------------------------------------ avaliação

        public static void Evaluate(StartupEntry e)
        {
            var reasons = new List<string>();
            var risk = Severity.Info;
            void Hit(Severity sv, string why) { reasons.Add(why); if (sv > risk) risk = sv; }

            var sig = e.FilePath.Length > 0 ? Signatures.Cached(e.FilePath) : null;
            if (sig != null) e.Signer = sig.Text;
            bool signed = sig?.Valid == true;

            switch (e.Source)
            {
                case "WMI": Hit(Severity.High, "assinatura de evento WMI: técnica usada por mineradores e malware sem arquivo"); break;
                case "Winlogon": Hit(Severity.High, "o login do Windows foi alterado para abrir outro programa"); break;
                case "Sequestro de programa": Hit(Severity.High, "abrir esse programa executa outro no lugar (técnica para bloquear antivírus)"); break;
                case "AppInit_DLLs": Hit(Severity.Medium, "uma DLL é injetada em todos os programas"); break;
            }

            if (Rules.MinerCommand(e.Command) is string m) Hit(Severity.High, m);
            if (Rules.IsMinerName(e.FilePath)) Hit(Severity.High, "programa minerador conhecido");
            if (Rules.SuspiciousScript(e.Command) is string sc) Hit(Severity.High, sc);
            if (e.FilePath.Length > 0 && Rules.Masquerade(Path.GetFileName(e.FilePath), e.FilePath) is string mq) Hit(Severity.High, mq);
            if (Rules.DoubleExtension(e.FilePath)) Hit(Severity.High, "arquivo com extensão dupla");
            if (sig?.Status == "HashMismatch") Hit(Severity.High, "assinatura digital adulterada");

            if (e.FilePath.Length > 0 && !e.FileMissing)
            {
                if (Rules.InTemp(e.FilePath)) Hit(Severity.High, "inicia a partir da pasta temporária");
                else if (Rules.SuspiciousFolder(e.FilePath) is string f && !signed) Hit(Severity.Medium, $"inicia da {f} sem assinatura");
                else if (!signed && sig != null && Rules.UserWritable(e.FilePath)) Hit(Severity.Low, "sem assinatura digital, em pasta do usuário");
            }
            if (e.FileMissing) Hit(Severity.Low, "o arquivo não existe mais (entrada quebrada)");
            if (e.Source.Contains("oculta") && risk >= Severity.Low) Hit(Severity.Medium, "tarefa marcada como oculta");

            e.Risk = risk;
            e.Reasons = ProcessScanner.Capitalize(string.Join("; ", reasons));
            e.Status = e.Enabled ? "" : "Desativado";
        }

        /// <summary>Alertas de inicialização para a verificação inteligente.</summary>
        public static List<Finding> ToFindings(IEnumerable<StartupEntry> entries) =>
            entries.Where(e => e.Risk >= Severity.Low && e.Enabled).Select(e => new Finding
            {
                Severity = e.Risk,
                Category = "Inicialização",
                Title = $"{e.Source}: {e.Name}",
                Detail = $"{e.Reasons}.\n{e.Command}",
                Path = e.FilePath,
                Key = "start:" + e.Location.ToLowerInvariant() + "|" + e.Name.ToLowerInvariant(),
                Fix = e.Source == "WMI" ? FixKind.RemoveWmi : e.CanDisable ? FixKind.DisableStartup : FixKind.None,
                FixLabel = e.Source == "WMI" ? "Remover" : "Desativar (reversível)",
                Tag = e
            }).ToList();
    }
}

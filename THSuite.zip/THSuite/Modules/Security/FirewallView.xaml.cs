using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;

namespace THSuite.Security
{
    /// <summary>Bloqueio de internet por programa (regras do Firewall do Windows).</summary>
    public partial class FirewallView : UserControl
    {
        const string Prefix = "TH Suite - Bloqueio - ";
        bool _loaded, _busy;

        public FirewallView()
        {
            InitializeComponent();
            IsVisibleChanged += async (_, _) => { if (IsVisible && !_loaded) await RefreshAsync(); };
        }

        async void Refresh_Click(object sender, RoutedEventArgs e) => await RefreshAsync();

        record Blocked(string Name, string Program);

        static async Task<List<Blocked>> BlockedAsync()
        {
            string script = $@"
$l = @(Get-NetFirewallRule -DisplayName '{Prefix}*' -ErrorAction SilentlyContinue | Where-Object Direction -eq 'Outbound' | ForEach-Object {{
  [pscustomobject]@{{ Name = $_.DisplayName; Program = ($_ | Get-NetFirewallApplicationFilter).Program }}
}})
ConvertTo-Json -InputObject $l -Compress";
            var (_, o) = await Cmd.PowerShellAsync(script, null, 60000);
            var list = new List<Blocked>();
            int s = o.IndexOf('['), e = o.LastIndexOf(']');
            if (s < 0 || e <= s) return list;
            try
            {
                using var doc = JsonDocument.Parse(o[s..(e + 1)]);
                foreach (var d in doc.RootElement.EnumerateArray())
                    list.Add(new Blocked(d.GetProperty("Name").GetString() ?? "", d.TryGetProperty("Program", out var p) ? p.GetString() ?? "" : ""));
            }
            catch { }
            return list;
        }

        async Task RefreshAsync()
        {
            _loaded = true;
            TxtFwStatus.Text = "Carregando...";
            var blocked = await BlockedAsync();
            var blockedPaths = new HashSet<string>(blocked.Select(b => b.Program), StringComparer.OrdinalIgnoreCase);

            // Programas com conexões abertas
            var active = await Task.Run(() =>
            {
                var res = new List<(string Name, string Path, int Count)>();
                try
                {
                    foreach (var g in Native.TcpConnections().Where(c => c.Pid > 4).GroupBy(c => c.Pid))
                    {
                        string? path = Native.ProcessPath(g.Key);
                        if (string.IsNullOrEmpty(path)) continue;
                        res.Add((Path.GetFileNameWithoutExtension(path), path, g.Count()));
                    }
                }
                catch { }
                return res.GroupBy(r => r.Path, StringComparer.OrdinalIgnoreCase)
                          .Select(g => (g.First().Name, g.Key, g.Sum(x => x.Count)))
                          .OrderByDescending(x => x.Item3).ToList();
            });

            ActiveList.Children.Clear();
            foreach (var (name, path, count) in active)
            {
                bool isBlocked = blockedPaths.Contains(path);
                bool system = path.StartsWith(Environment.GetFolderPath(Environment.SpecialFolder.Windows), StringComparison.OrdinalIgnoreCase);
                ActiveList.Children.Add(Row(name, $"{count} conexão(ões) · {path}", isBlocked ? null : system ? null : "Bloquear",
                    () => _ = BlockAsync(path)));
            }
            if (active.Count == 0) ActiveList.Children.Add(Note("Nenhum programa conectado agora."));

            BlockedList.Children.Clear();
            foreach (var b in blocked)
                BlockedList.Children.Add(Row(b.Name.Replace(Prefix, ""), b.Program, "Liberar", () => _ = UnblockAsync(b.Name)));
            if (blocked.Count == 0) BlockedList.Children.Add(Note("Nenhum programa bloqueado."));
            TxtFwStatus.Text = $"{blocked.Count} programa(s) bloqueado(s) · {active.Count} usando a internet agora. Programas do Windows não podem ser bloqueados por aqui.";
        }

        UIElement Row(string title, string sub, string? button, Action onClick)
        {
            var g = new Grid { Margin = new Thickness(0, 0, 0, 8) };
            g.ColumnDefinitions.Add(new ColumnDefinition());
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var sp = new StackPanel();
            var t = new TextBlock { Text = title, FontSize = 12.5, FontWeight = FontWeights.SemiBold, TextTrimming = TextTrimming.CharacterEllipsis };
            t.SetResourceReference(TextBlock.ForegroundProperty, "TextBrush");
            var s = new TextBlock { Text = sub, FontSize = 11, TextTrimming = TextTrimming.CharacterEllipsis, ToolTip = sub };
            s.SetResourceReference(TextBlock.ForegroundProperty, "MutedBrush");
            sp.Children.Add(t);
            sp.Children.Add(s);
            g.Children.Add(sp);
            if (button != null)
            {
                var b = new Button { Style = (Style)FindResource(button == "Bloquear" ? "DangerButton" : "SecondaryButton"), Content = button, Height = 28, Padding = new Thickness(12, 0, 12, 0), Margin = new Thickness(8, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center };
                b.Click += (_, _) => onClick();
                Grid.SetColumn(b, 1);
                g.Children.Add(b);
            }
            return g;
        }

        TextBlock Note(string text)
        {
            var t = new TextBlock { Text = text, FontSize = 12 };
            t.SetResourceReference(TextBlock.ForegroundProperty, "MutedBrush");
            return t;
        }

        void Pick_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog { Title = "Programa que não deve acessar a internet", Filter = "Programas (*.exe)|*.exe" };
            if (dlg.ShowDialog(Host.Owner) == true) _ = BlockAsync(dlg.FileName);
        }

        async Task BlockAsync(string path)
        {
            if (_busy) return;
            string name = Path.GetFileNameWithoutExtension(path);
            if (!Host.Confirm($"Bloquear a internet de \"{name}\"?\n\n{path}\n\nO programa vai funcionar só offline até você liberar.")) return;
            _busy = true;
            string rule = (Prefix + name).Replace("'", "");
            string p = path.Replace("'", "''");
            var (code, o) = await Cmd.PowerShellAsync(
                $"Remove-NetFirewallRule -DisplayName '{rule}' -ErrorAction SilentlyContinue; " +
                $"New-NetFirewallRule -DisplayName '{rule}' -Direction Outbound -Program '{p}' -Action Block -Profile Any | Out-Null; " +
                $"New-NetFirewallRule -DisplayName '{rule}' -Direction Inbound -Program '{p}' -Action Block -Profile Any | Out-Null; 'OK'", null, 60000);
            _busy = false;
            if (o.Contains("OK")) Activity.Log("Segurança", $"Internet bloqueada para {name}");
            else Host.Info("Não foi possível criar a regra. O Firewall do Windows está ligado?\n\n" + o.Trim());
            await RefreshAsync();
        }

        async Task UnblockAsync(string rule)
        {
            if (_busy) return;
            _busy = true;
            await Cmd.PowerShellAsync($"Remove-NetFirewallRule -DisplayName '{rule.Replace("'", "")}' -ErrorAction SilentlyContinue", null, 60000);
            _busy = false;
            Activity.Log("Segurança", $"Internet liberada para {rule.Replace(Prefix, "")}");
            await RefreshAsync();
        }
    }
}

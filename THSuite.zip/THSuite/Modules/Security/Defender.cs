using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace THSuite.Security
{
    /// <summary>Controla o Microsoft Defender pelo MpCmdRun.exe.</summary>
    public static class Defender
    {
        public static string? MpCmdRun()
        {
            try
            {
                string platform = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), @"Microsoft\Windows Defender\Platform");
                if (Directory.Exists(platform))
                {
                    var latest = Directory.GetDirectories(platform)
                        .Select(d => Path.Combine(d, "MpCmdRun.exe"))
                        .Where(File.Exists)
                        .OrderByDescending(p => p)
                        .FirstOrDefault();
                    if (latest != null) return latest;
                }
            }
            catch { }
            string pf = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), @"Windows Defender\MpCmdRun.exe");
            return File.Exists(pf) ? pf : null;
        }

        /// <summary>Executa o MpCmdRun e transmite a saída linha a linha.</summary>
        static async Task<(int Code, string Output)> RunAsync(string args, IProgress<string>? log, CancellationToken ct)
        {
            string? exe = MpCmdRun();
            if (exe == null) return (-1, "Microsoft Defender não encontrado.");

            var psi = new ProcessStartInfo(exe, args)
            {
                CreateNoWindow = true,
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                StandardOutputEncoding = Encoding.UTF8
            };
            var sb = new StringBuilder();
            using var p = new Process { StartInfo = psi, EnableRaisingEvents = true };
            p.OutputDataReceived += (_, e) =>
            {
                if (string.IsNullOrWhiteSpace(e.Data)) return;
                sb.AppendLine(e.Data);
                log?.Report(e.Data.Trim());
            };
            p.ErrorDataReceived += (_, e) => { if (!string.IsNullOrWhiteSpace(e.Data)) sb.AppendLine(e.Data); };
            p.Start();
            p.BeginOutputReadLine();
            p.BeginErrorReadLine();

            using (ct.Register(() =>
            {
                try { Process.Start(new ProcessStartInfo(exe, "-Scan -Cancel") { CreateNoWindow = true, UseShellExecute = false }); } catch { }
                try { if (!p.HasExited) p.Kill(true); } catch { }
            }))
            {
                await p.WaitForExitAsync();
            }
            return (p.ExitCode, sb.ToString());
        }

        public static Task<(int Code, string Output)> QuickScanAsync(IProgress<string>? log, CancellationToken ct) =>
            RunAsync("-Scan -ScanType 1", log, ct);

        public static Task<(int Code, string Output)> FullScanAsync(IProgress<string>? log, CancellationToken ct) =>
            RunAsync("-Scan -ScanType 2", log, ct);

        public static Task<(int Code, string Output)> CustomScanAsync(string path, IProgress<string>? log, CancellationToken ct) =>
            RunAsync($"-Scan -ScanType 3 -File \"{path.TrimEnd('\\')}\"", log, ct);

        public static Task<(int Code, string Output)> UpdateAsync(IProgress<string>? log) =>
            RunAsync("-SignatureUpdate", log, CancellationToken.None);

        /// <summary>Converte a saída do MpCmdRun em alertas.</summary>
        public static List<Finding> ParseThreats(string output)
        {
            var list = new List<Finding>();
            string? threat = null;
            foreach (var raw in output.Split('\n'))
            {
                string line = raw.Trim();
                var t = Regex.Match(line, @"^Threat\s*:\s*(.+)$", RegexOptions.IgnoreCase);
                if (t.Success) { threat = t.Groups[1].Value.Trim(); continue; }
                var r = Regex.Match(line, @"^(?:Resources|file|Resource)\s*:\s*(?:\d+\s+total\s*)?(?:file\s*:\s*)?(.+)$", RegexOptions.IgnoreCase);
                if (threat != null && r.Success && r.Groups[1].Value.Contains('\\'))
                {
                    string path = r.Groups[1].Value.Trim();
                    list.Add(new Finding
                    {
                        Severity = Severity.High,
                        Category = "Defender",
                        Title = threat,
                        Detail = "Detectado pelo Microsoft Defender. Ele normalmente já remove ou coloca em quarentena sozinho; confira em Histórico do Defender.",
                        Path = path,
                        Key = "def:" + threat + "|" + path.ToLowerInvariant()
                    });
                }
            }
            if (list.Count == 0 && Regex.IsMatch(output, @"found\s+\d+\s+threats?|threats?\s+identified", RegexOptions.IgnoreCase)
                && !Regex.IsMatch(output, @"found no threats", RegexOptions.IgnoreCase))
            {
                list.Add(new Finding
                {
                    Severity = Severity.High,
                    Category = "Defender",
                    Title = "O Microsoft Defender encontrou ameaças",
                    Detail = "Veja os detalhes em Histórico do Defender.",
                    Key = "def:generic:" + DateTime.Now.Ticks
                });
            }
            return list;
        }
    }

    /// <summary>Consulta opcional ao VirusTotal pelo hash (chave gratuita do usuário).</summary>
    public static class VirusTotal
    {
        static readonly HttpClient Http = new() { Timeout = TimeSpan.FromSeconds(20) };
        static DateTime _last = DateTime.MinValue;

        public record Result(bool Found, int Malicious, int Suspicious, int Total, string Error);

        public static string Link(string sha256) => $"https://www.virustotal.com/gui/file/{sha256}";

        public static async Task<Result> LookupAsync(string sha256, string apiKey)
        {
            if (string.IsNullOrWhiteSpace(apiKey)) return new Result(false, 0, 0, 0, "sem chave");
            // Chave gratuita: 4 consultas por minuto
            var wait = TimeSpan.FromSeconds(15) - (DateTime.Now - _last);
            if (wait > TimeSpan.Zero) await Task.Delay(wait);
            _last = DateTime.Now;

            try
            {
                using var req = new HttpRequestMessage(HttpMethod.Get, $"https://www.virustotal.com/api/v3/files/{sha256}");
                req.Headers.Add("x-apikey", apiKey.Trim());
                using var res = await Http.SendAsync(req);
                if (res.StatusCode == System.Net.HttpStatusCode.NotFound) return new Result(false, 0, 0, 0, "");
                if (!res.IsSuccessStatusCode) return new Result(false, 0, 0, 0, $"erro {(int)res.StatusCode}");
                using var doc = JsonDocument.Parse(await res.Content.ReadAsStringAsync());
                var stats = doc.RootElement.GetProperty("data").GetProperty("attributes").GetProperty("last_analysis_stats");
                int mal = stats.GetProperty("malicious").GetInt32();
                int sus = stats.GetProperty("suspicious").GetInt32();
                int total = stats.EnumerateObject().Sum(p => p.Value.ValueKind == JsonValueKind.Number ? p.Value.GetInt32() : 0);
                return new Result(true, mal, sus, total, "");
            }
            catch (Exception ex) { return new Result(false, 0, 0, 0, ex.Message); }
        }
    }

    /// <summary>Verificação de uma pasta ou arquivo escolhido.</summary>
    public static class FileScanner
    {
        static readonly string[] Exts = { ".exe", ".dll", ".scr", ".com", ".pif", ".bat", ".cmd", ".ps1", ".vbs", ".vbe", ".js", ".jse", ".wsf", ".hta", ".lnk", ".msi", ".jar", ".sys" };
        static readonly string[] Scripts = { ".bat", ".cmd", ".ps1", ".vbs", ".vbe", ".js", ".jse", ".wsf", ".hta" };

        public static async Task<List<Finding>> ScanAsync(string target, Settings s, IProgress<string> log, CancellationToken ct)
        {
            var findings = new List<Finding>();
            var files = new List<string>();

            if (File.Exists(target)) files.Add(target);
            else if (Directory.Exists(target))
            {
                log.Report("Listando arquivos...");
                await Task.Run(() =>
                {
                    var opt = new EnumerationOptions { RecurseSubdirectories = true, IgnoreInaccessible = true, AttributesToSkip = FileAttributes.ReparsePoint };
                    try
                    {
                        foreach (var f in Directory.EnumerateFiles(target, "*", opt))
                        {
                            if (ct.IsCancellationRequested || files.Count >= 20000) break;
                            if (Exts.Contains(Path.GetExtension(f).ToLowerInvariant())) files.Add(f);
                        }
                    }
                    catch { }
                }, ct);
            }

            log.Report($"{files.Count} arquivos executáveis ou scripts. Verificando assinaturas...");
            await Signatures.VerifyAsync(files.Where(f => !Scripts.Contains(Path.GetExtension(f).ToLowerInvariant())));

            int i = 0;
            foreach (var f in files)
            {
                if (ct.IsCancellationRequested) break;
                if (++i % 200 == 0) log.Report($"Analisando {i}/{files.Count}...");
                var reasons = new List<string>();
                var risk = Severity.Info;
                void Hit(Severity sv, string why) { reasons.Add(why); if (sv > risk) risk = sv; }

                string ext = Path.GetExtension(f).ToLowerInvariant();
                var sig = Signatures.Cached(f);
                bool signed = sig?.Valid == true;

                if (Rules.DoubleExtension(f)) Hit(Severity.High, "extensão dupla (finge ser documento ou imagem)");
                if (Rules.IsMinerName(f)) Hit(signed ? Severity.Medium : Severity.High, "nome de programa minerador conhecido");
                if (sig?.Status == "HashMismatch") Hit(Severity.High, "assinatura digital adulterada");
                if (Rules.Masquerade(Path.GetFileName(f), f) is string mq && !signed) Hit(Severity.High, mq);
                if (!signed && Rules.InTemp(f) && ext is ".exe" or ".scr" or ".dll") Hit(Severity.Low, "executável sem assinatura na pasta temporária");

                if (Scripts.Contains(ext))
                {
                    try
                    {
                        var fi = new FileInfo(f);
                        if (fi.Length < 512 * 1024)
                        {
                            string text = await File.ReadAllTextAsync(f, ct);
                            if (Rules.MinerCommand(text) is string m) Hit(Severity.High, "script de mineração: " + m);
                            if (Rules.SuspiciousScript(text) is string sc) Hit(Severity.Medium, "script com " + sc);
                        }
                    }
                    catch { }
                }

                if (risk < Severity.Low) continue;
                findings.Add(new Finding
                {
                    Severity = risk,
                    Category = "Arquivo",
                    Title = Path.GetFileName(f),
                    Detail = ProcessScanner.Capitalize(string.Join("; ", reasons)) + $".\nAssinatura: {sig?.Text ?? "—"}",
                    Path = f,
                    Key = "file:" + f.ToLowerInvariant(),
                    Fix = FixKind.Quarantine,
                    FixLabel = "Pôr em quarentena"
                });
            }

            // Microsoft Defender na mesma pasta/arquivo
            if (!ct.IsCancellationRequested && Defender.MpCmdRun() != null)
            {
                log.Report("Microsoft Defender verificando...");
                var (_, output) = await Defender.CustomScanAsync(target, log, ct);
                findings.AddRange(Defender.ParseThreats(output));
            }

            // VirusTotal (opcional) para os arquivos suspeitos
            if (!ct.IsCancellationRequested && s.VirusTotalKey.Length > 0)
            {
                foreach (var f in findings.Where(x => x.Category == "Arquivo").OrderByDescending(x => x.Severity).Take(8).ToList())
                {
                    if (ct.IsCancellationRequested) break;
                    log.Report($"Consultando VirusTotal: {f.Title}");
                    string hash = Signatures.Sha256(f.Path);
                    if (hash.Length == 0) continue;
                    var vt = await VirusTotal.LookupAsync(hash, s.VirusTotalKey);
                    f.Status = !vt.Found ? (vt.Error.Length > 0 ? "VirusTotal: " + vt.Error : "VirusTotal: arquivo nunca analisado")
                                         : $"VirusTotal: {vt.Malicious} de {vt.Total} antivírus detectam";
                }
            }

            log.Report($"Concluído: {findings.Count} alertas em {files.Count} arquivos.");
            return findings;
        }
    }
}

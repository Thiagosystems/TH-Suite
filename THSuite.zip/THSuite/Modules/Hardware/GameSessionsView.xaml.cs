using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace THSuite.Hardware
{
    public partial class GameSessionsView : UserControl
    {
        GameMonitor? _mon;
        GameSession? _shown;
        bool _loading = true;

        public GameSessionsView()
        {
            InitializeComponent();
            Loaded += (_, _) =>
            {
                if (_mon != null) return;
                _mon = GameMonitor.Instance;
                if (_mon == null) return;
                ChkFps.IsChecked = SuiteSettings.Current.FpsCounter;
                _mon.Updated += () => Dispatcher.InvokeAsync(Refresh);
                _mon.SessionEnded += _ => Dispatcher.InvokeAsync(LoadList);
                LoadList();
                _loading = false;
            };
            ChkFps.Checked += (_, _) => SetFps(true);
            ChkFps.Unchecked += (_, _) => SetFps(false);
        }

        void SetFps(bool on)
        {
            if (_loading || _mon == null) return;
            SuiteSettings.Current.FpsCounter = on;
            SuiteSettings.Current.Save();
            _mon.SetFps(on);
        }

        void LoadList()
        {
            if (_mon == null) return;
            LstSessions.ItemsSource = null;
            LstSessions.ItemsSource = _mon.History.ToList();
            TxtSessEmpty.Visibility = _mon.History.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        }

        void Refresh()
        {
            if (_mon == null || !IsVisible) return;
            var cur = _mon.Current;
            TxtFps.Text = _mon.Fps is int f ? f.ToString() : "—";
            if (cur != null)
            {
                TxtGame.Text = cur.Game;
                TxtGameSub.Text = $"Gravando há {TimeSpan.FromSeconds(cur.Seconds):h\\:mm\\:ss}";
                var last = cur.Samples.LastOrDefault();
                TxtCpuT.Text = last?.CpuTemp is float c ? $"{c:0}°" : "—";
                TxtGpuT.Text = last?.GpuTemp is float g ? $"{g:0}°" : "—";
                if (_shown == null) Draw(cur);
            }
            else
            {
                TxtGame.Text = "Nenhum jogo rodando";
                TxtGameSub.Text = !_mon.FpsEnabled ? "Ligue \"Medir FPS\" para ver os quadros por segundo."
                                : _mon.FpsError.Length > 0 ? "Não foi possível medir o FPS: " + _mon.FpsError
                                : "Abra um jogo: o TH Suite começa a gravar FPS, temperaturas e uso sozinho.";
                TxtCpuT.Text = TxtGpuT.Text = "—";
                if (_shown == null) Draw(null);
            }
        }

        void Sessions_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            _shown = LstSessions.SelectedItem as GameSession;
            TxtChartTitle.Text = _shown == null ? "SESSÃO ATUAL" : $"SESSÃO: {_shown.Title}".ToUpperInvariant();
            Draw(_shown ?? _mon?.Current);
        }

        void Chart_SizeChanged(object sender, SizeChangedEventArgs e) => Draw(_shown ?? _mon?.Current);

        void Clear_Click(object sender, RoutedEventArgs e)
        {
            if (_mon == null || !Host.Confirm("Apagar todas as sessões de jogo gravadas?")) return;
            _mon.ClearHistory();
            _shown = null;
            LoadList();
            Draw(_mon.Current);
        }

        void Draw(GameSession? s)
        {
            Chart.Children.Clear();
            var samples = s?.Samples ?? new List<GameSample>();
            TxtNoData.Visibility = samples.Count < 2 ? Visibility.Visible : Visibility.Collapsed;
            TxtChartInfo.Text = s != null ? s.Summary : "";
            double w = ChartHost.ActualWidth, h = ChartHost.ActualHeight;
            if (samples.Count < 2 || w < 10 || h < 10) return;

            double maxT = Math.Max(1, samples[^1].T);
            double maxFps = Math.Max(60, samples.Max(x => x.Fps) * 1.1);
            const double maxTemp = 110;

            // linhas de grade
            for (int i = 1; i < 4; i++)
            {
                var gl = new Line { X1 = 0, X2 = w, Y1 = h * i / 4, Y2 = h * i / 4, StrokeThickness = 1, Opacity = 0.25 };
                gl.SetResourceReference(Shape.StrokeProperty, "TrackBrush");
                Chart.Children.Add(gl);
            }
            AddLine(samples.Select(x => (x.T, (double?)x.Fps)), maxT, maxFps, w, h, "AccentSolidBrush");
            AddLine(samples.Select(x => (x.T, (double?)x.CpuTemp)), maxT, maxTemp, w, h, "WarnSolidBrush");
            AddLine(samples.Select(x => (x.T, (double?)x.GpuTemp)), maxT, maxTemp, w, h, "DangerSolidBrush");

            var lbl = new TextBlock { Text = $"{maxFps:0} FPS", FontSize = 10 };
            lbl.SetResourceReference(TextBlock.ForegroundProperty, "MutedBrush");
            Canvas.SetLeft(lbl, 6); Canvas.SetTop(lbl, 4);
            Chart.Children.Add(lbl);
        }

        void AddLine(IEnumerable<(int T, double? V)> pts, double maxT, double maxV, double w, double h, string brush)
        {
            var line = new Polyline { StrokeThickness = 1.6, StrokeLineJoin = PenLineJoin.Round };
            line.SetResourceReference(Shape.StrokeProperty, brush);
            foreach (var (t, v) in pts)
            {
                if (v is not double val || val <= 0) continue;
                line.Points.Add(new Point(t / maxT * w, h - 4 - (h - 8) * Math.Min(1, val / maxV)));
            }
            if (line.Points.Count > 1) Chart.Children.Add(line);
        }
    }
}

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace THSuite.Hardware
{
    public class DnsProvider : Observable
    {
        string _latency = "";
        bool _isCurrent;
        public string Name { get; init; } = "";
        public string Primary { get; init; } = "";
        public string Secondary { get; init; } = "";
        public string Note { get; init; } = "";
        public bool IsAuto => Primary.Length == 0;
        public string Servers => IsAuto ? "Do seu provedor de internet (DHCP)" : $"{Primary}  ·  {Secondary}";
        public double? Ms { get; set; }
        public string Latency { get => _latency; set => Set(ref _latency, value); }
        public bool IsCurrent { get => _isCurrent; set => Set(ref _isCurrent, value); }
    }

    public record AdapterInfo(string Name, string Type, string Speed, string Ip, string Gateway, string[] Dns, int Index, string Id);

    public static class NetworkTools
    {
        public static List<DnsProvider> Providers() => new()
        {
            new() { Name = "Automático", Note = "O DNS do seu provedor. Escolha este para desfazer a troca." },
            new() { Name = "Cloudflare", Primary = "1.1.1.1", Secondary = "1.0.0.1", Note = "Costuma ser um dos mais rápidos e não guarda o seu histórico." },
            new() { Name = "Google", Primary = "8.8.8.8", Secondary = "8.8.4.4", Note = "Muito estável e confiável, usado no mundo todo." },
            new() { Name = "Quad9", Primary = "9.9.9.9", Secondary = "149.112.112.112", Note = "Bloqueia automaticamente sites de golpe e vírus." },
            new() { Name = "OpenDNS", Primary = "208.67.222.222", Secondary = "208.67.220.220", Note = "Da Cisco, com opção de filtrar sites." },
            new() { Name = "AdGuard", Primary = "94.140.14.14", Secondary = "94.140.15.15", Note = "Bloqueia anúncios e rastreadores em todos os apps." },
        };

        // ------------------------------------------------------------ adaptador

        public static NetworkInterface? ActiveAdapter()
        {
            try
            {
                return NetworkInterface.GetAllNetworkInterfaces()
                    .Where(n => n.OperationalStatus == OperationalStatus.Up
                                && n.NetworkInterfaceType != NetworkInterfaceType.Loopback
                                && n.NetworkInterfaceType != NetworkInterfaceType.Tunnel
                                && n.GetIPProperties().GatewayAddresses.Any(g => g.Address.AddressFamily == AddressFamily.InterNetwork
                                                                                && !g.Address.Equals(IPAddress.Any)))
                    .OrderByDescending(n => n.Speed)
                    .FirstOrDefault();
            }
            catch { return null; }
        }

        public static AdapterInfo? Info(NetworkInterface? n)
        {
            if (n == null) return null;
            try
            {
                var ip = n.GetIPProperties();
                string type = n.NetworkInterfaceType switch
                {
                    NetworkInterfaceType.Wireless80211 => "Wi-Fi",
                    NetworkInterfaceType.Ethernet or NetworkInterfaceType.GigabitEthernet or NetworkInterfaceType.FastEthernetT => "Cabo (Ethernet)",
                    _ => n.NetworkInterfaceType.ToString()
                };
                string speed = n.Speed >= 1_000_000_000 ? $"{n.Speed / 1_000_000_000.0:0.#} Gbps" : $"{n.Speed / 1_000_000} Mbps";
                return new AdapterInfo(
                    n.Name + " (" + n.Description + ")",
                    type,
                    speed,
                    ip.UnicastAddresses.FirstOrDefault(a => a.Address.AddressFamily == AddressFamily.InterNetwork)?.Address.ToString() ?? "—",
                    ip.GatewayAddresses.FirstOrDefault(g => g.Address.AddressFamily == AddressFamily.InterNetwork)?.Address.ToString() ?? "—",
                    ip.DnsAddresses.Where(a => a.AddressFamily == AddressFamily.InterNetwork).Select(a => a.ToString()).ToArray(),
                    ip.GetIPv4Properties()?.Index ?? -1,
                    n.Id);
            }
            catch { return null; }
        }

        // ------------------------------------------------------------------ DNS

        public static async Task<bool> SetDnsAsync(int interfaceIndex, DnsProvider p)
        {
            string cmd = p.IsAuto
                ? $"Set-DnsClientServerAddress -InterfaceIndex {interfaceIndex} -ResetServerAddresses -ErrorAction Stop"
                : $"Set-DnsClientServerAddress -InterfaceIndex {interfaceIndex} -ServerAddresses ('{p.Primary}','{p.Secondary}') -ErrorAction Stop";
            var (code, _) = await Shell.PowerShellAsync(cmd + "; Clear-DnsClientCache");
            return code == 0;
        }

        public static Task FlushDnsAsync() => Shell.RunAsync("ipconfig.exe", "/flushdns");

        /// <summary>Mede o tempo de resposta de um servidor DNS (mediana de 4 consultas).</summary>
        public static async Task<double?> MeasureDnsAsync(string server)
        {
            var times = new List<double>();
            foreach (var domain in new[] { "google.com", "cloudflare.com", "microsoft.com", "youtube.com" })
            {
                try
                {
                    using var udp = new UdpClient();
                    udp.Connect(IPAddress.Parse(server), 53);
                    ushort id = (ushort)Random.Shared.Next(1, 65535);
                    byte[] q = BuildQuery(id, domain);
                    var sw = Stopwatch.StartNew();
                    await udp.SendAsync(q, q.Length);
                    var recv = udp.ReceiveAsync();
                    if (await Task.WhenAny(recv, Task.Delay(1500)) == recv)
                    {
                        var res = await recv;
                        if (res.Buffer.Length > 2 && res.Buffer[0] == q[0] && res.Buffer[1] == q[1])
                            times.Add(sw.Elapsed.TotalMilliseconds);
                    }
                }
                catch { }
            }
            if (times.Count == 0) return null;
            times.Sort();
            return times[times.Count / 2];
        }

        public static byte[] BuildQuery(ushort id, string domain)
        {
            var b = new List<byte> { (byte)(id >> 8), (byte)id, 0x01, 0x00, 0, 1, 0, 0, 0, 0, 0, 0 };
            foreach (var label in domain.Split('.'))
            {
                b.Add((byte)label.Length);
                b.AddRange(Encoding.ASCII.GetBytes(label));
            }
            b.Add(0);
            b.AddRange(new byte[] { 0, 1, 0, 1 }); // tipo A, classe IN
            return b.ToArray();
        }

        // ---------------------------------------------------------- otimizações

        const string InterfacesKey = @"SYSTEM\CurrentControlSet\Services\Tcpip\Parameters\Interfaces";
        const string ProfileKey = @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile";

        /// <summary>Nagle desativado = pacotes pequenos (comandos do jogo) saem na hora.</summary>
        public static bool NagleDisabled(string adapterId)
        {
            try
            {
                using var k = Registry.LocalMachine.OpenSubKey($@"{InterfacesKey}\{adapterId}");
                return k?.GetValue("TcpAckFrequency") is int v && v == 1;
            }
            catch { return false; }
        }

        public static void SetNagle(bool disable)
        {
            using var root = Registry.LocalMachine.OpenSubKey(InterfacesKey, true);
            if (root == null) return;
            foreach (var name in root.GetSubKeyNames())
            {
                try
                {
                    using var k = root.OpenSubKey(name, true);
                    if (k == null) continue;
                    bool hasIp = !string.IsNullOrEmpty(k.GetValue("DhcpIPAddress") as string)
                                 || (k.GetValue("IPAddress") is string[] ips && ips.Any(i => i.Length > 0 && i != "0.0.0.0"));
                    if (!hasIp && !disable) { k.DeleteValue("TcpAckFrequency", false); k.DeleteValue("TCPNoDelay", false); continue; }
                    if (!hasIp) continue;
                    if (disable)
                    {
                        k.SetValue("TcpAckFrequency", 1, RegistryValueKind.DWord);
                        k.SetValue("TCPNoDelay", 1, RegistryValueKind.DWord);
                    }
                    else
                    {
                        k.DeleteValue("TcpAckFrequency", false);
                        k.DeleteValue("TCPNoDelay", false);
                    }
                }
                catch { }
            }
        }

        /// <summary>Windows limita a rede enquanto toca áudio/vídeo; desligar ajuda em jogos.</summary>
        public static bool ThrottlingOff()
        {
            try
            {
                using var k = Registry.LocalMachine.OpenSubKey(ProfileKey);
                return k?.GetValue("NetworkThrottlingIndex") is int v && v == unchecked((int)0xFFFFFFFF);
            }
            catch { return false; }
        }

        public static void SetThrottling(bool off)
        {
            using var k = Registry.LocalMachine.CreateSubKey(ProfileKey, true);
            k.SetValue("NetworkThrottlingIndex", off ? unchecked((int)0xFFFFFFFF) : 10, RegistryValueKind.DWord);
            k.SetValue("SystemResponsiveness", off ? 10 : 20, RegistryValueKind.DWord);
        }

        /// <summary>Marca o tráfego dos jogos com prioridade alta (DSCP 46).</summary>
        public static async Task<bool> ApplyQosAsync(IEnumerable<string> exes)
        {
            var names = exes.Select(e => Path.GetFileName(e.Trim()).Replace("'", ""))
                            .Where(e => e.Length > 0)
                            .Select(e => e.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) ? e : e + ".exe")
                            .Distinct(StringComparer.OrdinalIgnoreCase).ToList();

            var sb = new StringBuilder();
            sb.Append("Get-NetQosPolicy -ErrorAction SilentlyContinue | Where-Object { $_.Name -like 'THControl_*' } | Remove-NetQosPolicy -Confirm:$false -ErrorAction SilentlyContinue; ");
            int i = 0;
            foreach (var n in names)
                sb.Append($"New-NetQosPolicy -Name 'THControl_{i++}' -AppPathNameMatchCondition '{n}' -DSCPAction 46 -NetworkProfile All -IPProtocolMatchCondition Both -ErrorAction Stop | Out-Null; ");

            try
            {
                using var qos = Registry.LocalMachine.CreateSubKey(@"SYSTEM\CurrentControlSet\Services\Tcpip\QoS", true);
                qos.SetValue("Do not use NLA", "1", RegistryValueKind.String);
            }
            catch { }

            var (code, _) = await Shell.PowerShellAsync(sb.ToString());
            return code == 0;
        }

        public static async Task RemoveQosAsync() =>
            await Shell.PowerShellAsync("Get-NetQosPolicy -ErrorAction SilentlyContinue | Where-Object { $_.Name -like 'THControl_*' } | Remove-NetQosPolicy -Confirm:$false -ErrorAction SilentlyContinue");

        public static async Task ResetNetworkAsync()
        {
            await Shell.RunAsync("netsh.exe", "winsock reset");
            await Shell.RunAsync("netsh.exe", "int ip reset");
            await Shell.RunAsync("ipconfig.exe", "/flushdns");
        }
    }
}

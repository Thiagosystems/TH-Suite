using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;

namespace THSuite.Hardware
{
    public partial class DiskHealthView : UserControl
    {
        bool _loaded;

        public DiskHealthView()
        {
            InitializeComponent();
            IsVisibleChanged += async (_, _) => { if (IsVisible && !_loaded) await LoadAsync(); };
        }

        async void Refresh_Click(object sender, RoutedEventArgs e) => await LoadAsync();
        void Check_Click(object sender, RoutedEventArgs e) => Host.Navigate("repair", "disk");

        record Disk(string Name, string Media, string Bus, double SizeGB, string Health, string Status,
                    int? Wear, int? Temp, int? TempMax, long? Hours, long? ReadErr, long? WriteErr);

        /// <summary>Lê o SMART pelo PowerShell (Get-PhysicalDisk + Get-StorageReliabilityCounter).</summary>
        public static async Task<List<object[]>> ReadRawAsync()
        {
            const string script = @"
$l = @(Get-PhysicalDisk | Sort-Object DeviceId | ForEach-Object {
  $r = $_ | Get-StorageReliabilityCounter -ErrorAction SilentlyContinue
  [pscustomobject]@{ Name=$_.FriendlyName; Media=[string]$_.MediaType; Bus=[string]$_.BusType; Size=[double]$_.Size;
    Health=[string]$_.HealthStatus; Status=(($_.OperationalStatus | ForEach-Object { [string]$_ }) -join ', ');
    Wear=$r.Wear; Temp=$r.Temperature; TempMax=$r.TemperatureMax; Hours=$r.PowerOnHours; ReadErr=$r.ReadErrorsTotal; WriteErr=$r.WriteErrorsTotal }
})
ConvertTo-Json -InputObject $l -Compress";
            var (_, o) = await Cmd.PowerShellAsync(script, null, 60000);
            var list = new List<object[]>();
            int s = o.IndexOf('['), e = o.LastIndexOf(']');
            if (s < 0 || e <= s) return list;
            try
            {
                using var doc = JsonDocument.Parse(o[s..(e + 1)]);
                foreach (var d in doc.RootElement.EnumerateArray())
                {
                    string S(string k) => d.TryGetProperty(k, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() ?? "" : "";
                    long? L(string k) => d.TryGetProperty(k, out var v) && v.ValueKind == JsonValueKind.Number ? (long)v.GetDouble() : null;
                    list.Add(new object[] { S("Name"), S("Media"), S("Bus"), (L("Size") ?? 0) / 1e9, S("Health"), S("Status"),
                                            L("Wear"), L("Temp"), L("TempMax"), L("Hours"), L("ReadErr"), L("WriteErr") });
                }
            }
            catch { }
            return list;
        }

        async Task LoadAsync()
        {
            _loaded = true;
            TxtDiskStatus.Text = "Lendo os discos...";
            DiskList.Children.Clear();
            var raw = await ReadRawAsync();
            var disks = raw.Select(r => new Disk((string)r[0], (string)r[1], (string)r[2], (double)r[3], (string)r[4], (string)r[5],
                (int?)(long?)r[6], (int?)(long?)r[7], (int?)(long?)r[8], (long?)r[9], (long?)r[10], (long?)r[11])).ToList();

            int bad = 0;
            foreach (var d in disks)
            {
                bool problem = d.Health is not ("Healthy" or "") || d.Wear >= 90 || d.Temp >= 65;
                bool warn = !problem && (d.Wear >= 70 || d.Temp >= 55);
                if (problem) bad++;
                DiskList.Children.Add(DiskCard(d, problem, warn));
            }
            TxtDiskStatus.Text = disks.Count == 0 ? "Não foi possível ler os discos (o Windows não informou os dados)."
                               : bad == 0 ? $"{disks.Count} disco(s) encontrado(s). Nenhum problema." : $"Atenção: {bad} disco(s) com sinais de problema. Faça backup dos seus arquivos.";
            if (bad > 0) Activity.Log("Hardware", TxtDiskStatus.Text);

            VolList.Children.Clear();
            foreach (var v in DriveInfo.GetDrives().Where(x => x.IsReady && x.DriveType is DriveType.Fixed or DriveType.Removable))
            {
                double used = (v.TotalSize - v.AvailableFreeSpace) * 100.0 / Math.Max(1, v.TotalSize);
                VolList.Children.Add(VolumeCard(v, used));
            }
        }

        UIElement DiskCard(Disk d, bool problem, bool warn)
        {
            var b = new Border { Style = (Style)FindResource("Card"), Margin = new Thickness(0, 0, 0, 10) };
            var sp = new StackPanel();
            var head = new Grid();
            var title = new TextBlock { Text = d.Name, FontSize = 14, FontWeight = FontWeights.SemiBold };
            title.SetResourceReference(TextBlock.ForegroundProperty, "TextBrush");
            head.Children.Add(title);
            var badge = new Border { Style = (Style)FindResource("Badge"), HorizontalAlignment = HorizontalAlignment.Right,
                Background = new SolidColorBrush(problem ? Color.FromArgb(0x30, 0xEF, 0x44, 0x44) : warn ? Color.FromArgb(0x30, 0xF5, 0x9E, 0x0B) : Color.FromArgb(0x30, 0x10, 0xB9, 0x81)) };
            var bt = new TextBlock { Text = problem ? "Problema" : warn ? "Atenção" : "Saudável", FontSize = 11, FontWeight = FontWeights.SemiBold };
            bt.SetResourceReference(TextBlock.ForegroundProperty, problem ? "DangerSolidBrush" : warn ? "WarnSolidBrush" : "OkSolidBrush");
            badge.Child = bt;
            head.Children.Add(badge);
            sp.Children.Add(head);

            string type = d.Media switch { "SSD" => "SSD", "HDD" => "HD (disco mecânico)", _ => "Disco" };
            sp.Children.Add(Muted($"{type} · {d.Bus} · {d.SizeGB:0} GB · estado: {Pt(d.Health)}" + (d.Status.Length > 0 && d.Status != "OK" ? $" ({d.Status})" : "")));

            var grid = new UniformGrid { Columns = 4, Margin = new Thickness(0, 12, 0, 0) };
            grid.Children.Add(Stat("Vida útil usada", d.Wear is int w ? $"{w}%" : "—", d.Wear is int w2 ? Math.Min(100, w2) : (double?)null));
            grid.Children.Add(Stat("Temperatura", d.Temp is int t && t > 0 ? $"{t} °C" + (d.TempMax is int tm && tm > 0 ? $" (máx {tm})" : "") : "—", null));
            grid.Children.Add(Stat("Tempo ligado", d.Hours is long h ? (h >= 48 ? $"{h / 24:N0} dias" : $"{h} h") : "—", null));
            long errs = (d.ReadErr ?? 0) + (d.WriteErr ?? 0);
            grid.Children.Add(Stat("Erros de leitura/gravação", d.ReadErr == null && d.WriteErr == null ? "—" : errs.ToString("N0"), null));
            sp.Children.Add(grid);

            string tip = problem ? "O disco informou problema. Copie seus arquivos importantes para outro lugar o quanto antes e considere trocar o disco."
                       : d.Wear >= 70 ? "O SSD já usou boa parte da vida útil. Ainda funciona, mas vá planejando a troca."
                       : d.Temp >= 55 ? "Temperatura alta. Melhore a ventilação do gabinete ou use um dissipador no SSD NVMe."
                       : "Tudo certo. \"—\" significa que o disco não informa esse dado.";
            var tipTb = Muted(tip);
            tipTb.Margin = new Thickness(0, 10, 0, 0);
            if (problem || warn) tipTb.SetResourceReference(TextBlock.ForegroundProperty, problem ? "DangerSolidBrush" : "WarnSolidBrush");
            sp.Children.Add(tipTb);
            b.Child = sp;
            return b;
        }

        static string Pt(string h) => h switch { "Healthy" => "saudável", "Warning" => "aviso", "Unhealthy" => "com falha", "" => "desconhecido", _ => h };

        TextBlock Muted(string text)
        {
            var t = new TextBlock { Text = text, FontSize = 11.5, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 0) };
            t.SetResourceReference(TextBlock.ForegroundProperty, "MutedBrush");
            return t;
        }

        UIElement Stat(string label, string value, double? bar)
        {
            var sp = new StackPanel { Margin = new Thickness(0, 0, 14, 0) };
            var l = new TextBlock { Text = label, FontSize = 11 };
            l.SetResourceReference(TextBlock.ForegroundProperty, "MutedBrush");
            var v = new TextBlock { Text = value, FontSize = 16, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 2, 0, 0) };
            v.SetResourceReference(TextBlock.ForegroundProperty, "TextBrush");
            sp.Children.Add(l);
            sp.Children.Add(v);
            if (bar is double p)
                sp.Children.Add(new ProgressBar { Style = (Style)FindResource("Progress"), Height = 5, Maximum = 100, Value = p, Margin = new Thickness(0, 6, 0, 0) });
            return sp;
        }

        UIElement VolumeCard(DriveInfo v, double used)
        {
            var b = new Border { Style = (Style)FindResource("Card"), Margin = new Thickness(0, 0, 0, 8), Padding = new Thickness(16, 10, 16, 10) };
            var sp = new StackPanel();
            var g = new Grid();
            var name = new TextBlock { Text = $"{v.Name.TrimEnd('\\')}  {(string.IsNullOrWhiteSpace(v.VolumeLabel) ? "" : v.VolumeLabel)}", FontSize = 13, FontWeight = FontWeights.SemiBold };
            name.SetResourceReference(TextBlock.ForegroundProperty, "TextBrush");
            var free = new TextBlock { Text = $"{v.AvailableFreeSpace / 1e9:0} GB livres de {v.TotalSize / 1e9:0} GB", FontSize = 11.5, HorizontalAlignment = HorizontalAlignment.Right };
            free.SetResourceReference(TextBlock.ForegroundProperty, "MutedBrush");
            g.Children.Add(name);
            g.Children.Add(free);
            sp.Children.Add(g);
            sp.Children.Add(new ProgressBar { Style = (Style)FindResource("Progress"), Height = 6, Maximum = 100, Value = used, Margin = new Thickness(0, 8, 0, 0) });
            b.Child = sp;
            return b;
        }
    }
}

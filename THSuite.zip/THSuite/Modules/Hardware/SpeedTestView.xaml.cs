using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace THSuite.Hardware
{
    public partial class SpeedTestView : UserControl
    {
        public class SpeedResult
        {
            public DateTime Time { get; set; }
            public double Ping { get; set; }
            public double Jitter { get; set; }
            public double Down { get; set; }
            public double Up { get; set; }
        }

        static string FilePath => Path.Combine(SuiteSettings.DataDir, "testes-de-velocidade.json");
        List<SpeedResult> _hist = new();
        bool _running;

        public SpeedTestView()
        {
            InitializeComponent();
            try { if (File.Exists(FilePath)) _hist = JsonSerializer.Deserialize<List<SpeedResult>>(File.ReadAllText(FilePath)) ?? new(); } catch { }
            ShowHistory();
        }

        async void Start_Click(object sender, RoutedEventArgs e)
        {
            if (_running) return;
            _running = true;
            BtnSpeed.IsEnabled = false;
            PrgSpeed.Visibility = Visibility.Visible;
            PrgSpeed.Value = 0;
            TxtPing.Text = TxtJitter.Text = TxtDown.Text = TxtUp.Text = "—";
            var r = new SpeedResult { Time = DateTime.Now };
            try
            {
                TxtSpeedStatus.Text = "Medindo o ping...";
                (r.Ping, r.Jitter) = await PingAsync();
                TxtPing.Text = r.Ping > 0 ? $"{r.Ping:0}" : "—";
                TxtJitter.Text = r.Ping > 0 ? $"{r.Jitter:0}" : "—";
                PrgSpeed.Value = 10;

                TxtSpeedStatus.Text = "Medindo o download...";
                r.Down = await TransferAsync(false, mbps => Dispatcher.Invoke(() => TxtDown.Text = $"{mbps:0}"), p => Dispatcher.Invoke(() => PrgSpeed.Value = 10 + p * 45));
                TxtDown.Text = $"{r.Down:0}";

                TxtSpeedStatus.Text = "Medindo o upload...";
                r.Up = await TransferAsync(true, mbps => Dispatcher.Invoke(() => TxtUp.Text = $"{mbps:0}"), p => Dispatcher.Invoke(() => PrgSpeed.Value = 55 + p * 45));
                TxtUp.Text = $"{r.Up:0}";

                TxtSpeedStatus.Text = $"Concluído às {DateTime.Now:HH:mm}.";
                TxtVerdict.Text = Verdict(r);
                _hist.Insert(0, r);
                if (_hist.Count > 15) _hist.RemoveRange(15, _hist.Count - 15);
                try { Directory.CreateDirectory(SuiteSettings.DataDir); File.WriteAllText(FilePath, JsonSerializer.Serialize(_hist)); } catch { }
                ShowHistory();
                Activity.Log("Internet", $"Teste de velocidade: ping {r.Ping:0} ms, download {r.Down:0} Mbps, upload {r.Up:0} Mbps");
            }
            catch (Exception ex)
            {
                TxtSpeedStatus.Text = "Não foi possível concluir o teste: " + ex.Message;
            }
            PrgSpeed.Visibility = Visibility.Hidden;
            BtnSpeed.IsEnabled = true;
            _running = false;
        }

        static async Task<(double Ping, double Jitter)> PingAsync()
        {
            var times = new List<double>();
            using var p = new Ping();
            for (int i = 0; i < 12; i++)
            {
                try
                {
                    var reply = await p.SendPingAsync("1.1.1.1", 2000);
                    if (reply.Status == IPStatus.Success) times.Add(reply.RoundtripTime);
                }
                catch { }
                await Task.Delay(150);
            }
            if (times.Count == 0) return (0, 0);
            double jitter = times.Count > 1 ? times.Zip(times.Skip(1), (a, b) => Math.Abs(a - b)).Average() : 0;
            return (times.Min() + (times.Average() - times.Min()) / 2, jitter);
        }

        /// <summary>Várias conexões ao mesmo tempo por ~8 segundos; resultado em Mbps.</summary>
        static async Task<double> TransferAsync(bool upload, Action<double> live, Action<double> progress)
        {
            const int Streams = 4;
            var duration = TimeSpan.FromSeconds(8);
            long total = 0;
            var sw = Stopwatch.StartNew();
            using var cts = new CancellationTokenSource(duration + TimeSpan.FromSeconds(4));
            using var http = new HttpClient { Timeout = TimeSpan.FromSeconds(30) };
            http.DefaultRequestHeaders.UserAgent.ParseAdd("THSuite/" + MainWindow.Version);
            var payload = new byte[2 * 1024 * 1024];
            new Random(1).NextBytes(payload);

            async Task Worker()
            {
                var buf = new byte[64 * 1024];
                while (sw.Elapsed < duration && !cts.IsCancellationRequested)
                {
                    try
                    {
                        if (upload)
                        {
                            using var content = new ByteArrayContent(payload);
                            using var resp = await http.PostAsync("https://speed.cloudflare.com/__up", content, cts.Token);
                            Interlocked.Add(ref total, payload.Length);
                        }
                        else
                        {
                            using var resp = await http.GetAsync("https://speed.cloudflare.com/__down?bytes=50000000", HttpCompletionOption.ResponseHeadersRead, cts.Token);
                            await using var s = await resp.Content.ReadAsStreamAsync(cts.Token);
                            int n;
                            while ((n = await s.ReadAsync(buf, cts.Token)) > 0)
                            {
                                Interlocked.Add(ref total, n);
                                if (sw.Elapsed >= duration) break;
                            }
                        }
                    }
                    catch (OperationCanceledException) { break; }
                    catch { await Task.Delay(300); }
                }
            }

            var workers = Enumerable.Range(0, Streams).Select(_ => Worker()).ToList();
            while (workers.Any(w => !w.IsCompleted) && sw.Elapsed < duration + TimeSpan.FromSeconds(2))
            {
                await Task.Delay(250);
                double secs = Math.Max(0.25, sw.Elapsed.TotalSeconds);
                live(Interlocked.Read(ref total) * 8 / secs / 1e6);
                progress(Math.Min(1, sw.Elapsed.TotalSeconds / duration.TotalSeconds));
            }
            cts.Cancel();
            try { await Task.WhenAll(workers); } catch { }
            double elapsed = Math.Min(sw.Elapsed.TotalSeconds, duration.TotalSeconds + 0.5);
            return Interlocked.Read(ref total) * 8 / Math.Max(0.5, elapsed) / 1e6;
        }

        static string Verdict(SpeedResult r)
        {
            string ping = r.Ping <= 0 ? "Não foi possível medir o ping." :
                          r.Ping < 40 ? $"Ping de {r.Ping:0} ms: ótimo para jogos competitivos." :
                          r.Ping < 80 ? $"Ping de {r.Ping:0} ms: bom para a maioria dos jogos." :
                          $"Ping de {r.Ping:0} ms: alto. Use cabo em vez de Wi-Fi, feche downloads e teste outro DNS na aba Internet para jogos.";
            string jit = r.Jitter < 10 ? " A conexão está estável." : $" Variação de {r.Jitter:0} ms: a conexão oscila, o que causa \"lag\". Wi-Fi e downloads em outros aparelhos são as causas mais comuns.";
            string down = r.Down >= 100 ? $" Download de {r.Down:0} Mbps: rápido." : r.Down >= 25 ? $" Download de {r.Down:0} Mbps: suficiente para jogar e assistir em HD." : $" Download de {r.Down:0} Mbps: lento para baixar jogos e ver vídeos em alta qualidade.";
            return ping + jit + down;
        }

        void ShowHistory()
        {
            HistList.Children.Clear();
            if (_hist.Count == 0)
            {
                var t = new TextBlock { Text = "Nenhum teste feito ainda.", FontSize = 12 };
                t.SetResourceReference(TextBlock.ForegroundProperty, "MutedBrush");
                HistList.Children.Add(t);
                return;
            }
            foreach (var r in _hist)
            {
                var t = new TextBlock
                {
                    Text = $"{r.Time:dd/MM HH:mm}     ping {r.Ping:0} ms  ·  variação {r.Jitter:0} ms  ·  ↓ {r.Down:0} Mbps  ·  ↑ {r.Up:0} Mbps",
                    FontSize = 12, Margin = new Thickness(0, 0, 0, 6), FontFamily = new System.Windows.Media.FontFamily("Consolas")
                };
                t.SetResourceReference(TextBlock.ForegroundProperty, "TextBrush");
                HistList.Children.Add(t);
            }
        }
    }
}

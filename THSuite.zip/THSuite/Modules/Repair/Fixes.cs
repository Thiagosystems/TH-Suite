using System;
using System.Collections.Generic;

namespace THSuite.Repair
{
    /// <summary>Um reparo: explica o problema, o que vai ser feito e roda um script do PowerShell.</summary>
    public class Fix : Bindable
    {
        public string Id { get; init; } = "";
        public string Group { get; init; } = "";
        public string Icon { get; init; } = "";
        public string Title { get; init; } = "";
        public string Problem { get; init; } = "";
        public string[] Steps { get; init; } = Array.Empty<string>();
        public string Warning { get; init; } = "";
        public string Duration { get; init; } = "menos de 1 minuto";
        public bool NeedsRestart { get; init; }
        public string Script { get; init; } = "";
        /// <summary>Página das Configurações do Windows para abrir no final (opcional).</summary>
        public string OpenAfter { get; init; } = "";
        /// <summary>Ação extra em C# (ex.: limpar memória pelo módulo de RAM).</summary>
        public Func<Action<string>, System.Threading.Tasks.Task>? After { get; set; }

        string _status = "";
        public string Status { get => _status; set => Set(ref _status, value); }
        public string StepsText => "• " + string.Join("\n• ", Steps);
    }

    public static class Fixes
    {
        public const string GConn = "Internet e conexões", GDev = "Som, câmera e dispositivos", GSys = "Sistema e arquivos",
                            GApps = "Apps, loja e jogos", GPerf = "Lentidão e travamentos";

        // Reinicia dispositivos de uma classe (pnputil existe no Windows 10 2004+)
        const string RestartDevices = @"
function Restart-Class($classes) {
  foreach ($d in Get-PnpDevice -PresentOnly -ErrorAction SilentlyContinue | Where-Object { $classes -contains $_.Class }) {
    Write-Output (""Reiniciando: "" + $d.FriendlyName)
    pnputil /restart-device ""$($d.InstanceId)"" | Out-Null
  }
}
";

        public static List<Fix> Build() => new()
        {
            // ================= INTERNET E CONEXÕES =================
            new Fix
            {
                Id = "network", Group = GConn, Icon = "", Title = "Rede e internet", NeedsRestart = true,
                Problem = "Sem internet, \"Sem acesso à internet\", sites que não abrem, conexão instável ou lenta do nada.",
                Steps = new[] { "Limpa o cache de DNS", "Renova o endereço IP (a internet cai por alguns segundos)", "Redefine o Winsock e a pilha TCP/IP", "Remove proxy que vírus ou programas possam ter configurado" },
                Warning = "Se você usa VPN ou IP fixo configurado na mão, pode precisar configurar de novo.",
                Script = @"
Write-Output 'Limpando cache de DNS...'; ipconfig /flushdns
Write-Output 'Renovando IP...'; ipconfig /release | Out-Null; ipconfig /renew | Out-Null
Write-Output 'Redefinindo Winsock...'; netsh winsock reset
Write-Output 'Redefinindo TCP/IP...'; netsh int ip reset | Out-Null
Write-Output 'Removendo proxy...'; netsh winhttp reset proxy
Set-ItemProperty 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -Name ProxyEnable -Value 0 -ErrorAction SilentlyContinue
Write-Output 'Concluído. Reinicie o PC para terminar.'"
            },
            new Fix
            {
                Id = "dns", Group = GConn, Icon = "", Title = "DNS (sites não abrem)",
                Problem = "Alguns sites não carregam, erro DNS_PROBE ou \"servidor DNS não está respondendo\".",
                Steps = new[] { "Limpa o cache de DNS do Windows", "Registra o PC de novo no DNS", "Mostra quais servidores DNS estão em uso" },
                Script = @"
ipconfig /flushdns
Clear-DnsClientCache
ipconfig /registerdns | Out-Null
Write-Output ''
Write-Output 'Servidores DNS em uso:'
Get-DnsClientServerAddress -AddressFamily IPv4 | Where-Object { $_.ServerAddresses } | ForEach-Object { Write-Output (""  "" + $_.InterfaceAlias + "": "" + ($_.ServerAddresses -join ', ')) }
Write-Output ''
Write-Output 'Dica: em Hardware e internet > Internet para jogos você pode trocar para um DNS mais rápido (Cloudflare, Google).'"
            },
            new Fix
            {
                Id = "wifi", Group = GConn, Icon = "", Title = "Reativar o Wi-Fi",
                Problem = "O Wi-Fi sumiu, não liga, não mostra redes ou desconecta sozinho.",
                Steps = new[] { "Liga os adaptadores de rede sem fio que estiverem desativados", "Reinicia o serviço de Wi-Fi (WLAN AutoConfig)", "Reinicia o adaptador Wi-Fi" },
                OpenAfter = "ms-settings:network-wifi",
                Script = RestartDevices + @"
$w = Get-NetAdapter -ErrorAction SilentlyContinue | Where-Object { $_.PhysicalMediaType -match '802\.11|Wireless' -or $_.InterfaceDescription -match 'Wi-?Fi|Wireless|WLAN|802\.11' }
if (-not $w) { Write-Output 'Nenhum adaptador Wi-Fi encontrado. Verifique se o driver está instalado (Gerenciador de Dispositivos).' }
foreach ($a in $w) { Write-Output (""Ativando: "" + $a.Name); Enable-NetAdapter -Name $a.Name -Confirm:$false -ErrorAction SilentlyContinue }
Write-Output 'Reiniciando serviço de Wi-Fi...'; Restart-Service WlanSvc -Force -ErrorAction SilentlyContinue
foreach ($a in $w) { Restart-NetAdapter -Name $a.Name -Confirm:$false -ErrorAction SilentlyContinue }
Write-Output 'Concluído.'"
            },
            new Fix
            {
                Id = "airplane", Group = GConn, Icon = "", Title = "Notebook preso no modo avião",
                Problem = "O modo avião não desliga, ou o botão está cinza e o Wi-Fi/Bluetooth não voltam.",
                Steps = new[] { "Desliga o estado de rádio do sistema", "Reinicia o serviço de Gerenciamento de Rádio", "Ativa os adaptadores sem fio" },
                OpenAfter = "ms-settings:network-airplanemode",
                Script = @"
Set-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\RadioManagement\SystemRadioState' -Name '(default)' -Value 0 -ErrorAction SilentlyContinue
Write-Output 'Reiniciando Gerenciamento de Rádio...'; Restart-Service RmSvc -Force -ErrorAction SilentlyContinue
Get-NetAdapter -ErrorAction SilentlyContinue | Where-Object { $_.Status -eq 'Disabled' -and ($_.PhysicalMediaType -match '802\.11|Wireless|BlueTooth') } | Enable-NetAdapter -Confirm:$false -ErrorAction SilentlyContinue
Write-Output 'Concluído. Se continuar, procure uma tecla de avião (Fn + F2/F12) ou um botão físico no notebook.'"
            },
            new Fix
            {
                Id = "bluetooth", Group = GConn, Icon = "", Title = "Bluetooth",
                Problem = "O Bluetooth não liga, sumiu das configurações ou fones e controles não conectam.",
                Steps = new[] { "Reinicia os serviços de Bluetooth", "Reinicia o adaptador Bluetooth", "Abre as configurações de Bluetooth" },
                OpenAfter = "ms-settings:bluetooth",
                Script = RestartDevices + @"
foreach ($s in 'bthserv','BTAGService','BthAvctpSvc') { Write-Output (""Reiniciando serviço: "" + $s); Set-Service $s -StartupType Manual -ErrorAction SilentlyContinue; Restart-Service $s -Force -ErrorAction SilentlyContinue }
Restart-Class @('Bluetooth')
Write-Output 'Concluído. Se o dispositivo não aparecer, remova-o e pareie de novo.'"
            },

            // ================= SOM, CÂMERA E DISPOSITIVOS =================
            new Fix
            {
                Id = "audio", Group = GDev, Icon = "", Title = "Áudio",
                Problem = "Sem som, \"Nenhum dispositivo de saída de áudio instalado\", som estourando ou o ícone com X vermelho.",
                Steps = new[] { "Reinicia os serviços de áudio do Windows", "Reinicia as placas de som e saídas de áudio" },
                OpenAfter = "ms-settings:sound",
                Script = RestartDevices + @"
foreach ($s in 'AudioEndpointBuilder','Audiosrv') { Write-Output (""Reiniciando serviço: "" + $s); Set-Service $s -StartupType Automatic -ErrorAction SilentlyContinue; Restart-Service $s -Force -ErrorAction SilentlyContinue }
Restart-Class @('MEDIA','AudioEndpoint')
Write-Output 'Concluído. Confira se o dispositivo certo está selecionado na tela de Som.'"
            },
            new Fix
            {
                Id = "mic", Group = GDev, Icon = "", Title = "Microfone",
                Problem = "O microfone não funciona no Discord, jogos ou chamadas, ou aparece como bloqueado.",
                Steps = new[] { "Libera o acesso ao microfone nas configurações de privacidade", "Reinicia os serviços de áudio" },
                OpenAfter = "ms-settings:privacy-microphone",
                Script = @"
foreach ($h in 'HKLM:','HKCU:') { $p = ""$h\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\microphone""; New-Item $p -Force | Out-Null; Set-ItemProperty $p -Name Value -Value 'Allow' }
Write-Output 'Acesso ao microfone liberado.'
foreach ($s in 'AudioEndpointBuilder','Audiosrv') { Restart-Service $s -Force -ErrorAction SilentlyContinue }
Write-Output 'Concluído. Confira o volume de entrada em Som > Entrada.'"
            },
            new Fix
            {
                Id = "camera", Group = GDev, Icon = "", Title = "Câmera",
                Problem = "A câmera não liga, aparece tela preta ou o erro 0xA00F4244 \"não encontramos sua câmera\".",
                Steps = new[] { "Libera o acesso à câmera nas configurações de privacidade", "Reinicia o serviço de câmera (Frame Server)", "Reinicia a câmera" },
                OpenAfter = "ms-settings:privacy-webcam",
                Script = RestartDevices + @"
foreach ($h in 'HKLM:','HKCU:') { $p = ""$h\SOFTWARE\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\webcam""; New-Item $p -Force | Out-Null; Set-ItemProperty $p -Name Value -Value 'Allow' }
Write-Output 'Acesso à câmera liberado.'
Restart-Service FrameServer -Force -ErrorAction SilentlyContinue
Restart-Class @('Camera','Image')
Write-Output 'Concluído. Em notebook, confira se não há uma tampa física ou tecla que desliga a câmera.'"
            },
            new Fix
            {
                Id = "printer", Group = GDev, Icon = "", Title = "Impressora",
                Problem = "Documentos presos na fila, impressora \"offline\" ou que não imprime nada.",
                Steps = new[] { "Para o Spooler de impressão", "Apaga os trabalhos travados na fila", "Liga o Spooler de novo no modo automático" },
                Script = @"
Write-Output 'Parando o Spooler...'; Stop-Service Spooler -Force -ErrorAction SilentlyContinue
Remove-Item ""$env:SystemRoot\System32\spool\PRINTERS\*"" -Force -Recurse -ErrorAction SilentlyContinue
Write-Output 'Fila de impressão limpa.'
Set-Service Spooler -StartupType Automatic; Start-Service Spooler
Write-Output 'Concluído. Se a impressora continuar offline, desligue e ligue ela.'"
            },
            new Fix
            {
                Id = "time", Group = GDev, Icon = "", Title = "Hora e data erradas",
                Problem = "O relógio do Windows está atrasado/adiantado, causando erros de certificado em sites e jogos.",
                Steps = new[] { "Liga o serviço de Horário do Windows", "Sincroniza com o servidor de hora da Microsoft" },
                Script = @"
Set-Service W32Time -StartupType Automatic -ErrorAction SilentlyContinue
Start-Service W32Time -ErrorAction SilentlyContinue
w32tm /config /manualpeerlist:'time.windows.com,0x9 a.ntp.br,0x9' /syncfromflags:manual /update | Out-Null
w32tm /resync /force
Write-Output ('Hora atual: ' + (Get-Date).ToString('dd/MM/yyyy HH:mm:ss'))"
            },

            // ================= SISTEMA E ARQUIVOS =================
            new Fix
            {
                Id = "sfc", Group = GSys, Icon = "", Title = "Arquivos do sistema corrompidos",
                Problem = "Erros estranhos, telas azuis, programas do Windows que não abrem, \"arquivo corrompido\".",
                Steps = new[] { "DISM: baixa da Microsoft e repara a imagem do Windows", "SFC: confere e conserta todos os arquivos protegidos do sistema" },
                Duration = "15 a 40 minutos",
                Warning = "Deixe o PC ligado na tomada e conectado à internet até terminar.",
                Script = @"
Write-Output 'Etapa 1 de 2: DISM (reparando a imagem do Windows)...'
DISM /Online /Cleanup-Image /RestoreHealth
Write-Output ''
Write-Output 'Etapa 2 de 2: SFC (verificando arquivos do sistema)...'
sfc /scannow
Write-Output ''
Write-Output 'Concluído. Se o SFC encontrou e corrigiu arquivos, reinicie o PC.'"
            },
            new Fix
            {
                Id = "dll", Group = GSys, Icon = "", Title = "Erros de DLL (MSVCP140, VCRUNTIME, d3dx9...)",
                Problem = "Jogos e programas não abrem com \"MSVCP140.dll não foi encontrado\", \"VCRUNTIME140.dll\", \"d3dx9_43.dll\" ou parecido.",
                Steps = new[] { "Instala/repara os pacotes Visual C++ (2008 a 2022) pelo winget", "Instala o DirectX End-User Runtime (DLLs antigas de jogos)" },
                Duration = "3 a 10 minutos",
                Warning = "Nunca baixe DLLs soltas de sites: é uma forma comum de pegar vírus.",
                Script = @"
if (-not (Get-Command winget -ErrorAction SilentlyContinue)) { Write-Output 'O winget não está disponível. Atualize o ""Instalador de Aplicativo"" pela Microsoft Store e tente de novo.'; exit }
$ids = 'Microsoft.VCRedist.2015+.x64','Microsoft.VCRedist.2015+.x86','Microsoft.VCRedist.2013.x64','Microsoft.VCRedist.2013.x86','Microsoft.VCRedist.2012.x64','Microsoft.VCRedist.2012.x86','Microsoft.VCRedist.2010.x64','Microsoft.VCRedist.2010.x86','Microsoft.VCRedist.2008.x64','Microsoft.VCRedist.2008.x86','Microsoft.DirectX'
foreach ($id in $ids) {
  Write-Output (""Instalando "" + $id + ""..."")
  winget install --id $id -e --silent --accept-package-agreements --accept-source-agreements --disable-interactivity | Out-Null
}
Write-Output 'Concluído. Tente abrir o programa de novo.'"
            },
            new Fix
            {
                Id = "disk", Group = GSys, Icon = "", Title = "Erros no disco",
                Problem = "Arquivos que somem ou corrompem, o Windows pedindo para \"verificar a unidade\", lentidão ao abrir pastas.",
                Steps = new[] { "Verifica o disco C: sem precisar reiniciar", "Corrige o que der na hora", "Se precisar, agenda a correção completa para o próximo reinício" },
                Duration = "2 a 15 minutos",
                Script = @"
$d = $env:SystemDrive.TrimEnd(':')
Write-Output (""Verificando a unidade "" + $d + "": ..."")
$r = Repair-Volume -DriveLetter $d -Scan -ErrorAction SilentlyContinue
Write-Output (""Resultado: "" + $r)
if ($r -ne 'NoErrorsFound') {
  Write-Output 'Tentando corrigir agora...'
  $f = Repair-Volume -DriveLetter $d -SpotFix -ErrorAction SilentlyContinue
  Write-Output (""Resultado: "" + $f)
}
Write-Output ''
Write-Output 'Saúde dos discos (informação do próprio disco):'
Get-PhysicalDisk | ForEach-Object { Write-Output (""  "" + $_.FriendlyName + "" ("" + $_.MediaType + ""): "" + $_.HealthStatus) }
Write-Output 'Concluído.'"
            },
            new Fix
            {
                Id = "update", Group = GSys, Icon = "", Title = "Windows Update travado",
                Problem = "Atualizações que não baixam, ficam em 0% ou falham com erro (0x80070002, 0x800f0922...).",
                Steps = new[] { "Para os serviços do Windows Update", "Renomeia as pastas de cache (SoftwareDistribution e catroot2)", "Liga os serviços de novo e procura atualizações" },
                Duration = "1 a 3 minutos",
                Script = @"
$svcs = 'wuauserv','bits','cryptsvc','msiserver'
foreach ($s in $svcs) { Write-Output (""Parando "" + $s); Stop-Service $s -Force -ErrorAction SilentlyContinue }
$t = Get-Date -Format 'yyyyMMddHHmmss'
Rename-Item ""$env:SystemRoot\SoftwareDistribution"" ""SoftwareDistribution.old$t"" -ErrorAction SilentlyContinue
Rename-Item ""$env:SystemRoot\System32\catroot2"" ""catroot2.old$t"" -ErrorAction SilentlyContinue
Write-Output 'Cache do Windows Update recriado.'
foreach ($s in $svcs) { Start-Service $s -ErrorAction SilentlyContinue }
UsoClient StartScan 2>$null
Write-Output 'Concluído. Abra Configurações > Windows Update e clique em Verificar atualizações.'",
                OpenAfter = "ms-settings:windowsupdate"
            },
            new Fix
            {
                Id = "start", Group = GSys, Icon = "", Title = "Menu Iniciar e barra de tarefas",
                Problem = "O Iniciar não abre, a barra de tarefas travou, ícones sumiram ou a pesquisa não digita.",
                Steps = new[] { "Reinicia o Iniciar, a pesquisa e a barra de tarefas", "Registra de novo os componentes do Iniciar" },
                Script = @"
Get-AppxPackage -AllUsers Microsoft.Windows.ShellExperienceHost, Microsoft.Windows.StartMenuExperienceHost, MicrosoftWindows.Client.CBS -ErrorAction SilentlyContinue | ForEach-Object {
  Write-Output (""Registrando "" + $_.Name)
  Add-AppxPackage -DisableDevelopmentMode -Register ""$($_.InstallLocation)\AppXManifest.xml"" -ErrorAction SilentlyContinue
}
foreach ($p in 'StartMenuExperienceHost','SearchHost','ShellExperienceHost','explorer') { Stop-Process -Name $p -Force -ErrorAction SilentlyContinue }
Start-Sleep 3
if (-not (Get-Process explorer -ErrorAction SilentlyContinue)) { Start-Process explorer }
Write-Output 'Concluído.'"
            },
            new Fix
            {
                Id = "explorer", Group = GSys, Icon = "", Title = "Explorador de arquivos",
                Problem = "O Explorador trava, fecha sozinho, demora para abrir pastas ou mostra as pastas com visual bagunçado.",
                Steps = new[] { "Apaga as configurações salvas de visualização das pastas", "Reinicia o Explorador" },
                Script = @"
Remove-Item 'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\BagMRU' -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item 'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\Shell\Bags' -Recurse -Force -ErrorAction SilentlyContinue
Write-Output 'Visualizações das pastas redefinidas.'
Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
Start-Sleep 3
if (-not (Get-Process explorer -ErrorAction SilentlyContinue)) { Start-Process explorer }
Write-Output 'Concluído.'"
            },
            new Fix
            {
                Id = "icons", Group = GSys, Icon = "", Title = "Ícones e miniaturas",
                Problem = "Ícones em branco ou errados, miniaturas de fotos e vídeos que não aparecem.",
                Steps = new[] { "Fecha o Explorador", "Apaga o cache de ícones e de miniaturas (o Windows recria)", "Abre o Explorador de novo" },
                Script = @"
Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
Start-Sleep 2
Remove-Item ""$env:LOCALAPPDATA\IconCache.db"" -Force -ErrorAction SilentlyContinue
Remove-Item ""$env:LOCALAPPDATA\Microsoft\Windows\Explorer\iconcache_*.db"" -Force -ErrorAction SilentlyContinue
Remove-Item ""$env:LOCALAPPDATA\Microsoft\Windows\Explorer\thumbcache_*.db"" -Force -ErrorAction SilentlyContinue
Write-Output 'Cache de ícones e miniaturas apagado.'
Start-Process explorer
ie4uinit.exe -show
Write-Output 'Concluído. Os ícones podem levar alguns segundos para aparecer.'"
            },
            new Fix
            {
                Id = "clipboard", Group = GSys, Icon = "", Title = "Copiar e colar",
                Problem = "Ctrl+C / Ctrl+V pararam de funcionar ou colam coisa antiga.",
                Steps = new[] { "Limpa a área de transferência", "Reinicia o serviço da área de transferência", "Reinicia o Explorador" },
                Script = @"
Set-Clipboard -Value ' ' -ErrorAction SilentlyContinue
Get-Service cbdhsvc_* -ErrorAction SilentlyContinue | Restart-Service -Force -ErrorAction SilentlyContinue
Stop-Process -Name rdpclip -Force -ErrorAction SilentlyContinue
Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
Start-Sleep 3
if (-not (Get-Process explorer -ErrorAction SilentlyContinue)) { Start-Process explorer }
Write-Output 'Concluído.'"
            },
            new Fix
            {
                Id = "blackscreen", Group = GSys, Icon = "", Title = "Tela preta depois de entrar",
                Problem = "Depois do login só aparece o cursor numa tela preta, sem barra de tarefas.",
                Steps = new[] { "Confere se o Windows está configurado para abrir o Explorador (vírus às vezes trocam)", "Corrige o serviço de preparação de apps", "Abre o Explorador" },
                Script = @"
$k = 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon'
$shell = (Get-ItemProperty $k).Shell
Write-Output (""Shell configurado: "" + $shell)
if ($shell -ne 'explorer.exe') { Set-ItemProperty $k -Name Shell -Value 'explorer.exe'; Write-Output 'Corrigido para explorer.exe (o valor anterior era suspeito; faça uma verificação na área Segurança).' }
Remove-ItemProperty 'HKCU:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Winlogon' -Name Shell -ErrorAction SilentlyContinue
Set-Service AppReadiness -StartupType Manual -ErrorAction SilentlyContinue
if (-not (Get-Process explorer -ErrorAction SilentlyContinue)) { Start-Process explorer }
Write-Output 'Concluído.'"
            },
            new Fix
            {
                Id = "shutdown", Group = GSys, Icon = "", Title = "PC não desliga ou demora para desligar",
                Problem = "O PC reinicia em vez de desligar, fica com a tela preta ligado, ou leva minutos para desligar.",
                Steps = new[] { "Desliga a Inicialização Rápida (principal causa)", "Faz o Windows fechar programas travados automaticamente ao desligar", "Reduz o tempo de espera de programas que não respondem" },
                Script = @"
Set-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Power' -Name HiberbootEnabled -Value 0 -Type DWord
Write-Output 'Inicialização Rápida desativada.'
Set-ItemProperty 'HKCU:\Control Panel\Desktop' -Name AutoEndTasks -Value '1'
Set-ItemProperty 'HKCU:\Control Panel\Desktop' -Name WaitToKillAppTimeout -Value '5000'
Set-ItemProperty 'HKCU:\Control Panel\Desktop' -Name HungAppTimeout -Value '3000'
Write-Output 'Programas travados serão fechados automaticamente ao desligar.'
Write-Output 'Concluído.'"
            },
            new Fix
            {
                Id = "installer", Group = GSys, Icon = "", Title = "Windows Installer (.msi)",
                Problem = "Instaladores .msi não abrem ou dão erro \"o serviço Windows Installer não pôde ser acessado\".",
                Steps = new[] { "Registra de novo o Windows Installer", "Liga o serviço msiserver" },
                Script = @"
msiexec /unregister
Start-Sleep 1
msiexec /regserver
Set-Service msiserver -StartupType Manual -ErrorAction SilentlyContinue
Start-Service msiserver -ErrorAction SilentlyContinue
Write-Output 'Concluído.'"
            },
            new Fix
            {
                Id = "hello", Group = GSys, Icon = "", Title = "Windows Hello / PIN",
                Problem = "\"Algo aconteceu e seu PIN não está disponível\", digital ou reconhecimento facial que não funcionam.",
                Steps = new[] { "Apaga os dados corrompidos do PIN (pasta Ngc)", "Abre a tela para criar um PIN novo" },
                Warning = "Você vai precisar criar o PIN de novo. Entre com a senha da conta Microsoft ou local depois de reiniciar.",
                OpenAfter = "ms-settings:signinoptions",
                Script = @"
$ngc = ""$env:SystemRoot\ServiceProfiles\LocalService\AppData\Local\Microsoft\Ngc""
if (Test-Path $ngc) {
  takeown /f $ngc /a /r /d S 2>$null | Out-Null
  takeown /f $ngc /a /r /d Y 2>$null | Out-Null
  icacls $ngc /grant '*S-1-5-32-544:F' /t /c 2>$null | Out-Null
  Remove-Item ""$ngc\*"" -Recurse -Force -ErrorAction SilentlyContinue
  Write-Output 'Dados do PIN apagados.'
} else { Write-Output 'Pasta do PIN não encontrada (nenhum PIN configurado).' }
Write-Output 'Concluído. Reinicie o PC e crie um PIN novo em Opções de entrada.'"
            },

            // ================= APPS, LOJA E JOGOS =================
            new Fix
            {
                Id = "store", Group = GApps, Icon = "", Title = "Microsoft Store",
                Problem = "A Store não abre, não baixa, fica carregando ou dá erro ao instalar apps.",
                Steps = new[] { "Limpa o cache da Store (wsreset)", "Registra a Store de novo", "Liga o serviço de instalação" },
                Duration = "1 a 2 minutos",
                Script = @"
Write-Output 'Limpando cache da Store...'
Start-Process wsreset.exe -Wait -ErrorAction SilentlyContinue
Get-AppxPackage -AllUsers Microsoft.WindowsStore | ForEach-Object { Add-AppxPackage -DisableDevelopmentMode -Register ""$($_.InstallLocation)\AppXManifest.xml"" -ErrorAction SilentlyContinue }
Set-Service InstallService -StartupType Manual -ErrorAction SilentlyContinue
Start-Service InstallService -ErrorAction SilentlyContinue
Write-Output 'Concluído.'"
            },
            new Fix
            {
                Id = "apps", Group = GApps, Icon = "", Title = "Aplicativos do Windows",
                Problem = "Calculadora, Fotos, Configurações ou outros apps do Windows não abrem ou fecham sozinhos.",
                Steps = new[] { "Registra de novo todos os apps do Windows" },
                Duration = "2 a 10 minutos",
                Warning = "Aparecem alguns avisos de erro durante o processo; isso é normal.",
                Script = @"
$apps = Get-AppxPackage -AllUsers | Where-Object { $_.InstallLocation -and -not $_.IsFramework }
$i = 0
foreach ($a in $apps) {
  $i++
  Write-Output (""["" + $i + ""/"" + $apps.Count + ""] "" + $a.Name)
  Add-AppxPackage -DisableDevelopmentMode -Register ""$($a.InstallLocation)\AppXManifest.xml"" -ErrorAction SilentlyContinue
}
Write-Output 'Concluído.'"
            },
            new Fix
            {
                Id = "xbox_services", Group = GApps, Icon = "", Title = "Serviços do Xbox",
                Problem = "Jogos do Game Pass não abrem, não salvam na nuvem, ou o login do Xbox falha.",
                Steps = new[] { "Liga de novo os serviços do Xbox (inclusive se foram desativados pelo otimizador)", "Reinicia os Gaming Services" },
                Script = @"
foreach ($s in 'XblAuthManager','XblGameSave','XboxNetApiSvc','XboxGipSvc','GamingServices','GamingServicesNet') {
  if (Get-Service $s -ErrorAction SilentlyContinue) { Write-Output (""Ativando "" + $s); Set-Service $s -StartupType Manual -ErrorAction SilentlyContinue; Start-Service $s -ErrorAction SilentlyContinue }
}
Write-Output 'Concluído.'"
            },
            new Fix
            {
                Id = "xbox_app", Group = GApps, Icon = "", Title = "App Xbox",
                Problem = "O app Xbox não abre, trava na tela de carregamento ou não instala jogos.",
                Steps = new[] { "Redefine o app Xbox (apaga o cache dele)", "Registra de novo o app Xbox e os Gaming Services" },
                Script = @"
Get-AppxPackage Microsoft.GamingApp -ErrorAction SilentlyContinue | Reset-AppxPackage -ErrorAction SilentlyContinue
Get-AppxPackage -AllUsers Microsoft.GamingApp, Microsoft.GamingServices, Microsoft.XboxIdentityProvider -ErrorAction SilentlyContinue | ForEach-Object {
  Write-Output (""Registrando "" + $_.Name)
  Add-AppxPackage -DisableDevelopmentMode -Register ""$($_.InstallLocation)\AppXManifest.xml"" -ErrorAction SilentlyContinue
}
Write-Output 'Concluído. Se continuar, reinstale os Gaming Services pela Microsoft Store.'"
            },
            new Fix
            {
                Id = "defender", Group = GApps, Icon = "", Title = "Windows Defender / Segurança do Windows",
                Problem = "A Segurança do Windows não abre, a proteção em tempo real não liga ou aparece \"gerenciado pela organização\" sem motivo.",
                Steps = new[] { "Remove políticas que desativam o Defender (vírus costumam criar)", "Liga a proteção em tempo real", "Atualiza as definições de vírus", "Redefine o app Segurança do Windows" },
                Script = @"
foreach ($p in 'HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender','HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection') {
  foreach ($n in 'DisableAntiSpyware','DisableAntiVirus','DisableRealtimeMonitoring','DisableBehaviorMonitoring','DisableOnAccessProtection','DisableScanOnRealtimeEnable') {
    if (Get-ItemProperty $p -Name $n -ErrorAction SilentlyContinue) { Remove-ItemProperty $p -Name $n -ErrorAction SilentlyContinue; Write-Output (""Política removida: "" + $n) }
  }
}
Set-MpPreference -DisableRealtimeMonitoring $false -ErrorAction SilentlyContinue
Write-Output 'Atualizando definições...'
& ""$env:ProgramFiles\Windows Defender\MpCmdRun.exe"" -SignatureUpdate 2>$null | Out-Null
Get-AppxPackage Microsoft.SecHealthUI -AllUsers -ErrorAction SilentlyContinue | Reset-AppxPackage -ErrorAction SilentlyContinue
Write-Output 'Concluído. Se outro antivírus estiver instalado, é normal o Defender ficar desligado.'"
            },
            new Fix
            {
                Id = "search", Group = GApps, Icon = "", Title = "Pesquisa do Windows",
                Problem = "A pesquisa não encontra arquivos ou programas, ou o SearchIndexer usa muito disco/CPU.",
                Steps = new[] { "Liga o serviço Windows Search", "Apaga o índice antigo e manda o Windows refazer" },
                Warning = "A pesquisa pode ficar incompleta por algumas horas enquanto o índice é refeito.",
                Script = @"
Stop-Service WSearch -Force -ErrorAction SilentlyContinue
Set-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows Search' -Name SetupCompletedSuccessfully -Value 0 -ErrorAction SilentlyContinue
Remove-Item ""$env:ProgramData\Microsoft\Search\Data\Applications\Windows\Windows.edb"" -Force -ErrorAction SilentlyContinue
Remove-Item ""$env:ProgramData\Microsoft\Search\Data\Applications\Windows\Windows.db"" -Force -ErrorAction SilentlyContinue
Set-Service WSearch -StartupType Automatic -ErrorAction SilentlyContinue
Start-Service WSearch -ErrorAction SilentlyContinue
Write-Output 'Índice apagado. O Windows vai refazer em segundo plano.'"
            },

            // ================= LENTIDÃO E TRAVAMENTOS =================
            new Fix
            {
                Id = "cpu", Group = GPerf, Icon = "", Title = "Uso alto de CPU",
                Problem = "O processador fica em 80–100% mesmo sem nada aberto, o PC esquenta e a ventoinha não para.",
                Steps = new[] { "Mostra os programas que mais usam o processador agora", "Reinicia o WMI Provider Host (causa comum)", "Dá dicas do que fazer com o resultado" },
                Script = @"
Write-Output 'Medindo por 3 segundos...'
$n = [Environment]::ProcessorCount
Get-CimInstance Win32_PerfFormattedData_PerfProc_Process -ErrorAction SilentlyContinue | Out-Null
Start-Sleep 3
$top = Get-CimInstance Win32_PerfFormattedData_PerfProc_Process -ErrorAction SilentlyContinue | Where-Object { $_.Name -notin '_Total','Idle' } | Sort-Object PercentProcessorTime -Descending | Select-Object -First 10
Write-Output ''
Write-Output 'Programas que mais usam CPU:'
foreach ($p in $top) { Write-Output (""  {0,-32} {1,5:N1}%"" -f $p.Name, ($p.PercentProcessorTime / $n)) }
Get-Process WmiPrvSE -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Write-Output ''
Write-Output 'Dicas: um processo desconhecido usando muita CPU pode ser minerador -> use Segurança > Processos e mineração.'
Write-Output 'Se for o navegador, feche abas. Se for ""Antimalware Service Executable"", espere a verificação do Defender terminar.'"
            },
            new Fix
            {
                Id = "ram", Group = GPerf, Icon = "", Title = "Uso alto de memória RAM",
                Problem = "A memória fica sempre acima de 85–90%, o PC fica lento e os jogos engasgam.",
                Steps = new[] { "Mostra os programas que mais usam memória", "Libera a memória com o módulo de RAM do TH Suite" },
                Script = @"
Write-Output 'Programas que mais usam memória:'
Get-Process | Sort-Object WorkingSet64 -Descending | Select-Object -First 10 | ForEach-Object { Write-Output (""  {0,-32} {1,8:N0} MB"" -f $_.ProcessName, ($_.WorkingSet64 / 1MB)) }
$os = Get-CimInstance Win32_OperatingSystem
Write-Output ''
Write-Output (""Memória em uso antes: {0:N0}%"" -f ((1 - $os.FreePhysicalMemory / $os.TotalVisibleMemorySize) * 100))"
            },
            new Fix
            {
                Id = "disk100", Group = GPerf, Icon = "", Title = "Disco em 100%",
                Problem = "O Gerenciador de Tarefas mostra o disco em 100% e tudo demora muito para abrir.",
                Steps = new[] { "Mostra os programas que mais usam o disco", "Mostra o tipo e a saúde do disco", "Faz o TRIM do SSD (otimização)" },
                Script = @"
Write-Output 'Medindo por 3 segundos...'
Get-CimInstance Win32_PerfFormattedData_PerfProc_Process -ErrorAction SilentlyContinue | Out-Null
Start-Sleep 3
Write-Output 'Programas que mais usam o disco:'
Get-CimInstance Win32_PerfFormattedData_PerfProc_Process -ErrorAction SilentlyContinue | Where-Object { $_.Name -notin '_Total','Idle' } | Sort-Object IODataBytesPersec -Descending | Select-Object -First 8 | ForEach-Object { Write-Output (""  {0,-32} {1,8:N1} MB/s"" -f $_.Name, ($_.IODataBytesPersec / 1MB)) }
Write-Output ''
Get-PhysicalDisk | ForEach-Object { Write-Output (""Disco: "" + $_.FriendlyName + "" | Tipo: "" + $_.MediaType + "" | Saúde: "" + $_.HealthStatus) }
$d = $env:SystemDrive.TrimEnd(':')
if ((Get-PhysicalDisk | Where-Object MediaType -eq 'SSD')) { Write-Output 'Otimizando SSD (TRIM)...'; Optimize-Volume -DriveLetter $d -ReTrim -ErrorAction SilentlyContinue }
Write-Output ''
Write-Output 'Dicas: em HD (disco mecânico) é comum o disco ficar em 100%. No Otimizador, os ajustes ""Desativar SysMain"" e ""Desativar indexação"" ajudam. A melhor solução é trocar por um SSD.'"
            },
        };
    }
}

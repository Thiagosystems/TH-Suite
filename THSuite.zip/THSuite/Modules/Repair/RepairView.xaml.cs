using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;

namespace THSuite.Repair
{
    public partial class RepairView : UserControl
    {
        readonly List<Fix> _fixes = Fixes.Build();
        Fix? _current;
        CancellationTokenSource? _cts;
        bool _running;

        /// <summary>Limpeza de memória do módulo de RAM (definido pela janela principal).</summary>
        public Func<Task<string>>? CleanMemory { get; set; }

        public RepairView()
        {
            InitializeComponent();
            foreach (var f in _fixes) f.Title = Lang.T(f.Title);
            var view = (ListCollectionView)CollectionViewSource.GetDefaultView(_fixes);
            view.GroupDescriptions.Add(new PropertyGroupDescription(nameof(Fix.Group)));
            LstFixes.ItemsSource = view;

            var ram = _fixes.FirstOrDefault(f => f.Id == "ram");
            if (ram != null)
                ram.After = async log =>
                {
                    if (CleanMemory == null) return;
                    log("");
                    log("Liberando memória...");
                    log(await CleanMemory());
                };

            BuildTools();
            LstFixes.SelectedIndex = 0;
        }

        public void ShowTab(string tab)
        {
            if (tab == "tools") { TabTools.IsChecked = true; return; }
            TabFixes.IsChecked = true;
            var f = _fixes.FirstOrDefault(x => x.Id == tab);
            if (f != null) LstFixes.SelectedItem = f;
        }

        public void Shutdown() => _cts?.Cancel();

        public IReadOnlyList<Fix> AllFixes => _fixes;

        void Tab_Checked(object sender, RoutedEventArgs e)
        {
            if (PageFixes == null) return;
            PageFixes.Visibility = sender == TabFixes ? Visibility.Visible : Visibility.Collapsed;
            PageTools.Visibility = sender == TabTools ? Visibility.Visible : Visibility.Collapsed;
        }

        // =====================================================================
        //  Reparos
        // =====================================================================

        void LstFixes_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (LstFixes.SelectedItem is not Fix f) return;
            if (_running && f != _current) { LstFixes.SelectedItem = _current; return; }
            _current = f;
            TxtFixIcon.Text = f.Icon;
            TxtFixTitle.Text = f.Title;
            TxtFixDuration.Text = "Duração: " + f.Duration + (f.NeedsRestart ? " · pede reiniciar o PC no final" : "");
            TxtFixProblem.Text = f.Problem;
            TxtFixSteps.Text = f.StepsText;
            TxtFixWarn.Text = f.Warning;
            FixWarn.Visibility = f.Warning.Length > 0 ? Visibility.Visible : Visibility.Collapsed;
            if (!_running)
            {
                TxtFixLog.Text = "";
                TxtLogHint.Visibility = Visibility.Visible;
                TxtFixState.Text = f.Status;
            }
        }

        async void RunFix_Click(object sender, RoutedEventArgs e)
        {
            if (_current == null || _running) return;
            var f = _current;
            if (f.Warning.Length > 0 && !Host.Confirm($"{f.Title}\n\n{f.Warning}\n\nExecutar o reparo?")) return;

            _running = true;
            _cts = new CancellationTokenSource();
            BtnRunFix.IsEnabled = false;
            BtnStopFix.Visibility = Visibility.Visible;
            TxtFixLog.Text = "";
            TxtLogHint.Visibility = Visibility.Collapsed;
            TxtFixState.Text = "Executando...";
            Append($"> {f.Title}  ({DateTime.Now:HH:mm:ss})");

            int code = -1;
            try
            {
                var r = await Cmd.PowerShellAsync(f.Script, line => Dispatcher.InvokeAsync(() => Append(line)), 60 * 60 * 1000, _cts.Token);
                code = r.Code;
                if (f.After != null && !_cts.IsCancellationRequested) await f.After(Append);
            }
            catch (Exception ex) { Append("Erro: " + ex.Message); }

            bool cancelled = _cts.IsCancellationRequested;
            Append("");
            Append(cancelled ? "Reparo interrompido." : "Reparo concluído.");
            f.Status = cancelled ? "" : $"Executado às {DateTime.Now:HH:mm}";
            if (!cancelled) Activity.Log("Reparos", "Reparo executado: " + f.Title);
            TxtFixState.Text = cancelled ? "Interrompido" : "Concluído";
            BtnRunFix.IsEnabled = true;
            BtnStopFix.Visibility = Visibility.Collapsed;
            _running = false;

            if (!cancelled)
            {
                if (f.OpenAfter.Length > 0) Cmd.Open(f.OpenAfter);
                if (f.NeedsRestart && Host.Confirm("Este reparo precisa reiniciar o PC para terminar.\n\nReiniciar agora? (salve seus trabalhos antes)"))
                    Cmd.Open("shutdown.exe", "/r /t 5");
            }
        }

        void StopFix_Click(object sender, RoutedEventArgs e) => _cts?.Cancel();

        void Append(string line)
        {
            TxtFixLog.AppendText((TxtFixLog.Text.Length > 0 ? "\n" : "") + line);
            TxtFixLog.ScrollToEnd();
        }

        void CopyLog_Click(object sender, RoutedEventArgs e)
        {
            try { if (TxtFixLog.Text.Length > 0) Clipboard.SetText(TxtFixLog.Text); } catch { }
        }

        // =====================================================================
        //  Ferramentas rápidas
        // =====================================================================

        void BuildTools()
        {
            Section("PONTO DE RESTAURAÇÃO E EXPLORADOR");
            var p = Panel();
            Tool(p, "", "Criar ponto de restauração", "Uma \"foto\" do sistema para voltar se algo der errado.", async () =>
            {
                Host.Info("O ponto de restauração vai ser criado em segundo plano (até 1 minuto). Você recebe um aviso quando terminar.");
                var (ok, m) = await Cmd.CreateRestorePointAsync("TH Suite - ponto manual");
                Host.Notify(ok ? "Ponto de restauração criado." : m, null, "TH Suite", !ok);
            });
            Tool(p, "", "Restauração do Sistema", "Volta o Windows para um ponto de restauração anterior.", () => { Cmd.Open("rstrui.exe"); return Task.CompletedTask; });
            Tool(p, "", "Reiniciar o Explorador", "Recarrega a barra de tarefas e a área de trabalho.", Cmd.RestartExplorerAsync);
            Tool(p, "", "Fechar o Explorador", "Fecha a barra de tarefas e a área de trabalho.", async () =>
            {
                await Cmd.RunAsync("taskkill.exe", "/f /im explorer.exe");
            });
            Tool(p, "", "Iniciar o Explorador", "Abre a barra de tarefas se ela sumiu.", () => { Cmd.Open("explorer.exe"); return Task.CompletedTask; });
            Tool(p, "", "Limpar arquivos temporários", "Abre a limpeza de disco do TH Suite.", () => { Host.Navigate("cleaner", "clean"); return Task.CompletedTask; });

            Section("REINICIAR E DESLIGAR");
            p = Panel();
            Tool(p, "", "Reiniciar o PC", "Reinicia em 5 segundos.", () => Confirmed("Reiniciar o PC agora?", "shutdown.exe", "/r /t 5"));
            Tool(p, "", "Desligar o PC", "Desliga em 5 segundos.", () => Confirmed("Desligar o PC agora?", "shutdown.exe", "/s /t 5"));
            Tool(p, "", "Reiniciar na BIOS / UEFI", "Abre a configuração da placa-mãe ao reiniciar.", () => Confirmed("Reiniciar direto na BIOS/UEFI?\n\nFunciona apenas em PCs com UEFI.", "shutdown.exe", "/r /fw /t 5"));
            Tool(p, "", "Reiniciar no modo de recuperação", "Opções avançadas: modo de segurança, restauração, reparo de inicialização.", () => Confirmed("Reiniciar nas opções avançadas de inicialização?", "shutdown.exe", "/r /o /t 5"));

            Section("ATALHOS DO WINDOWS");
            p = Panel();
            Tool(p, "", "Gerenciador de Tarefas", "Programas abertos, desempenho e inicialização.", Open("taskmgr.exe"));
            Tool(p, "", "Gerenciador de Dispositivos", "Drivers e dispositivos do PC.", Open("devmgmt.msc"));
            Tool(p, "", "Serviços", "Todos os serviços do Windows.", Open("services.msc"));
            Tool(p, "", "Editor do Registro", "Para usuários avançados.", Open("regedit.exe"));
            Tool(p, "", "Informações do Sistema", "Detalhes de hardware e Windows.", Open("msinfo32.exe"));
            Tool(p, "", "Monitor de Recursos", "CPU, disco, rede e memória por programa.", Open("resmon.exe"));
            Tool(p, "", "Visualizador de Eventos", "Registros de erros do Windows.", Open("eventvwr.msc"));
            Tool(p, "", "Painel de Controle", "Configurações clássicas do Windows.", Open("control.exe"));
            Tool(p, "", "Opções de energia", "Planos de energia do Windows.", Open("powercfg.cpl"));
            Tool(p, "", "Programas e Recursos", "Desinstalador clássico do Windows.", Open("appwiz.cpl"));
            Tool(p, "", "Firewall do Windows", "Regras e estado do firewall.", Open("wf.msc"));
            Tool(p, "", "Limpeza de Disco do Windows", "A ferramenta original da Microsoft.", Open("cleanmgr.exe"));
        }

        static Func<Task> Open(string target) => () => { Cmd.Open(target); return Task.CompletedTask; };

        static Task Confirmed(string question, string exe, string args)
        {
            if (Host.Confirm(question + "\n\nSalve seus trabalhos antes.")) Cmd.Open(exe, args);
            return Task.CompletedTask;
        }

        void Section(string title) =>
            ToolsHost.Children.Add(new TextBlock { Text = title, Style = (Style)FindResource("Section"), Margin = new Thickness(0, ToolsHost.Children.Count == 0 ? 0 : 8, 0, 8) });

        WrapPanel Panel()
        {
            var w = new WrapPanel();
            ToolsHost.Children.Add(w);
            return w;
        }

        void Tool(WrapPanel host, string icon, string title, string desc, Func<Task> action)
        {
            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(34) });
            grid.ColumnDefinitions.Add(new ColumnDefinition());
            var ico = new TextBlock { Text = icon, FontFamily = new FontFamily("Segoe MDL2 Assets"), FontSize = 17, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0, 2, 0, 0) };
            ico.SetResourceReference(TextBlock.ForegroundProperty, "AccentSolidBrush");
            grid.Children.Add(ico);
            var sp = new StackPanel();
            var t = new TextBlock { Text = title, FontSize = 12.5, FontWeight = FontWeights.SemiBold, TextWrapping = TextWrapping.Wrap };
            t.SetResourceReference(TextBlock.ForegroundProperty, "TextBrush");
            var d = new TextBlock { Text = desc, FontSize = 11, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 0) };
            d.SetResourceReference(TextBlock.ForegroundProperty, "MutedBrush");
            sp.Children.Add(t);
            sp.Children.Add(d);
            Grid.SetColumn(sp, 1);
            grid.Children.Add(sp);

            var b = new Button { Style = (Style)FindResource("ToolButton"), Content = grid, HorizontalContentAlignment = HorizontalAlignment.Stretch };
            b.Click += async (_, _) =>
            {
                b.IsEnabled = false;
                try { await action(); } catch { }
                b.IsEnabled = true;
            };
            host.Children.Add(b);
        }
    }
}

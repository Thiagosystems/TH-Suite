using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace THSuite.Apps
{
    public class AppItem : Bindable
    {
        public string Name { get; init; } = "";
        public string Id { get; init; } = "";
        public string Source { get; init; } = "winget";
        public string Category { get; init; } = "";
        public string Description { get; init; } = "";
        public string Version { get; set; } = "";
        public string Available { get; set; } = "";

        bool _checked, _installed;
        string _status = "";
        public bool IsChecked { get => _checked; set => Set(ref _checked, value); }
        public bool Installed { get => _installed; set { if (Set(ref _installed, value)) OnChanged(nameof(StateText)); } }
        public string Status { get => _status; set => Set(ref _status, value); }
        public string StateText => Installed ? "Instalado" : "";
        public string VersionText => Available.Length > 0 ? $"{Version}  →  {Available}" : Version;
    }

    /// <summary>Gerenciador de pacotes oficial do Windows (winget).</summary>
    public static class Winget
    {
        const string Common = "--accept-source-agreements --disable-interactivity";

        public static async Task<bool> AvailableAsync()
        {
            var (code, _) = await Cmd.RunAsync("winget.exe", "--version", null, 15000);
            return code == 0;
        }

        /// <summary>Lê a tabela de texto que o winget imprime (as colunas começam onde começam as palavras do cabeçalho).</summary>
        static List<string[]> Table(string output)
        {
            var rows = new List<string[]>();
            var lines = output.Replace("\r\n", "\n").Split('\n')
                              .Select(l => { int i = l.LastIndexOf('\r'); return i >= 0 ? l[(i + 1)..] : l; })
                              .ToList();
            int dash = lines.FindIndex(l => Regex.IsMatch(l.Trim(), "^-{10,}$"));
            if (dash < 1) return rows;
            string header = lines[dash - 1];
            // ignora restos de animação antes do cabeçalho
            int first = header.IndexOfAny("ABCDEFGHIJKLMNOPQRSTUVWXYZÁÉÍÓÚabcdefghijklmnopqrstuvwxyz".ToCharArray());
            if (first < 0) return rows;
            var starts = new List<int>();
            for (int i = first; i < header.Length; i++)
                if (header[i] != ' ' && (i == first || header[i - 1] == ' ')) starts.Add(i);
            if (starts.Count < 3) return rows;

            for (int r = dash + 1; r < lines.Count; r++)
            {
                string l = lines[r];
                if (l.Trim().Length == 0) break;
                var cols = new string[starts.Count];
                for (int c = 0; c < starts.Count; c++)
                {
                    int s = starts[c];
                    if (s >= l.Length) { cols[c] = ""; continue; }
                    int e = c + 1 < starts.Count ? Math.Min(starts[c + 1], l.Length) : l.Length;
                    cols[c] = l[s..e].Trim();
                }
                if (cols[1].Length == 0 || cols[1].Contains(' ')) break; // fim da tabela
                rows.Add(cols);
            }
            return rows;
        }

        /// <summary>Programas com atualização disponível.</summary>
        public static async Task<List<AppItem>> UpgradesAsync()
        {
            var (_, o) = await Cmd.RunAsync("winget.exe", $"upgrade --include-unknown {Common}", null, 180000);
            return Table(o).Where(c => c.Length >= 4 && !c[1].EndsWith("…"))
                .Select(c => new AppItem
                {
                    Name = c[0], Id = c[1], Version = c[2], Available = c[3],
                    Source = c.Length >= 5 && c[4].Length > 0 ? c[4] : "winget",
                    IsChecked = true
                }).ToList();
        }

        /// <summary>Ids de tudo que o winget reconhece como instalado.</summary>
        public static async Task<HashSet<string>> InstalledIdsAsync()
        {
            var (_, o) = await Cmd.RunAsync("winget.exe", $"list {Common}", null, 180000);
            return new HashSet<string>(Table(o).Select(c => c[1]), StringComparer.OrdinalIgnoreCase);
        }

        public static Task<(int Code, string Output)> UpgradeAsync(AppItem a, Action<string>? log, CancellationToken ct = default) =>
            Cmd.RunAsync("winget.exe", $"upgrade --id \"{a.Id}\" -e --silent --accept-package-agreements {Common}", log, 30 * 60000, ct);

        public static Task<(int Code, string Output)> InstallAsync(AppItem a, Action<string>? log, CancellationToken ct = default) =>
            Cmd.RunAsync("winget.exe", $"install --id \"{a.Id}\" -e --source {a.Source} --silent --accept-package-agreements {Common}", log, 30 * 60000, ct);

        /// <summary>Linhas de progresso (barras e porcentagens) não vão para o registro.</summary>
        public static bool IsNoise(string line)
        {
            string t = line.Trim();
            return t.Length == 0 || t.Length <= 2 || Regex.IsMatch(t, @"^[\-\\\|/ ]+$") || t.Contains('█') || t.Contains('▒');
        }
    }

    public static class AppCatalog
    {
        public static List<AppItem> Build()
        {
            var l = new List<AppItem>();
            void A(string cat, string name, string id, string desc, string source = "winget") =>
                l.Add(new AppItem { Category = cat, Name = name, Id = id, Description = desc, Source = source });

            A("Navegadores", "Google Chrome", "Google.Chrome", "O navegador mais usado");
            A("Navegadores", "Mozilla Firefox", "Mozilla.Firefox", "Navegador focado em privacidade");
            A("Navegadores", "Brave", "Brave.Brave", "Bloqueia anúncios sozinho");
            A("Navegadores", "Opera GX", "Opera.OperaGX", "Navegador para gamers");
            A("Comunicação", "Discord", "Discord.Discord", "Voz e chat para jogos");
            A("Comunicação", "WhatsApp", "9NKSQGP7F2NH", "WhatsApp para Windows", "msstore");
            A("Comunicação", "Telegram", "Telegram.TelegramDesktop", "Mensagens");
            A("Comunicação", "Zoom", "Zoom.Zoom", "Reuniões por vídeo");
            A("Comunicação", "Microsoft Teams", "Microsoft.Teams", "Reuniões e chat de trabalho");
            A("Jogos", "Steam", "Valve.Steam", "Loja de jogos da Valve");
            A("Jogos", "Epic Games", "EpicGames.EpicGamesLauncher", "Jogos grátis toda semana");
            A("Jogos", "EA app", "ElectronicArts.EADesktop", "Jogos da EA (FC, Battlefield...)");
            A("Jogos", "Ubisoft Connect", "Ubisoft.Connect", "Jogos da Ubisoft");
            A("Jogos", "GOG Galaxy", "GOG.Galaxy", "Jogos sem DRM");
            A("Jogos", "Battle.net", "Blizzard.BattleNet", "Jogos da Blizzard");
            A("Mídia", "VLC", "VideoLAN.VLC", "Toca qualquer vídeo");
            A("Mídia", "Spotify", "Spotify.Spotify", "Música");
            A("Mídia", "OBS Studio", "OBSProject.OBSStudio", "Gravar a tela e fazer lives");
            A("Mídia", "K-Lite Codec Pack", "CodecGuide.K-LiteCodecPack.Standard", "Codecs de vídeo e áudio");
            A("Mídia", "Audacity", "Audacity.Audacity", "Editor de áudio");
            A("Mídia", "HandBrake", "HandBrake.HandBrake", "Converter vídeos");
            A("Utilitários", "7-Zip", "7zip.7zip", "Abre .zip, .rar, .7z");
            A("Utilitários", "WinRAR", "RARLab.WinRAR", "Compactador");
            A("Utilitários", "Notepad++", "Notepad++.Notepad++", "Editor de texto");
            A("Utilitários", "Everything", "voidtools.Everything", "Acha qualquer arquivo na hora");
            A("Utilitários", "PowerToys", "Microsoft.PowerToys", "Ferramentas extras da Microsoft");
            A("Utilitários", "ShareX", "ShareX.ShareX", "Capturas de tela avançadas");
            A("Utilitários", "AnyDesk", "AnyDeskSoftwareGmbH.AnyDesk", "Acesso remoto");
            A("Utilitários", "qBittorrent", "qBittorrent.qBittorrent", "Torrent sem anúncios");
            A("Hardware", "CPU-Z", "CPUID.CPU-Z", "Detalhes do processador e memória");
            A("Hardware", "HWiNFO", "REALiX.HWiNFO", "Todos os sensores do PC");
            A("Hardware", "CrystalDiskInfo", "CrystalDewWorld.CrystalDiskInfo", "Saúde dos discos");
            A("Hardware", "MSI Afterburner", "Guru3D.Afterburner", "Overclock e monitor da placa de vídeo");
            A("Escritório", "LibreOffice", "TheDocumentFoundation.LibreOffice", "Office grátis");
            A("Escritório", "Adobe Acrobat Reader", "Adobe.Acrobat.Reader.64-bit", "Ler PDFs");
            A("Escritório", "Google Drive", "Google.GoogleDrive", "Arquivos na nuvem");
            A("Escritório", "Notion", "Notion.Notion", "Notas e organização");
            A("Escritório", "Obsidian", "Obsidian.Obsidian", "Notas em Markdown");
            A("Programação", "Visual Studio Code", "Microsoft.VisualStudioCode", "Editor de código");
            A("Programação", "Git", "Git.Git", "Controle de versão");
            A("Programação", "Python 3", "Python.Python.3.12", "Linguagem Python");
            A("Programação", "Node.js LTS", "OpenJS.NodeJS.LTS", "JavaScript no PC");
            A("Programação", "Windows Terminal", "Microsoft.WindowsTerminal", "Terminal moderno");
            A("Essenciais", "Visual C++ 2015-2022", "Microsoft.VCRedist.2015+.x64", "Necessário para muitos jogos");
            A("Essenciais", ".NET Desktop Runtime 8", "Microsoft.DotNet.DesktopRuntime.8", "Necessário para vários programas");
            A("Essenciais", "DirectX (DLLs antigas)", "Microsoft.DirectX", "Para jogos antigos");
            A("Essenciais", "Java", "Oracle.JavaRuntimeEnvironment", "Para Minecraft Java e outros");
            return l;
        }
    }
}

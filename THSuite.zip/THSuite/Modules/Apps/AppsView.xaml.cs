using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Management;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;

namespace THSuite.Apps
{
    public partial class AppsView : UserControl
    {
        readonly ObservableCollection<AppItem> _upgrades = new();
        readonly List<AppItem> _catalog = AppCatalog.Build();
        readonly ICollectionView _catView;
        string _cat = "Todos";
        bool _busy, _stop, _installedLoaded, _driversLoaded, _wingetChecked, _wingetOk;

        public AppsView()
        {
            InitializeComponent();
            LstUpgrades.ItemsSource = _upgrades;
            _catView = CollectionViewSource.GetDefaultView(_catalog);
            _catView.Filter = o => o is AppItem a && (_cat == "Todos" || a.Category == _cat);
            LstCatalog.ItemsSource = _catView;
            foreach (var c in new[] { "Todos" }.Concat(_catalog.Select(a => a.Category).Distinct()))
            {
                var rb = new RadioButton { Style = (Style)FindResource("Pill"), GroupName = "appCat", Content = c, Tag = c, IsChecked = c == "Todos", Margin = new Thickness(0, 0, 6, 6) };
                rb.Checked += (_, _) => { _cat = (string)rb.Tag; _catView.Refresh(); };
                InstPills.Children.Add(rb);
            }
        }

        public IReadOnlyList<AppItem> Catalog => _catalog;

        public void ShowTab(string tab)
        {
            (tab switch { "install" => TabInstall, "drivers" => TabDrivers, _ => TabUpdate }).IsChecked = true;
        }

        void Tab_Checked(object sender, RoutedEventArgs e)
        {
            if (PageUpdate == null) return;
            PageUpdate.Visibility = sender == TabUpdate ? Visibility.Visible : Visibility.Collapsed;
            PageInstall.Visibility = sender == TabInstall ? Visibility.Visible : Visibility.Collapsed;
            PageDrivers.Visibility = sender == TabDrivers ? Visibility.Visible : Visibility.Collapsed;
            if (sender == TabInstall && !_installedLoaded) _ = LoadInstalledAsync();
            if (sender == TabDrivers && !_driversLoaded) _ = LoadDriversAsync();
        }

        async Task<bool> EnsureWingetAsync()
        {
            if (!_wingetChecked) { _wingetOk = await Winget.AvailableAsync(); _wingetChecked = true; }
            if (!_wingetOk && Host.Confirm("O winget (gerenciador de pacotes da Microsoft) não foi encontrado.\n\nEle vem no \"Instalador de Aplicativo\" da Microsoft Store. Abrir a Store para instalar/atualizar?"))
                Cmd.Open("ms-windows-store://pdp/?ProductId=9NBLGGH4NNS1");
            return _wingetOk;
        }

        // =====================================================================
        //  Atualizar
        // =====================================================================

        async void ScanUpdates_Click(object sender, RoutedEventArgs e) => await ScanUpdatesAsync();

        public async Task<int> ScanUpdatesAsync(bool silent = false)
        {
            if (_busy || !await EnsureWingetAsync()) return 0;
            BtnScanUpd.IsEnabled = false;
            TxtUpdSub.Text = "Procurando atualizações (pode levar até 1 minuto)...";
            _upgrades.Clear();
            var list = await Winget.UpgradesAsync();
            foreach (var a in list) _upgrades.Add(a);
            TxtUpdTitle.Text = list.Count == 0 ? "Tudo atualizado" : $"{list.Count} programa(s) com atualização";
            TxtUpdSub.Text = list.Count == 0 ? "Nenhum programa desatualizado encontrado pelo winget." : "Desmarque o que não quiser atualizar e clique em \"Atualizar selecionados\".";
            TxtUpdEmpty.Visibility = list.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
            TxtUpdEmpty.Text = "Programas instalados fora do winget (alguns jogos e apps antigos) podem não aparecer aqui.";
            BtnScanUpd.IsEnabled = true;
            return list.Count;
        }

        async void Upgrade_Click(object sender, RoutedEventArgs e)
        {
            if (_busy) return;
            if (_upgrades.Count == 0) { await ScanUpdatesAsync(); if (_upgrades.Count == 0) return; }
            var list = _upgrades.Where(a => a.IsChecked).ToList();
            if (list.Count == 0) { Host.Info("Marque os programas que deseja atualizar."); return; }
            if (!Host.Confirm($"Atualizar {list.Count} programa(s)?\n\nFeche os programas da lista antes (eles podem ser fechados durante a atualização).")) return;
            await RunBatchAsync("Atualizando", list, Winget.UpgradeAsync, "Atualizado");
            await ScanUpdatesAsync();
        }

        // =====================================================================
        //  Instalar
        // =====================================================================

        async Task LoadInstalledAsync()
        {
            _installedLoaded = true;
            if (!await EnsureWingetAsync()) { _installedLoaded = false; return; }
            TxtInstSub.Text = "Verificando o que já está instalado...";
            var ids = await Winget.InstalledIdsAsync();
            foreach (var a in _catalog) a.Installed = ids.Contains(a.Id);
            TxtInstSub.Text = "Marque o que quiser e clique em Instalar. Tudo é baixado do site oficial, sem barras de ferramentas nem programas extras.";
        }

        void ClearSel_Click(object sender, RoutedEventArgs e) { foreach (var a in _catalog) a.IsChecked = false; }

        async void Install_Click(object sender, RoutedEventArgs e)
        {
            if (_busy) return;
            var list = _catalog.Where(a => a.IsChecked).ToList();
            if (list.Count == 0) { Host.Info("Marque os programas que deseja instalar."); return; }
            if (!await EnsureWingetAsync()) return;
            if (!Host.Confirm($"Instalar {list.Count} programa(s)?\n\n" + string.Join("\n", list.Select(a => "  • " + a.Name)))) return;
            await RunBatchAsync("Instalando", list, Winget.InstallAsync, "Instalado");
            foreach (var a in list) a.IsChecked = false;
            _installedLoaded = false;
            await LoadInstalledAsync();
        }

        async Task RunBatchAsync(string verb, List<AppItem> list, Func<AppItem, Action<string>?, CancellationToken, Task<(int Code, string Output)>> run, string doneText)
        {
            _busy = true;
            _stop = false;
            TxtBusy.Text = $"{verb} {list.Count} programa(s)...";
            TxtBusyLog.Text = "";
            PrgBusy.IsIndeterminate = false;
            PrgBusy.Maximum = list.Count;
            PrgBusy.Value = 0;
            PrgBusy.Visibility = Visibility.Visible;
            BtnBusyStop.Visibility = Visibility.Visible;
            BtnBusyClose.Visibility = Visibility.Collapsed;
            BusyOverlay.Visibility = Visibility.Visible;
            int ok = 0;
            for (int i = 0; i < list.Count && !_stop; i++)
            {
                var a = list[i];
                TxtBusy.Text = $"{verb} {i + 1} de {list.Count}: {a.Name}";
                Log($"> {a.Name}");
                a.Status = verb + "...";
                var (code, output) = await run(a, line => { if (!Winget.IsNoise(line)) Dispatcher.InvokeAsync(() => Log("  " + line.Trim())); }, CancellationToken.None);
                bool success = code == 0 || output.Contains("instalado com êxito", StringComparison.OrdinalIgnoreCase) || output.Contains("Successfully installed", StringComparison.OrdinalIgnoreCase);
                a.Status = success ? doneText : $"Erro (código {code})";
                if (success) { ok++; Activity.Log("Programas", $"{doneText}: {a.Name}"); }
                PrgBusy.Value = i + 1;
            }
            TxtBusy.Text = $"Concluído: {ok} de {list.Count}.";
            BtnBusyStop.Visibility = Visibility.Collapsed;
            BtnBusyClose.Visibility = Visibility.Visible;
            _busy = false;
        }

        void Log(string line)
        {
            TxtBusyLog.Text += (TxtBusyLog.Text.Length > 0 ? "\n" : "") + line;
            BusyScroll.ScrollToEnd();
        }

        void BusyStop_Click(object sender, RoutedEventArgs e) { _stop = true; BtnBusyStop.IsEnabled = false; }
        void BusyClose_Click(object sender, RoutedEventArgs e) { BusyOverlay.Visibility = Visibility.Collapsed; BtnBusyStop.IsEnabled = true; }

        // =====================================================================
        //  Drivers
        // =====================================================================

        record Gpu(string Name, string Version, DateTime? Date);
        record BadDevice(string Name, int Code);

        async void RefreshDrivers_Click(object sender, RoutedEventArgs e) => await LoadDriversAsync();
        void WuDrivers_Click(object sender, RoutedEventArgs e) => Cmd.Open("ms-settings:windowsupdate-optionalupdates");
        void DevMgr_Click(object sender, RoutedEventArgs e) => Cmd.Open("devmgmt.msc");

        string _board = "";

        async Task LoadDriversAsync()
        {
            _driversLoaded = true;
            GpuList.Children.Clear();
            DevList.Children.Clear();
            var (gpus, board, bios, bad) = await Task.Run(() =>
            {
                var g = new List<Gpu>();
                var b = new List<BadDevice>();
                string brd = "", bio = "";
                try
                {
                    using (var s = new ManagementObjectSearcher("SELECT Name, DriverVersion, DriverDate FROM Win32_VideoController"))
                        foreach (ManagementObject o in s.Get())
                        {
                            DateTime? d = null;
                            try { if (o["DriverDate"] is string ds) d = ManagementDateTimeConverter.ToDateTime(ds); } catch { }
                            g.Add(new Gpu(o["Name"]?.ToString() ?? "", o["DriverVersion"]?.ToString() ?? "", d));
                            o.Dispose();
                        }
                    using (var s = new ManagementObjectSearcher("SELECT Manufacturer, Product FROM Win32_BaseBoard"))
                        foreach (ManagementObject o in s.Get()) { brd = $"{o["Manufacturer"]} {o["Product"]}".Trim(); o.Dispose(); }
                    using (var s = new ManagementObjectSearcher("SELECT SMBIOSBIOSVersion, ReleaseDate FROM Win32_BIOS"))
                        foreach (ManagementObject o in s.Get())
                        {
                            string date = "";
                            try { if (o["ReleaseDate"] is string rd) date = ManagementDateTimeConverter.ToDateTime(rd).ToString("dd/MM/yyyy"); } catch { }
                            bio = $"BIOS {o["SMBIOSBIOSVersion"]}" + (date.Length > 0 ? $" de {date}" : "");
                            o.Dispose();
                        }
                    using (var s = new ManagementObjectSearcher("SELECT Name, ConfigManagerErrorCode FROM Win32_PnPEntity WHERE ConfigManagerErrorCode <> 0"))
                        foreach (ManagementObject o in s.Get())
                        {
                            int code = Convert.ToInt32(o["ConfigManagerErrorCode"]);
                            if (code != 22) b.Add(new BadDevice(o["Name"]?.ToString() ?? "Dispositivo desconhecido", code)); // 22 = desativado pelo usuário
                            o.Dispose();
                        }
                }
                catch { }
                return (g, brd, bio, b);
            });

            foreach (var gp in gpus.Where(x => !x.Name.Contains("Basic Display", StringComparison.OrdinalIgnoreCase) || gpus.Count == 1))
                GpuList.Children.Add(GpuCard(gp));
            _board = board;
            TxtBoard.Text = board.Length > 0 ? board : "Não identificada";
            TxtBios.Text = bios;

            if (bad.Count == 0)
                DevList.Children.Add(Card("", "Nenhum dispositivo com problema", "Todos os dispositivos do PC estão com driver funcionando.", "OkSolidBrush", null, null));
            foreach (var d in bad)
                DevList.Children.Add(Card("", d.Name, ErrorText(d.Code), "WarnSolidBrush", "Procurar no Windows Update", () => Cmd.Open("ms-settings:windowsupdate-optionalupdates")));
        }

        static string ErrorText(int code) => code switch
        {
            28 => "Driver não instalado (código 28).",
            10 => "O dispositivo não consegue iniciar (código 10). Reinstalar o driver costuma resolver.",
            43 => "O Windows parou o dispositivo porque ele relatou problemas (código 43).",
            31 => "O driver não carregou corretamente (código 31).",
            1 => "Dispositivo sem configuração correta (código 1).",
            _ => $"Problema no driver (código {code})."
        };

        UIElement GpuCard(Gpu g)
        {
            string n = g.Name.ToLowerInvariant();
            string vendor = n.Contains("nvidia") || n.Contains("geforce") ? "nvidia" : n.Contains("amd") || n.Contains("radeon") ? "amd" : n.Contains("intel") ? "intel" : "";
            string age = "";
            string brush = "OkSolidBrush";
            if (g.Date is DateTime d)
            {
                int days = (int)(DateTime.Now - d).TotalDays;
                age = $"Driver {g.Version} de {d:dd/MM/yyyy}";
                if (days > 180) { age += $" — com {days / 30} meses, vale atualizar"; brush = "WarnSolidBrush"; }
            }
            (string Text, Action Act)[] actions = vendor switch
            {
                "nvidia" => new (string, Action)[] { ("Baixar driver NVIDIA", () => Cmd.Open("https://www.nvidia.com/pt-br/drivers/")), ("App NVIDIA", () => Cmd.Open("https://www.nvidia.com/pt-br/software/nvidia-app/")) },
                "amd" => new (string, Action)[] { ("Baixar driver AMD", () => Cmd.Open("https://www.amd.com/pt/support/download/drivers.html")) },
                "intel" => new (string, Action)[] { ("Assistente de drivers Intel", () => Cmd.Open("https://www.intel.com.br/content/www/br/pt/support/detect.html")) },
                _ => new (string, Action)[] { ("Procurar driver", () => Cmd.Open("https://www.google.com/search?q=" + Uri.EscapeDataString(g.Name + " driver"))) }
            };
            var border = (Border)Card(vendor == "" ? "" : "", g.Name, age.Length > 0 ? age : "Versão do driver: " + g.Version, brush, null, null);
            var grid = (Grid)border.Child;
            var sp = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, VerticalAlignment = VerticalAlignment.Center };
            foreach (var (text, act) in actions)
            {
                var b = new Button { Style = (Style)FindResource("SecondaryButton"), Content = text, Margin = new Thickness(8, 0, 0, 0) };
                b.Click += (_, _) => act();
                sp.Children.Add(b);
            }
            Grid.SetColumn(sp, 2);
            grid.Children.Add(sp);
            return border;
        }

        UIElement Card(string icon, string title, string sub, string brush, string? button, Action? onClick)
        {
            var border = new Border { Style = (Style)FindResource("Card"), Margin = new Thickness(0, 0, 0, 10) };
            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(36) });
            grid.ColumnDefinitions.Add(new ColumnDefinition());
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var ico = new TextBlock { Text = icon, FontFamily = new FontFamily("Segoe MDL2 Assets"), FontSize = 18, VerticalAlignment = VerticalAlignment.Center };
            ico.SetResourceReference(TextBlock.ForegroundProperty, brush);
            grid.Children.Add(ico);
            var sp = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            var t = new TextBlock { Text = title, FontSize = 13.5, FontWeight = FontWeights.SemiBold, TextWrapping = TextWrapping.Wrap };
            t.SetResourceReference(TextBlock.ForegroundProperty, "TextBrush");
            var s2 = new TextBlock { Text = sub, FontSize = 11.5, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 0) };
            s2.SetResourceReference(TextBlock.ForegroundProperty, brush == "OkSolidBrush" ? "MutedBrush" : brush);
            sp.Children.Add(t);
            sp.Children.Add(s2);
            Grid.SetColumn(sp, 1);
            grid.Children.Add(sp);
            if (button != null && onClick != null)
            {
                var b = new Button { Style = (Style)FindResource("SecondaryButton"), Content = button, VerticalAlignment = VerticalAlignment.Center };
                b.Click += (_, _) => onClick();
                Grid.SetColumn(b, 2);
                grid.Children.Add(b);
            }
            border.Child = grid;
            return border;
        }

        void BoardSearch_Click(object sender, RoutedEventArgs e) =>
            Cmd.Open("https://www.google.com/search?q=" + Uri.EscapeDataString((_board.Length > 0 ? _board : "placa mãe") + " drivers chipset download"));
    }
}

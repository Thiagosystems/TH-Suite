using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Management;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace THSuite.Optimizer
{
    public partial class OptimizerView : UserControl
    {
        const string AllCat = "Todos", RecCat = "Recomendados", OnCat = "Ativados", PendingCat = "Pendentes";

        static readonly Dictionary<string, string> CatInfo = new()
        {
            [AllCat] = "Todos os ajustes. Use as categorias para encontrar mais rápido.",
            [RecCat] = "Ajustes seguros que ajudam a maioria dos PCs. Bom ponto de partida.",
            [OnCat] = "Ajustes que estão ligados neste PC agora (pelo TH Suite ou por outro programa).",
            [PendingCat] = "Mudanças que você marcou e ainda não aplicou.",
            [Catalog.CatPerf] = "Deixam o Windows mais leve: menos coisas rodando escondidas, menos espera e menos uso de disco.",
            [Catalog.CatGames] = "Mais FPS, menos atraso de mouse e menos interrupções durante os jogos.",
            [Catalog.CatPower] = "O Windows economiza energia desligando partes do PC, o que pode causar pequenas travadas. Aqui você troca economia por desempenho.",
            [Catalog.CatGpu] = "Ajustes para placas NVIDIA, AMD e Intel. Os que não servem para a sua placa aparecem apagados.",
            [Catalog.CatNet] = "Menos ping e menos quedas. DNS, Nagle e prioridade de jogos ficam em Hardware e internet > Internet para jogos.",
            [Catalog.CatPrivacy] = "Menos dados enviados para a Microsoft e outras empresas, e mais segurança.",
            [Catalog.CatUi] = "Deixam o Windows 11 mais limpo e prático: sem propagandas, sem Bing e com o menu clássico.",
            [Catalog.CatServices] = "Serviços que ficam ligados o tempo todo e quase ninguém usa. Leia o aviso de cada um antes de desativar.",
            [Catalog.CatUpdate] = "Controle sobre quando e o que o Windows Update instala.",
        };

        readonly List<Tweak> _tweaks = Catalog.Build();
        readonly ICollectionView _view;
        readonly BackupStore _store = BackupStore.Load();
        readonly List<BloatApp> _bloat = Debloat.Catalog();
        readonly ObservableCollection<BloatApp> _bloatShown = new();
        readonly bool _laptop = Cmd.IsLaptop();

        string _cat = RecCat;
        bool _started, _busy, _bloatLoaded;

        public bool StatesLoaded { get; private set; }
        public event Action? StatesChanged;

        public OptimizerView()
        {
            InitializeComponent();
            foreach (var t in _tweaks) t.PendingChanged += UpdatePending;

            _view = CollectionViewSource.GetDefaultView(_tweaks);
            _view.Filter = o => o is Tweak t && Matches(t);
            LstTweaks.ItemsSource = _view;
            LstBloat.ItemsSource = _bloatShown;

            foreach (var c in new[] { RecCat, AllCat }.Concat(Catalog.Categories).Concat(new[] { OnCat, PendingCat }))
            {
                var rb = new RadioButton
                {
                    Style = (Style)FindResource("Pill"),
                    GroupName = "optCat",
                    Content = c,
                    Tag = c,
                    IsChecked = c == _cat,
                    Margin = new Thickness(0, 0, 6, 6)
                };
                rb.Checked += (_, _) => { _cat = (string)rb.Tag; Refilter(); };
                CatPills.Children.Add(rb);
            }
            TxtSearch.TextChanged += (_, _) => Refilter();
            Refilter();

            Loaded += async (_, _) =>
            {
                if (_started) return;
                _started = true;
                await RefreshStatesAsync();
            };
        }

        // =====================================================================
        //  API para a tela inicial
        // =====================================================================

        public void ShowTab(string tab)
        {
            switch (tab)
            {
                case "debloat": TabDebloat.IsChecked = true; return;
                case "startup": TabStartup.IsChecked = true; return;
            }
            TabTweaks.IsChecked = true;
            var pill = CatPills.Children.OfType<RadioButton>().FirstOrDefault(r => string.Equals((string)r.Tag, tab, StringComparison.OrdinalIgnoreCase));
            if (pill != null) pill.IsChecked = true;
        }

        /// <summary>Recomendados que ainda não estão ligados.</summary>
        public int PendingRecommendedCount => _tweaks.Count(t => IsQuickCandidate(t) && !t.IsApplied);
        public int AppliedCount => _tweaks.Count(t => t.Available && t.IsApplied);
        public int TotalCount => _tweaks.Count(t => t.Available);

        bool IsQuickCandidate(Tweak t) => t.Recommended && t.Available && t.Risk == Risk.Safe && !(_laptop && t.NotebookWarning);

        /// <summary>Aplica os recomendados seguros (otimização rápida). Retorna quantos foram aplicados.</summary>
        public async Task<int> ApplyRecommendedAsync(Action<string>? log = null)
        {
            if (!StatesLoaded) await RefreshStatesAsync();
            var list = _tweaks.Where(t => IsQuickCandidate(t) && !t.IsApplied).ToList();
            int ok = 0;
            foreach (var t in list)
            {
                log?.Invoke("  • " + t.Title);
                var errors = await Task.Run(() => t.Run(true, _store));
                if (errors.Count == 0) ok++;
                else log?.Invoke("    (não foi possível: " + errors[0] + ")");
            }
            _store.Save();
            await RedetectAsync(list);
            if (list.Any(t => t.Restart == Restart.Explorer)) await Cmd.RestartExplorerAsync();
            return ok;
        }

        // =====================================================================
        //  Estado
        // =====================================================================

        async Task RefreshStatesAsync()
        {
            TxtOptTitle.Text = "Verificando seu PC...";
            TxtOptSummary.Text = "Lendo o estado atual de cada ajuste.";
            var vendors = await Task.Run(DetectVendors);
            await RedetectAsync(_tweaks, vendors);
            StatesLoaded = true;
            UpdateSummary();
        }

        HashSet<string>? _vendors;

        async Task RedetectAsync(IEnumerable<Tweak> tweaks, HashSet<string>? vendors = null)
        {
            if (vendors != null) _vendors = vendors;
            var list = tweaks.ToList();
            var results = new ConcurrentDictionary<string, (bool Applied, bool Available)>();
            await Task.Run(() => Parallel.ForEach(list, new ParallelOptions { MaxDegreeOfParallelism = 6 }, t =>
            {
                try { results[t.Id] = t.Detect(_store); }
                catch { results[t.Id] = (false, false); }
            }));
            foreach (var t in list)
            {
                var (applied, available) = results.TryGetValue(t.Id, out var r) ? r : (false, false);
                bool vendorOk = t.Vendor.Length == 0 || _vendors == null || _vendors.Contains(t.Vendor);
                t.Available = available && vendorOk;
                t.IsApplied = applied;
                t.Desired = applied;
            }
            UpdatePending();
            Refilter();
            StatesChanged?.Invoke();
        }

        static HashSet<string> DetectVendors()
        {
            var set = new HashSet<string>();
            try
            {
                using var s = new ManagementObjectSearcher("SELECT Name FROM Win32_VideoController");
                foreach (ManagementObject o in s.Get())
                {
                    string n = (o["Name"]?.ToString() ?? "").ToLowerInvariant();
                    if (n.Contains("nvidia") || n.Contains("geforce") || n.Contains("rtx") || n.Contains("gtx")) set.Add("nvidia");
                    if (n.Contains("amd") || n.Contains("radeon")) set.Add("amd");
                    if (n.Contains("intel")) set.Add("intel");
                    o.Dispose();
                }
            }
            catch { }
            return set;
        }

        void UpdateSummary()
        {
            int total = TotalCount, on = AppliedCount, rec = PendingRecommendedCount;
            TxtOptTitle.Text = rec == 0 ? "Seu Windows está otimizado" : $"{rec} ajuste{(rec > 1 ? "s" : "")} recomendado{(rec > 1 ? "s" : "")} para fazer";
            TxtOptSummary.Text = $"{on} de {total} ajustes ligados neste PC."
                                 + (_laptop ? " Notebook detectado: ajustes que gastam mais bateria não são marcados automaticamente." : "");
        }

        // =====================================================================
        //  Filtro e lista
        // =====================================================================

        bool Matches(Tweak t)
        {
            bool cat = _cat switch
            {
                AllCat => true,
                RecCat => t.Recommended,
                OnCat => t.IsApplied && t.Available,
                PendingCat => t.Pending,
                _ => t.Category == _cat
            };
            if (!cat) return false;
            string q = TxtSearch.Text.Trim();
            if (q.Length == 0) return true;
            return t.Title.Contains(q, StringComparison.CurrentCultureIgnoreCase)
                || t.Description.Contains(q, StringComparison.CurrentCultureIgnoreCase)
                || t.Details.Contains(q, StringComparison.CurrentCultureIgnoreCase)
                || t.Category.Contains(q, StringComparison.CurrentCultureIgnoreCase);
        }

        void Refilter()
        {
            if (_view == null) return;
            _view.Refresh();
            TxtCatInfo.Text = TxtSearch.Text.Trim().Length > 0 ? "Resultados da pesquisa." : CatInfo.TryGetValue(_cat, out var info) ? info : "";
            TxtEmpty.Visibility = _view.IsEmpty ? Visibility.Visible : Visibility.Collapsed;
            TweakScroll.ScrollToTop();
        }

        void ToggleDetails_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as FrameworkElement)?.DataContext is Tweak t) t.Expanded = !t.Expanded;
        }

        void UpdatePending()
        {
            var pending = _tweaks.Where(t => t.Pending).ToList();
            PendingBar.Visibility = pending.Count > 0 ? Visibility.Visible : Visibility.Collapsed;
            if (pending.Count == 0) return;
            int on = pending.Count(t => t.Desired), off = pending.Count - on;
            TxtPending.Text = $"{pending.Count} alteraç{(pending.Count > 1 ? "ões" : "ão")} para aplicar";
            var parts = new List<string>();
            if (on > 0) parts.Add($"{on} para ligar");
            if (off > 0) parts.Add($"{off} para desfazer");
            if (pending.Any(t => t.Restart == Restart.Reboot)) parts.Add("alguns só valem depois de reiniciar o PC");
            TxtPendingSub.Text = string.Join(" · ", parts);
        }

        // =====================================================================
        //  Ações
        // =====================================================================

        void MarkRecommended_Click(object sender, RoutedEventArgs e)
        {
            int n = 0;
            foreach (var t in _tweaks.Where(t => IsQuickCandidate(t) && !t.IsApplied)) { t.Desired = true; n++; }
            ShowTab(RecCat);
            if (n == 0) Host.Info("Todos os ajustes recomendados já estão ligados.");
        }

        void Discard_Click(object sender, RoutedEventArgs e)
        {
            foreach (var t in _tweaks) t.Desired = t.IsApplied;
            Refilter();
        }

        async void RevertAll_Click(object sender, RoutedEventArgs e)
        {
            var mine = _tweaks.Where(t => t.IsApplied && _store.Tweaks.TryGetValue(t.Id, out var r) && r.Applied).ToList();
            if (mine.Count == 0) { Host.Info("Nenhum ajuste aplicado pelo TH Suite para desfazer."); return; }
            if (!Host.Confirm($"Desfazer os {mine.Count} ajustes aplicados pelo TH Suite e voltar os valores originais?")) return;
            foreach (var t in mine) t.Desired = false;
            await ApplyPendingAsync(askConfirm: false);
        }

        async void Apply_Click(object sender, RoutedEventArgs e) => await ApplyPendingAsync(askConfirm: true);

        async Task ApplyPendingAsync(bool askConfirm)
        {
            if (_busy) return;
            var pending = _tweaks.Where(t => t.Pending).ToList();
            if (pending.Count == 0) return;

            if (askConfirm && SuiteSettings.Current.ConfirmTweaks)
            {
                var msg = new List<string>();
                var on = pending.Where(t => t.Desired).ToList();
                var off = pending.Where(t => !t.Desired).ToList();
                if (on.Count > 0) msg.Add("Ligar:\n" + string.Join("\n", on.Take(20).Select(t => "  • " + t.Title)) + (on.Count > 20 ? $"\n  ... e mais {on.Count - 20}" : ""));
                if (off.Count > 0) msg.Add("Desfazer:\n" + string.Join("\n", off.Take(20).Select(t => "  • " + t.Title)) + (off.Count > 20 ? $"\n  ... e mais {off.Count - 20}" : ""));
                var adv = on.Where(t => t.Risk == Risk.Advanced).ToList();
                if (adv.Count > 0) msg.Add("ATENÇÃO, ajustes avançados:\n" + string.Join("\n", adv.Select(t => "  • " + t.Title + ": " + t.Warning)));
                if (SuiteSettings.Current.RestorePointBeforeTweaks) msg.Add("Um ponto de restauração será criado antes.");
                if (!Host.Confirm(string.Join("\n\n", msg) + "\n\nContinuar?", "Aplicar ajustes")) return;
            }

            _busy = true;
            BeginBusy("Aplicando ajustes...");
            try
            {
                if (SuiteSettings.Current.RestorePointBeforeTweaks && pending.Any(t => t.Desired))
                {
                    Log("Criando ponto de restauração (pode levar até 1 minuto)...");
                    var (ok, m) = await Cmd.CreateRestorePointAsync("TH Suite - antes dos ajustes");
                    Log(ok ? "Ponto de restauração criado." : m);
                    if (!ok && !Host.Confirm("Não foi possível criar o ponto de restauração.\n\n" + m + "\n\nAplicar os ajustes mesmo assim?"))
                    {
                        EndBusy("Cancelado.");
                        return;
                    }
                }

                int i = 0, fails = 0;
                foreach (var t in pending)
                {
                    i++;
                    TxtBusy.Text = $"Aplicando {i} de {pending.Count}...";
                    bool apply = t.Desired;
                    Log((apply ? "Ligando: " : "Desfazendo: ") + t.Title);
                    t.Status = "";
                    var errors = await Task.Run(() => t.Run(apply, _store));
                    if (errors.Count > 0)
                    {
                        fails++;
                        t.Status = "Erro: " + errors[0];
                        Log("   erro: " + string.Join("; ", errors));
                    }
                }
                _store.Save();
                Log("Conferindo o resultado...");
                await RedetectAsync(pending);
                UpdateSummary();

                bool explorer = pending.Any(t => t.Restart == Restart.Explorer);
                bool reboot = pending.Any(t => t.Restart == Restart.Reboot);
                bool logoff = pending.Any(t => t.Restart == Restart.Logoff);
                if (explorer)
                {
                    Log("Reiniciando o Explorador para aplicar as mudanças visuais...");
                    await Cmd.RestartExplorerAsync();
                }
                string done = fails == 0 ? "Pronto! Todos os ajustes foram aplicados." : $"Concluído com {fails} erro(s). Veja os detalhes nos cartões marcados.";
                if (reboot) done += "\nAlguns ajustes só valem depois de reiniciar o PC.";
                else if (logoff) done += "\nAlguns ajustes só valem depois de sair e entrar de novo na conta.";
                EndBusy(done);

                if (reboot && Host.Confirm("Alguns ajustes precisam reiniciar o PC para funcionar.\n\nReiniciar agora? (salve seus trabalhos antes)"))
                    Cmd.Open("shutdown.exe", "/r /t 5 /c \"TH Suite: reiniciando para aplicar ajustes\"");
            }
            catch (Exception ex)
            {
                EndBusy("Erro: " + ex.Message);
            }
            finally
            {
                _busy = false;
            }
        }

        async void RestorePoint_Click(object sender, RoutedEventArgs e)
        {
            if (_busy) return;
            _busy = true;
            BeginBusy("Criando ponto de restauração...");
            Log("Isso pode levar até 1 minuto.");
            var (ok, m) = await Cmd.CreateRestorePointAsync("TH Suite - ponto manual");
            EndBusy(ok ? "Ponto de restauração criado. Para voltar: Reparos e ferramentas > Restauração do Sistema." : m);
            _busy = false;
        }

        // =====================================================================
        //  Janela de progresso
        // =====================================================================

        void BeginBusy(string title)
        {
            TxtBusy.Text = title;
            TxtBusyLog.Text = "";
            PrgBusy.IsIndeterminate = true;
            PrgBusy.Visibility = Visibility.Visible;
            BtnBusyClose.Visibility = Visibility.Collapsed;
            BusyOverlay.Visibility = Visibility.Visible;
        }

        void Log(string line)
        {
            TxtBusyLog.Text += (TxtBusyLog.Text.Length > 0 ? "\n" : "") + line;
            BusyScroll.ScrollToEnd();
        }

        void EndBusy(string message)
        {
            TxtBusy.Text = message;
            PrgBusy.Visibility = Visibility.Collapsed;
            BtnBusyClose.Visibility = Visibility.Visible;
        }

        void BusyClose_Click(object sender, RoutedEventArgs e) => BusyOverlay.Visibility = Visibility.Collapsed;

        // =====================================================================
        //  Abas
        // =====================================================================

        void Tab_Checked(object sender, RoutedEventArgs e)
        {
            if (PageTweaks == null) return;
            PageTweaks.Visibility = sender == TabTweaks ? Visibility.Visible : Visibility.Collapsed;
            PageDebloat.Visibility = sender == TabDebloat ? Visibility.Visible : Visibility.Collapsed;
            PageStartup.Visibility = sender == TabStartup ? Visibility.Visible : Visibility.Collapsed;
            if (sender == TabDebloat && !_bloatLoaded) _ = LoadBloatAsync();
        }

        void OpenStartup_Click(object sender, RoutedEventArgs e) => Host.Navigate("security", "startup");
        void OpenTaskMgr_Click(object sender, RoutedEventArgs e) => Cmd.Open("taskmgr.exe", "/0 /startup");

        // =====================================================================
        //  Remover apps
        // =====================================================================

        async Task LoadBloatAsync()
        {
            _bloatLoaded = true;
            TxtDebloatSummary.Text = "Procurando apps instalados...";
            await Debloat.ScanAsync(_bloat);
            _bloatShown.Clear();
            foreach (var a in _bloat.Where(a => a.Installed).OrderByDescending(a => a.Recommended).ThenBy(a => a.Name))
                _bloatShown.Add(a);
            int rec = _bloatShown.Count(a => a.Recommended);
            TxtDebloatSummary.Text = _bloatShown.Count == 0
                ? "Nenhum app desnecessário encontrado. Seu Windows já está limpo."
                : $"{_bloatShown.Count} apps encontrados, {rec} marcados como \"pode remover\".";
        }

        void BloatRecommended_Click(object sender, RoutedEventArgs e)
        {
            foreach (var a in _bloatShown) a.IsChecked = a.Recommended;
        }

        async void BloatRemove_Click(object sender, RoutedEventArgs e)
        {
            if (_busy) return;
            var list = _bloatShown.Where(a => a.IsChecked).ToList();
            if (list.Count == 0) { Host.Info("Marque os apps que deseja remover."); return; }
            string warn = string.Join("\n", list.Where(a => a.Warning.Length > 0).Select(a => $"• {a.Name}: {a.Warning}"));
            if (!Host.Confirm($"Remover {list.Count} app(s)?\n\n" + string.Join("\n", list.Select(a => "  • " + a.Name))
                              + (warn.Length > 0 ? "\n\nAtenção:\n" + warn : "")
                              + "\n\nQuase todos podem ser instalados de novo pela Microsoft Store.")) return;

            _busy = true;
            BtnBloatRemove.IsEnabled = false;
            bool prov = ChkProvisioned.IsChecked == true;
            int ok = 0;
            foreach (var a in list)
            {
                a.Status = "Removendo...";
                bool done = await Debloat.RemoveAsync(a, prov);
                a.Status = done ? "Removido" : "Não foi possível";
                if (done) { ok++; a.IsChecked = false; }
            }
            BtnBloatRemove.IsEnabled = true;
            _busy = false;
            TxtDebloatSummary.Text = $"{ok} de {list.Count} apps removidos.";
            await Task.Delay(1500);
            await LoadBloatAsync();
        }
    }
}

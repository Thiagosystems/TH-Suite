using System;
using System.Collections.Generic;
using Microsoft.Win32;

namespace THSuite.Optimizer
{
    /// <summary>Lista de todos os ajustes do otimizador, com explicações para quem não é técnico.</summary>
    public static class Catalog
    {
        public const string CatPerf = "Desempenho", CatGames = "Jogos", CatPower = "Energia", CatGpu = "Placa de vídeo",
                            CatNet = "Rede", CatPrivacy = "Privacidade", CatUi = "Windows 11 e visual",
                            CatServices = "Serviços", CatUpdate = "Windows Update";

        public static readonly string[] Categories = { CatPerf, CatGames, CatPower, CatGpu, CatNet, CatPrivacy, CatUi, CatServices, CatUpdate };

        const string ADV = @"Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced";
        const string CDM = @"Software\Microsoft\Windows\CurrentVersion\ContentDeliveryManager";
        const string POL = @"SOFTWARE\Policies\Microsoft\Windows";
        const string MMSP = @"SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile";
        const string GCS = @"System\GameConfigStore";
        const string DESK = @"Control Panel\Desktop";
        const string ULTIMATE = "7a4f3d2e-1b0c-4e8f-9a6b-5c4d3e2f1a0b";

        static RegValue D(string hive, string path, string name, int value, int? def = null, bool optional = false) =>
            new(hive, path, name, value) { Default = def, Optional = optional };

        static RegValue Sz(string hive, string path, string name, string value, string? def = null) =>
            new(hive, path, name, value, RegistryValueKind.String) { Default = def };

        static ServiceStart Svc(string name, int def = 3) => new(name, 4, def);

        static bool? PsBool(string script)
        {
            var (_, o) = Proc.PowerShell(script, 30000);
            if (o.Contains("True")) return true;
            if (o.Contains("False")) return false;
            return null;
        }

        static bool? RegIs(string hive, string path, string name, int value) =>
            Reg.Get(hive, path, name) is int i ? i == value : null;

        public static List<Tweak> Build()
        {
            var t = new List<Tweak>();

            // =================================================================
            //  DESEMPENHO
            // =================================================================
            t.Add(new Tweak
            {
                Id = "startup_delay", Category = CatPerf, Recommended = true,
                Title = "Abrir os programas da inicialização sem espera",
                Description = "Tira a pausa de alguns segundos que o Windows faz antes de abrir os apps que iniciam com ele.",
                Details = "Depois de ligar o PC, o Windows segura os programas da inicialização por um tempo para o sistema \"respirar\". Em PCs com SSD essa espera é desnecessária e só atrasa o momento em que você pode usar o computador.",
                Actions = { D("HKCU", @"Software\Microsoft\Windows\CurrentVersion\Explorer\Serialize", "StartupDelayInMSec", 0) }
            });
            t.Add(new Tweak
            {
                Id = "menu_delay", Category = CatPerf, Recommended = true,
                Title = "Menus abrem sem atraso",
                Description = "Submenus e menus do Windows aparecem na hora, sem a animação de espera.",
                Details = "Por padrão o Windows espera 400 milissegundos antes de abrir um submenu quando você passa o mouse. Zerar essa espera deixa a navegação mais ágil. Vale depois de sair e entrar na conta.",
                Restart = Restart.Logoff,
                Actions = { Sz("HKCU", DESK, "MenuShowDelay", "0", "400") }
            });
            t.Add(new Tweak
            {
                Id = "visual_fx", Category = CatPerf,
                Title = "Efeitos visuais no modo desempenho",
                Description = "Desliga animações, sombras e efeitos de janelas para sobrar mais processamento.",
                Details = "Equivale a escolher \"Ajustar para obter um melhor desempenho\" nas configurações avançadas do sistema. Faz diferença em PCs fracos ou com placa de vídeo integrada. O visual fica mais simples (sem animação ao minimizar, sem sombra embaixo das janelas). A suavização das fontes continua ligada.",
                Restart = Restart.Logoff,
                Actions =
                {
                    D("HKCU", @"Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects", "VisualFXSetting", 2),
                    new RegValue("HKCU", DESK, "UserPreferencesMask", new byte[] { 0x90, 0x12, 0x03, 0x80, 0x10, 0x00, 0x00, 0x00 }, RegistryValueKind.Binary)
                        { Default = new byte[] { 0x9E, 0x1E, 0x07, 0x80, 0x12, 0x00, 0x00, 0x00 } },
                    Sz("HKCU", DESK + @"\WindowMetrics", "MinAnimate", "0", "1"),
                    D("HKCU", ADV, "TaskbarAnimations", 0, 1),
                    D("HKCU", ADV, "ListviewShadow", 0, 1),
                    D("HKCU", ADV, "ListviewAlphaSelect", 0, 1),
                }
            });
            t.Add(new Tweak
            {
                Id = "transparency", Category = CatPerf,
                Title = "Desativar transparência",
                Description = "Barra de tarefas, Iniciar e janelas ficam sólidas, sem o efeito de vidro.",
                Details = "O efeito de transparência (acrílico/mica) usa a placa de vídeo o tempo todo. Desligar ajuda notebooks a economizar bateria e PCs com vídeo integrado a ficarem mais leves.",
                Actions = { D("HKCU", @"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize", "EnableTransparency", 0, 1) }
            });
            t.Add(new Tweak
            {
                Id = "foreground_prio", Category = CatPerf, Recommended = true,
                Title = "Mais prioridade para o programa em primeiro plano",
                Description = "O Windows dá fatias maiores de processamento para a janela que você está usando.",
                Details = "Ajusta o \"Win32PrioritySeparation\" para 0x26: o app ou jogo em foco recebe mais tempo de CPU e responde mais rápido, enquanto o que está em segundo plano espera um pouco mais. É uma configuração clássica e segura.",
                Actions = { D("HKLM", @"SYSTEM\CurrentControlSet\Control\PriorityControl", "Win32PrioritySeparation", 0x26, 2) }
            });
            t.Add(new Tweak
            {
                Id = "background_apps", Category = CatPerf, Risk = Risk.Moderate,
                Title = "Bloquear apps da Store em segundo plano",
                Description = "Apps da Microsoft Store não ficam rodando escondidos quando estão fechados.",
                Details = "Muitos apps da Store (Clima, Notícias, Fotos etc.) continuam acordando em segundo plano para atualizar coisas. Bloquear economiza RAM, CPU e bateria. Programas normais (Chrome, Discord, Steam) não são afetados.",
                Warning = "Apps da Store como WhatsApp, Email e Teams podem deixar de mostrar notificações enquanto estão fechados.",
                Actions =
                {
                    D("HKCU", @"Software\Microsoft\Windows\CurrentVersion\BackgroundAccessApplications", "GlobalUserDisabled", 1, 0),
                    D("HKLM", POL + @"\AppPrivacy", "LetAppsRunInBackground", 2),
                }
            });
            t.Add(new Tweak
            {
                Id = "sysmain", Category = CatPerf, Risk = Risk.Moderate,
                Title = "Desativar SysMain (Superfetch) e Prefetch",
                Description = "Para o serviço que pré-carrega na RAM os programas que você mais usa.",
                Details = "O SysMain tenta adivinhar o que você vai abrir e carrega antes. Em PCs com pouca RAM ou que ficam com o disco em 100%, desligar costuma aliviar. Em SSD rápido a diferença ao abrir programas é quase nula.",
                Warning = "Em HD (disco mecânico) os programas podem demorar mais para abrir. Não recomendado se o seu Windows está em HD.",
                Actions =
                {
                    Svc("SysMain", 2),
                    D("HKLM", @"SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters", "EnablePrefetcher", 0, 3),
                }
            });
            t.Add(new Tweak
            {
                Id = "indexing", Category = CatPerf, Risk = Risk.Moderate,
                Title = "Desativar indexação de arquivos (Windows Search)",
                Description = "Para o serviço que fica lendo seus arquivos para a pesquisa ser instantânea.",
                Details = "A indexação usa disco e CPU de tempos em tempos, principalmente depois de copiar muitos arquivos. Desligar alivia PCs fracos e discos lentos.",
                Warning = "A pesquisa do Iniciar e do Explorador fica mais lenta e pode não achar textos dentro de documentos e e-mails do Outlook.",
                Actions = { Svc("WSearch", 2) }
            });
            t.Add(new Tweak
            {
                Id = "memcompress", Category = CatPerf, Risk = Risk.Moderate, Restart = Restart.Reboot,
                Title = "Desativar compressão de memória",
                Description = "O Windows para de compactar a RAM, o que economiza um pouco de processamento.",
                Details = "Quando a memória enche, o Windows comprime partes dela em vez de jogar no disco. Isso gasta CPU. Com bastante RAM sobrando, desligar tira esse trabalho extra e pode reduzir pequenas travadas em jogos.",
                Warning = "Indicado apenas para PCs com 16 GB de RAM ou mais. Com 8 GB ou menos, o PC pode ficar mais lento ao usar muitos programas.",
                Actions =
                {
                    new ScriptAction("memcompress",
                        "Disable-MMAgent -MemoryCompression -ErrorAction Stop",
                        "Enable-MMAgent -MemoryCompression -ErrorAction Stop",
                        () => PsBool("-not (Get-MMAgent).MemoryCompression"))
                }
            });
            t.Add(new Tweak
            {
                Id = "error_reporting", Category = CatPerf, Recommended = true,
                Title = "Desativar relatórios de erro",
                Description = "O Windows para de coletar e enviar relatórios quando um programa trava.",
                Details = "Quando algo trava, o Serviço de Relatório de Erros junta informações e envia para a Microsoft, usando disco e internet. Para o uso doméstico isso não traz benefício.",
                Actions =
                {
                    D("HKLM", @"SOFTWARE\Microsoft\Windows\Windows Error Reporting", "Disabled", 1, 0),
                    Svc("WerSvc", 3),
                }
            });
            t.Add(new Tweak
            {
                Id = "compat_assistant", Category = CatPerf, Recommended = true,
                Title = "Desativar Assistente de Compatibilidade de Programas",
                Description = "Para o serviço que monitora instaladores e programas antigos procurando problemas.",
                Details = "O assistente fica observando cada programa que você abre para sugerir \"modos de compatibilidade\". Na prática quase nunca ajuda e às vezes atrasa a abertura de jogos e instaladores.",
                Actions =
                {
                    Svc("PcaSvc", 3),
                    D("HKLM", POL + @"\AppCompat", "DisablePCA", 1),
                }
            });
            t.Add(new Tweak
            {
                Id = "ntfs_lastaccess", Category = CatPerf, Recommended = true,
                Title = "Não registrar o último acesso de cada arquivo",
                Description = "O disco deixa de gravar a data e hora toda vez que um arquivo é só lido.",
                Details = "Por padrão o NTFS pode atualizar o \"último acesso\" de cada arquivo lido, o que gera escritas extras no disco. Desligar reduz o trabalho do disco e o desgaste do SSD. Quase nenhum programa usa essa informação.",
                Actions = { D("HKLM", @"SYSTEM\CurrentControlSet\Control\FileSystem", "NtfsDisableLastAccessUpdate", unchecked((int)0x80000003), unchecked((int)0x80000002)) }
            });

            // =================================================================
            //  JOGOS
            // =================================================================
            t.Add(new Tweak
            {
                Id = "game_mode", Category = CatGames, Recommended = true,
                Title = "Ativar o Modo de Jogo do Windows",
                Description = "O Windows prioriza o jogo aberto e evita instalar atualizações e mostrar avisos durante a partida.",
                Details = "O Modo de Jogo dá prioridade de CPU e placa de vídeo para o jogo e segura o Windows Update e notificações enquanto você joga. Em PCs atuais é seguro deixar ligado.",
                Actions =
                {
                    D("HKCU", @"Software\Microsoft\GameBar", "AutoGameModeEnabled", 1),
                    D("HKCU", @"Software\Microsoft\GameBar", "AllowAutoGameMode", 1),
                }
            });
            t.Add(new Tweak
            {
                Id = "game_dvr", Category = CatGames, Recommended = true,
                Title = "Desativar gravação em segundo plano (Game DVR)",
                Description = "Para a gravação automática dos últimos minutos de jogo, que consome FPS.",
                Details = "O Game DVR fica gravando a tela o tempo todo para você poder salvar \"o que acabou de acontecer\". Isso usa a placa de vídeo e o disco. Se você não usa esse recurso, desligar devolve alguns quadros por segundo.",
                Actions =
                {
                    D("HKCU", GCS, "GameDVR_Enabled", 0, 1),
                    D("HKCU", @"Software\Microsoft\Windows\CurrentVersion\GameDVR", "AppCaptureEnabled", 0, 1),
                    D("HKLM", POL + @"\GameDVR", "AllowGameDVR", 0),
                }
            });
            t.Add(new Tweak
            {
                Id = "game_bar", Category = CatGames,
                Title = "Desativar a Xbox Game Bar",
                Description = "A barra que abre com Win+G para de carregar junto com os jogos.",
                Details = "A Game Bar mostra widgets por cima do jogo (desempenho, áudio, chat do Xbox). Desligar deixa o jogo mais leve se você não usa esses recursos.",
                Warning = "Win+G deixa de abrir a Game Bar e a captura de tela/vídeo do Xbox para de funcionar.",
                Actions =
                {
                    D("HKCU", @"Software\Microsoft\GameBar", "UseNexusForGameBarEnabled", 0, 1),
                    D("HKCU", @"Software\Microsoft\GameBar", "ShowStartupPanel", 0, 1),
                }
            });
            t.Add(new Tweak
            {
                Id = "fso", Category = CatGames, Risk = Risk.Moderate,
                Title = "Desativar otimizações de tela cheia",
                Description = "Jogos em tela cheia rodam no modo exclusivo, sem a camada do Windows por cima.",
                Details = "As \"otimizações de tela cheia\" fazem o jogo rodar como uma janela sem bordas disfarçada. Em alguns jogos (principalmente competitivos e mais antigos), desligar reduz o atraso do mouse e melhora a estabilidade do FPS.",
                Warning = "O Alt+Tab pode ficar mais lento e a tela piscar ao trocar de janela. Em jogos novos a diferença costuma ser pequena.",
                Actions =
                {
                    D("HKCU", GCS, "GameDVR_FSEBehaviorMode", 2),
                    D("HKCU", GCS, "GameDVR_HonorUserFSEBehaviorMode", 1),
                    D("HKCU", GCS, "GameDVR_FSEBehavior", 2),
                    D("HKCU", GCS, "GameDVR_DXGIHonorFSEWindowsCompatible", 1),
                }
            });
            t.Add(new Tweak
            {
                Id = "mmcss_games", Category = CatGames, Recommended = true,
                Title = "Prioridade máxima de CPU e placa de vídeo para jogos",
                Description = "Ajusta o agendador multimídia do Windows (MMCSS) para dar preferência aos jogos.",
                Details = "O Windows tem um perfil interno chamado \"Games\". Aqui ele recebe prioridade alta de CPU, de placa de vídeo e de acesso ao disco, e o sistema reserva menos processamento para tarefas de fundo durante o jogo (SystemResponsiveness = 10).",
                Actions =
                {
                    D("HKLM", MMSP + @"\Tasks\Games", "GPU Priority", 8, 8),
                    D("HKLM", MMSP + @"\Tasks\Games", "Priority", 6, 2),
                    Sz("HKLM", MMSP + @"\Tasks\Games", "Scheduling Category", "High", "Medium"),
                    Sz("HKLM", MMSP + @"\Tasks\Games", "SFIO Priority", "High", "Normal"),
                    D("HKLM", MMSP, "SystemResponsiveness", 10, 20),
                }
            });
            t.Add(new Tweak
            {
                Id = "mouse_accel", Category = CatGames, Restart = Restart.Logoff,
                Title = "Desativar aceleração do mouse",
                Description = "O cursor anda sempre a mesma distância para o mesmo movimento da mão.",
                Details = "Com a aceleração (\"Aumentar a precisão do ponteiro\") o cursor anda mais quando você move o mouse rápido. Em jogos de tiro isso atrapalha a mira, porque o mesmo gesto dá resultados diferentes. Desligar deixa o movimento 1:1.",
                Actions =
                {
                    Sz("HKCU", @"Control Panel\Mouse", "MouseSpeed", "0", "1"),
                    Sz("HKCU", @"Control Panel\Mouse", "MouseThreshold1", "0", "6"),
                    Sz("HKCU", @"Control Panel\Mouse", "MouseThreshold2", "0", "10"),
                }
            });
            t.Add(new Tweak
            {
                Id = "sticky_keys", Category = CatGames, Recommended = true,
                Title = "Desativar o atalho das Teclas de Aderência (Shift 5 vezes)",
                Description = "Apertar Shift várias vezes no jogo não abre mais a janela das Teclas de Aderência.",
                Details = "Quem joga aperta Shift muitas vezes seguidas e a janela das Teclas de Aderência aparece no meio da partida, minimizando o jogo. Isto só desliga o atalho; o recurso continua disponível em Acessibilidade.",
                Actions =
                {
                    Sz("HKCU", @"Control Panel\Accessibility\StickyKeys", "Flags", "506", "510"),
                    Sz("HKCU", @"Control Panel\Accessibility\ToggleKeys", "Flags", "58", "62"),
                    Sz("HKCU", @"Control Panel\Accessibility\Keyboard Response", "Flags", "122", "126"),
                }
            });
            t.Add(new Tweak
            {
                Id = "xbox_off", Category = CatGames, Risk = Risk.Advanced,
                Title = "Desativar TOTALMENTE o Xbox",
                Description = "Desliga os serviços do Xbox, a Game Bar e a gravação de jogos.",
                Details = "Para quem não usa nada da Microsoft para jogos. Desativa os serviços de login, salvamento na nuvem e rede do Xbox, além da Game Bar e do Game DVR. Libera um pouco de memória e tira processos de fundo.",
                Warning = "Game Pass, app Xbox, jogos da Microsoft Store (Forza, Minecraft Bedrock etc.), conquistas e o controle de Xbox sem fio podem parar de funcionar. Dá para desfazer a qualquer momento.",
                Actions =
                {
                    Svc("XblAuthManager", 3), Svc("XblGameSave", 3), Svc("XboxNetApiSvc", 3), Svc("XboxGipSvc", 3),
                    D("HKCU", @"Software\Microsoft\GameBar", "UseNexusForGameBarEnabled", 0, 1),
                    D("HKCU", GCS, "GameDVR_Enabled", 0, 1),
                    D("HKLM", POL + @"\GameDVR", "AllowGameDVR", 0),
                }
            });
            t.Add(new Tweak
            {
                Id = "core_isolation", Category = CatGames, Risk = Risk.Advanced, Restart = Restart.Reboot,
                Title = "Desativar Isolamento de Núcleo (Integridade de Memória)",
                Description = "Desliga a proteção de drivers por virtualização, que pode custar de 5% a 10% de FPS.",
                Details = "A Integridade de Memória (HVCI) usa a virtualização do processador para impedir que drivers maliciosos rodem. Em alguns jogos isso reduz o desempenho. A própria Microsoft recomenda desligar para quem prioriza jogos.",
                Warning = "Reduz a proteção contra vírus que atacam drivers. Mantenha o antivírus ligado. Alguns anti-cheats (ex.: Valorant em certos casos) exigem a proteção ligada.",
                Actions = { D("HKLM", @"SYSTEM\CurrentControlSet\Control\DeviceGuard\Scenarios\HypervisorEnforcedCodeIntegrity", "Enabled", 0, 1) }
            });
            t.Add(new Tweak
            {
                Id = "vbs", Category = CatGames, Risk = Risk.Advanced, Restart = Restart.Reboot,
                Title = "Desativar VBS (Segurança Baseada em Virtualização)",
                Description = "Desliga a camada de segurança que roda o Windows sobre um mini-hipervisor.",
                Details = "O VBS vem ligado em muitos PCs novos com Windows 11 e é a base do Isolamento de Núcleo. Benchmarks mostram ganho de desempenho em jogos ao desligar. Combine com o ajuste acima.",
                Warning = "Diminui a segurança do sistema. Em PCs de empresa pode ser exigido pela política de TI. Se o Windows estiver com bloqueio UEFI, o ajuste pode não ter efeito.",
                Actions =
                {
                    D("HKLM", @"SYSTEM\CurrentControlSet\Control\DeviceGuard", "EnableVirtualizationBasedSecurity", 0),
                    D("HKLM", @"SYSTEM\CurrentControlSet\Control\DeviceGuard", "RequirePlatformSecurityFeatures", 0),
                }
            });

            // =================================================================
            //  ENERGIA
            // =================================================================
            t.Add(new Tweak
            {
                Id = "ultimate_plan", Category = CatPower, Risk = Risk.Moderate, NotebookWarning = true,
                Title = "Plano de energia Desempenho Máximo",
                Description = "Cria e ativa um plano de energia sem economia: o processador não reduz a velocidade.",
                Details = "Baseado no plano oculto \"Desempenho Máximo\" (Ultimate Performance) do Windows. Elimina pequenas economias de energia que causam atrasos ao acordar o processador. Ao desfazer, o plano anterior volta a ser usado.",
                Warning = "Esquenta e gasta mais energia. Em notebook, a bateria dura menos. Os perfis de \"Hardware e internet\" e o Modo jogo também trocam o plano de energia.",
                Actions =
                {
                    new ScriptAction("ultimate_plan",
                        $@"$g='{ULTIMATE}'
$a = powercfg /getactivescheme | Out-String
if ($a -notmatch $g -and $a -match '([0-9a-fA-F]{{8}}-[0-9a-fA-F]{{4}}-[0-9a-fA-F]{{4}}-[0-9a-fA-F]{{4}}-[0-9a-fA-F]{{12}})') {{
  New-Item 'HKCU:\Software\THSuite' -Force | Out-Null
  Set-ItemProperty 'HKCU:\Software\THSuite' -Name PrevPowerScheme -Value $Matches[1]
}}
if (-not ((powercfg /list | Out-String) -match $g)) {{ powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61 $g | Out-Null }}
if (-not ((powercfg /list | Out-String) -match $g)) {{ powercfg -duplicatescheme 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c $g | Out-Null }}
powercfg -changename $g 'TH Suite - Desempenho Maximo' 'Criado pelo TH Suite'
powercfg -setactive $g",
                        $@"$g='{ULTIMATE}'
$p = (Get-ItemProperty 'HKCU:\Software\THSuite' -ErrorAction SilentlyContinue).PrevPowerScheme
if (-not $p -or $p -eq $g) {{ $p = '381b4222-f694-41f0-9685-ff5bb260df2e' }}
powercfg -setactive $p
powercfg -delete $g",
                        () => Proc.Run("powercfg.exe", "/getactivescheme", 10000).Output.Contains(ULTIMATE, StringComparison.OrdinalIgnoreCase))
                }
            });
            t.Add(new Tweak
            {
                Id = "usb_suspend", Category = CatPower, Recommended = true,
                Title = "Desativar suspensão seletiva de USB",
                Description = "O Windows para de \"desligar\" portas USB ociosas para economizar energia.",
                Details = "A suspensão seletiva coloca dispositivos USB para dormir quando acha que não estão em uso. Isso pode causar pequenas travadas, mouse e teclado que \"somem\" por um instante e headsets que cortam. Vale para o plano de energia atual.",
                NotebookWarning = true,
                Actions = { new PowerSetting("2a737441-1930-4402-8d77-b2bebba308a3", "48e6b7a6-50f5-4782-a5d4-53bb8f07e226", 0, 1) }
            });
            t.Add(new Tweak
            {
                Id = "pcie_aspm", Category = CatPower, Recommended = true, NotebookWarning = true,
                Title = "Desativar economia de energia do PCIe",
                Description = "Placa de vídeo, SSD NVMe e placa de rede ficam sempre na velocidade total.",
                Details = "O \"Gerenciamento de Energia do Estado do Link\" reduz a energia do barramento PCIe quando há pouco uso. Acordar desse estado leva alguns milissegundos e pode causar engasgos. Em desktop é seguro desligar.",
                Actions = { new PowerSetting("501a4d13-42af-4429-9fd1-a8218c268e20", "ee12f906-d277-404b-b6da-e5fa1a576df5", 0, 1) }
            });
            t.Add(new Tweak
            {
                Id = "core_parking", Category = CatPower, Risk = Risk.Moderate, NotebookWarning = true,
                Title = "Desativar estacionamento de núcleos (Core Parking)",
                Description = "Todos os núcleos do processador ficam acordados e prontos para trabalhar.",
                Details = "O Windows \"estaciona\" (desliga) núcleos ociosos para economizar energia. Quando um jogo precisa deles de repente, acordá-los causa microtravamentos. Desligar o estacionamento deixa o processador mais responsivo.",
                Warning = "Aumenta um pouco o consumo e a temperatura em repouso.",
                Actions = { new PowerSetting("54533251-82be-4824-96c1-47b60b740d00", "0cc5b647-c1df-4637-891a-dec35c318583", 100, 10, hidden: true) }
            });
            t.Add(new Tweak
            {
                Id = "power_throttling", Category = CatPower, Risk = Risk.Moderate, NotebookWarning = true,
                Title = "Desativar Power Throttling e EcoQoS",
                Description = "Programas em segundo plano não são mais colocados em modo de economia.",
                Details = "O Windows reduz a velocidade de programas que considera \"de fundo\" (EcoQoS). Às vezes ele erra: um render, download, gravação ou o Discord durante o jogo ficam lentos. Desligar faz todos os programas rodarem na velocidade normal.",
                Warning = "Não recomendado para notebook na bateria: o consumo aumenta.",
                Actions = { D("HKLM", @"SYSTEM\CurrentControlSet\Control\Power\PowerThrottling", "PowerThrottlingOff", 1) }
            });
            t.Add(new Tweak
            {
                Id = "disk_sleep", Category = CatPower,
                Title = "Nunca desligar o disco rígido",
                Description = "Os discos não \"dormem\" depois de alguns minutos parados.",
                Details = "Evita aquela travada de alguns segundos quando um HD precisa voltar a girar ao abrir uma pasta ou carregar um jogo. Em SSD não faz diferença.",
                Actions = { new PowerSetting("0012ee47-9041-4b5d-9b77-535fba8b1442", "6738e2c4-e8a5-4a42-b16a-e040e769756e", 0, 1200) }
            });
            t.Add(new Tweak
            {
                Id = "hibernation", Category = CatPower,
                Title = "Desativar hibernação",
                Description = "Apaga o arquivo hiberfil.sys e libera vários GB no disco C:.",
                Details = "A hibernação guarda toda a RAM em um arquivo do tamanho de boa parte da sua memória. Em desktop quase ninguém usa. Desligar libera esse espaço na hora. A suspensão (dormir) continua funcionando.",
                Warning = "Também desliga a Inicialização Rápida. Em notebook, o PC não hiberna sozinho quando a bateria acaba.",
                Actions =
                {
                    new ScriptAction("hibernation", "powercfg /hibernate off", "powercfg /hibernate on",
                        () => RegIs("HKLM", @"SYSTEM\CurrentControlSet\Control\Power", "HibernateEnabled", 0))
                }
            });
            t.Add(new Tweak
            {
                Id = "fast_startup", Category = CatPower,
                Title = "Desativar Inicialização Rápida",
                Description = "\"Desligar\" passa a desligar o Windows de verdade.",
                Details = "A Inicialização Rápida não desliga o Windows por completo: ela hiberna o núcleo do sistema. Isso faz drivers e atualizações não serem recarregados e é causa comum de PC que \"não desliga\", periféricos que somem e erros estranhos que só somem ao reiniciar. O boot pode levar alguns segundos a mais.",
                Actions = { D("HKLM", @"SYSTEM\CurrentControlSet\Control\Session Manager\Power", "HiberbootEnabled", 0, 1) }
            });

            // =================================================================
            //  PLACA DE VÍDEO
            // =================================================================
            t.Add(new Tweak
            {
                Id = "hags", Category = CatGpu, Risk = Risk.Moderate, Restart = Restart.Reboot,
                Title = "Agendamento de GPU acelerado por hardware (HAGS)",
                Description = "A placa de vídeo organiza a própria memória, tirando trabalho do processador.",
                Details = "Com o HAGS, a placa de vídeo gerencia a fila de tarefas sozinha. Reduz um pouco o atraso e ajuda em processadores mais fracos. É obrigatório para o DLSS 3 (Geração de Quadros) da NVIDIA. Precisa de placa GTX 1000 / RX 5000 / Intel Arc ou mais nova e driver atualizado.",
                Warning = "Em placas antigas ou drivers desatualizados pode causar travadas. Se notar problemas, desfaça.",
                Actions = { D("HKLM", @"SYSTEM\CurrentControlSet\Control\GraphicsDrivers", "HwSchMode", 2, 1) }
            });
            t.Add(new Tweak
            {
                Id = "mpo", Category = CatGpu, Risk = Risk.Moderate, Restart = Restart.Reboot,
                Title = "Desativar MPO (Multiplane Overlay)",
                Description = "Corrige telas piscando, cintilação e travadas com dois monitores.",
                Details = "O MPO é um recurso do Windows que mistura camadas de imagem direto na placa de vídeo. Com alguns drivers NVIDIA e AMD ele causa tela piscando, faixas pretas e engasgos em vídeos e jogos, principalmente com monitores de taxas diferentes. A NVIDIA já recomendou desligar para quem tem o problema.",
                Actions = { D("HKLM", @"SOFTWARE\Microsoft\Windows\Dwm", "OverlayTestMode", 5) }
            });
            t.Add(new Tweak
            {
                Id = "nvidia_tel", Category = CatGpu, Vendor = "nvidia", Recommended = true,
                Title = "Desativar telemetria da NVIDIA",
                Description = "O driver NVIDIA para de coletar e enviar dados de uso.",
                Details = "Desliga o serviço e as tarefas de telemetria que acompanham o driver da NVIDIA. O driver, o Painel de Controle e o app NVIDIA continuam funcionando normalmente.",
                Actions =
                {
                    new ServiceStart("NvTelemetryContainer", 4, 2),
                    D("HKLM", @"SOFTWARE\NVIDIA Corporation\NvControlPanel2\Client", "OptInOrOutPreference", 0, 1),
                    D("HKLM", @"SOFTWARE\NVIDIA Corporation\Global\FTS", "EnableRID44231", 0, optional: true),
                    D("HKLM", @"SOFTWARE\NVIDIA Corporation\Global\FTS", "EnableRID64640", 0, optional: true),
                    D("HKLM", @"SOFTWARE\NVIDIA Corporation\Global\FTS", "EnableRID66610", 0, optional: true),
                }
            });
            t.Add(new Tweak
            {
                Id = "amd_ulps", Category = CatGpu, Vendor = "amd", Risk = Risk.Moderate, Restart = Restart.Reboot,
                Title = "Desativar ULPS (AMD)",
                Description = "A placa AMD não entra no modo de ultra economia quando está ociosa.",
                Details = "O ULPS (Ultra Low Power State) desliga partes da placa AMD em repouso. Em CrossFire, notebooks com dois vídeos e algumas placas, acordar desse estado causa tela preta, travadas ou clock que não sobe. Desligar resolve.",
                Warning = "A placa consome um pouco mais em repouso.",
                Actions = { new RegEach(@"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}", "EnableUlps", 0, 1) }
            });
            t.Add(new Tweak
            {
                Id = "gpu_tdr", Category = CatGpu, Risk = Risk.Moderate, Restart = Restart.Reboot,
                Title = "Mais tempo antes de reiniciar o driver de vídeo (TDR)",
                Description = "Evita o erro \"o driver de vídeo parou de responder e foi recuperado\" em cargas pesadas.",
                Details = "Se a placa de vídeo demora mais de 2 segundos para responder, o Windows reinicia o driver (tela pisca e o jogo/render fecha). Em renderização, IA e jogos muito pesados isso pode acontecer à toa. Aumentar para 8 segundos dá mais folga.",
                Actions = { D("HKLM", @"SYSTEM\CurrentControlSet\Control\GraphicsDrivers", "TdrDelay", 8) }
            });

            // =================================================================
            //  REDE
            // =================================================================
            t.Add(new Tweak
            {
                Id = "net_throttle", Category = CatNet, Recommended = true,
                Title = "Desativar limitação de rede do Windows",
                Description = "O Windows para de limitar pacotes de rede enquanto toca áudio ou vídeo.",
                Details = "Por padrão o Windows segura o tráfego de rede quando há mídia tocando, para o som não falhar. Em PCs atuais isso só aumenta a latência em jogos (ex.: jogar com música ou Discord aberto). Mesma opção da aba Internet para jogos.",
                Actions = { D("HKLM", MMSP, "NetworkThrottlingIndex", unchecked((int)0xFFFFFFFF), 10) }
            });
            t.Add(new Tweak
            {
                Id = "net_power", Category = CatNet, Recommended = true, NotebookWarning = true,
                Title = "Desativar economia de energia da placa de rede",
                Description = "O Windows não desliga a placa de rede (cabo ou Wi-Fi) para economizar energia.",
                Details = "Com a economia ligada, a placa de rede pode \"cochilar\" e causar picos de ping, quedas rápidas e Wi-Fi que desconecta depois de voltar da suspensão. A conexão cai por 2 ou 3 segundos ao aplicar.",
                Warning = "Desliga também o \"Wake on LAN\" (ligar o PC pela rede).",
                Actions =
                {
                    new ScriptAction("net_power",
                        "Get-NetAdapter -Physical | ForEach-Object { Disable-NetAdapterPowerManagement -Name $_.Name -ErrorAction SilentlyContinue }",
                        "Get-NetAdapter -Physical | ForEach-Object { Enable-NetAdapterPowerManagement -Name $_.Name -ErrorAction SilentlyContinue }",
                        () => PsBool("@(Get-NetAdapter -Physical | Get-NetAdapterPowerManagement -ErrorAction SilentlyContinue | Where-Object { $_.AllowComputerToTurnOffDevice -eq 'Enabled' }).Count -eq 0"))
                }
            });
            t.Add(new Tweak
            {
                Id = "delivery_opt", Category = CatNet, Recommended = true,
                Title = "Não enviar atualizações para outros PCs da internet",
                Description = "O Windows para de usar a sua internet para mandar atualizações para outras pessoas.",
                Details = "A \"Otimização de Entrega\" faz o seu PC funcionar como um servidor de atualizações para outros computadores, usando o seu upload. Isso pode aumentar o ping em jogos e gastar franquia. As atualizações continuam chegando normalmente pela Microsoft.",
                Actions = { D("HKLM", POL + @"\DeliveryOptimization", "DODownloadMode", 0) }
            });
            t.Add(new Tweak
            {
                Id = "teredo", Category = CatNet, Risk = Risk.Moderate,
                Title = "Desativar Teredo (IPv6 por túnel)",
                Description = "Desliga um adaptador virtual antigo que encapsula IPv6 dentro do IPv4.",
                Details = "O Teredo era usado quando a internet não tinha IPv6. Hoje raramente é necessário e, em algumas redes, atrasa a conexão ou atrapalha o NAT de jogos.",
                Warning = "O chat em grupo do app Xbox pode precisar do Teredo. Se aparecer \"Teredo não consegue se qualificar\" no Xbox, desfaça.",
                Actions = { new ScriptAction("teredo", "netsh interface teredo set state disabled", "netsh interface teredo set state default") }
            });

            // =================================================================
            //  PRIVACIDADE
            // =================================================================
            t.Add(new Tweak
            {
                Id = "telemetry", Category = CatPrivacy, Recommended = true,
                Title = "Desativar telemetria do Windows",
                Description = "Reduz ao mínimo os dados de uso que o Windows envia para a Microsoft.",
                Details = "Desliga o serviço \"Experiências do Usuário Conectado e Telemetria\" (DiagTrack) e define a coleta de dados no menor nível permitido pela sua edição do Windows. Também economiza um pouco de disco e internet.",
                Actions =
                {
                    D("HKLM", POL + @"\DataCollection", "AllowTelemetry", 0),
                    D("HKLM", @"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection", "AllowTelemetry", 0, optional: true),
                    Svc("DiagTrack", 2),
                    Svc("dmwappushservice", 3),
                }
            });
            t.Add(new Tweak
            {
                Id = "telemetry_tasks", Category = CatPrivacy, Recommended = true,
                Title = "Desativar tarefas agendadas de telemetria",
                Description = "Para as tarefas que de tempos em tempos coletam informações do PC.",
                Details = "O Windows tem tarefas que rodam escondidas para analisar compatibilidade, uso de disco e experiência do usuário, e enviar o resultado. Elas podem causar uso alto de disco e CPU em momentos aleatórios.",
                Actions =
                {
                    new TaskOff(@"\Microsoft\Windows\Application Experience\Microsoft Compatibility Appraiser"),
                    new TaskOff(@"\Microsoft\Windows\Application Experience\ProgramDataUpdater"),
                    new TaskOff(@"\Microsoft\Windows\Customer Experience Improvement Program\Consolidator"),
                    new TaskOff(@"\Microsoft\Windows\Customer Experience Improvement Program\UsbCeip"),
                    new TaskOff(@"\Microsoft\Windows\Autochk\Proxy"),
                    new TaskOff(@"\Microsoft\Windows\DiskDiagnostic\Microsoft-Windows-DiskDiagnosticDataCollector"),
                    new TaskOff(@"\Microsoft\Windows\Feedback\Siuf\DmClient"),
                    new TaskOff(@"\Microsoft\Windows\Feedback\Siuf\DmClientOnScenarioDownload"),
                }
            });
            t.Add(new Tweak
            {
                Id = "ad_id", Category = CatPrivacy, Recommended = true,
                Title = "Desativar ID de publicidade",
                Description = "Apps não recebem mais um identificador para mostrar anúncios personalizados.",
                Details = "O Windows cria um ID único para cada usuário que apps e sites usam para rastrear seus interesses e direcionar propaganda. Desligar não tira os anúncios, só deixa de personalizá-los.",
                Actions =
                {
                    D("HKCU", @"Software\Microsoft\Windows\CurrentVersion\AdvertisingInfo", "Enabled", 0, 1),
                    D("HKLM", @"SOFTWARE\Policies\Microsoft\Windows\AdvertisingInfo", "DisabledByGroupPolicy", 1),
                }
            });
            t.Add(new Tweak
            {
                Id = "activity", Category = CatPrivacy, Recommended = true,
                Title = "Desativar histórico de atividades",
                Description = "O Windows para de registrar os programas, arquivos e sites que você abre.",
                Details = "O histórico de atividades guarda o que você fez no PC para a \"Linha do Tempo\" e para sincronizar entre dispositivos. Desligar é mais privado e evita gravações constantes no disco.",
                Actions =
                {
                    D("HKLM", POL + @"\System", "EnableActivityFeed", 0),
                    D("HKLM", POL + @"\System", "PublishUserActivities", 0),
                    D("HKLM", POL + @"\System", "UploadUserActivities", 0),
                }
            });
            t.Add(new Tweak
            {
                Id = "tailored", Category = CatPrivacy, Recommended = true,
                Title = "Desativar dicas, sugestões e experiências personalizadas",
                Description = "Sem dicas, \"sugestões\" e propagandas do Windows baseadas no seu uso.",
                Details = "Desliga as dicas do Windows, as sugestões em Configurações e as \"experiências personalizadas\" que usam seus dados de diagnóstico para mostrar ofertas da Microsoft.",
                Actions =
                {
                    D("HKCU", @"Software\Microsoft\Windows\CurrentVersion\Privacy", "TailoredExperiencesWithDiagnosticDataEnabled", 0, 1),
                    D("HKCU", CDM, "SubscribedContent-338389Enabled", 0, 1),
                    D("HKCU", CDM, "SubscribedContent-338393Enabled", 0, 1),
                    D("HKCU", CDM, "SubscribedContent-353694Enabled", 0, 1),
                    D("HKCU", CDM, "SubscribedContent-353696Enabled", 0, 1),
                    D("HKCU", CDM, "SoftLandingEnabled", 0, 1),
                }
            });
            t.Add(new Tweak
            {
                Id = "feedback", Category = CatPrivacy, Recommended = true,
                Title = "O Windows nunca pede feedback",
                Description = "Sem janelas perguntando \"o que você acha do Windows?\".",
                Actions =
                {
                    D("HKCU", @"Software\Microsoft\Siuf\Rules", "NumberOfSIUFInPeriod", 0),
                    D("HKLM", POL + @"\DataCollection", "DoNotShowFeedbackNotifications", 1),
                },
                Details = "Desliga os pedidos de avaliação e as pesquisas que o Hub de Comentários mostra de tempos em tempos."
            });
            t.Add(new Tweak
            {
                Id = "typing", Category = CatPrivacy,
                Title = "Não enviar dados de digitação e escrita",
                Description = "O Windows para de coletar o que você digita e escreve para \"melhorar o reconhecimento\".",
                Details = "Desliga a personalização de digitação e de escrita à tinta, que analisa as palavras que você usa e pode enviar amostras para a Microsoft.",
                Actions =
                {
                    D("HKCU", @"Software\Microsoft\Input\TIPC", "Enabled", 0, 1),
                    D("HKCU", @"Software\Microsoft\InputPersonalization", "RestrictImplicitInkCollection", 1, 0),
                    D("HKCU", @"Software\Microsoft\InputPersonalization", "RestrictImplicitTextCollection", 1, 0),
                }
            });
            t.Add(new Tweak
            {
                Id = "recall", Category = CatPrivacy, Recommended = true,
                Title = "Desativar Recall e análise por IA",
                Description = "Impede que o Windows tire \"fotos\" da tela para a busca por IA (Windows 11 24H2).",
                Details = "O Recall salva capturas da sua tela a cada poucos segundos para você pesquisar depois. Mesmo que fique só no PC, isso guarda senhas, conversas e documentos visíveis. Este ajuste bloqueia o recurso.",
                Actions =
                {
                    D("HKCU", @"Software\Policies\Microsoft\Windows\WindowsAI", "DisableAIDataAnalysis", 1),
                    D("HKLM", POL + @"\WindowsAI", "DisableAIDataAnalysis", 1),
                }
            });
            t.Add(new Tweak
            {
                Id = "cloud_clipboard", Category = CatPrivacy,
                Title = "Desativar área de transferência na nuvem",
                Description = "O que você copia não é mais sincronizado com a sua conta Microsoft.",
                Details = "A área de transferência na nuvem envia o que você copia (textos, senhas, imagens) para outros dispositivos da mesma conta. O histórico local (Win+V) continua funcionando.",
                Actions = { D("HKLM", POL + @"\System", "AllowCrossDeviceClipboard", 0) }
            });
            t.Add(new Tweak
            {
                Id = "smb1", Category = CatPrivacy, Recommended = true,
                Title = "Desativar o protocolo SMBv1 (inseguro)",
                Description = "Desliga a versão antiga do compartilhamento de arquivos, usada pelo vírus WannaCry.",
                Details = "O SMBv1 tem mais de 30 anos e falhas graves de segurança. Só aparelhos muito antigos (alguns NAS, impressoras e TV boxes) ainda dependem dele. O compartilhamento de arquivos moderno (SMBv2/v3) continua funcionando.",
                Actions =
                {
                    new ScriptAction("smb1",
                        "Set-SmbServerConfiguration -EnableSMB1Protocol $false -Force -ErrorAction Stop",
                        "Set-SmbServerConfiguration -EnableSMB1Protocol $true -Force -ErrorAction Stop",
                        () => PsBool("-not (Get-SmbServerConfiguration).EnableSMB1Protocol"))
                }
            });
            t.Add(new Tweak
            {
                Id = "office_tel", Category = CatPrivacy,
                Title = "Desativar telemetria do Office",
                Description = "Word, Excel e companhia param de enviar dados de uso.",
                Details = "Define as políticas que desligam a coleta de dados de diagnóstico do Microsoft Office / Microsoft 365. Os programas continuam funcionando normalmente.",
                Actions =
                {
                    D("HKCU", @"Software\Policies\Microsoft\Office\16.0\Common\ClientTelemetry", "DisableTelemetry", 1),
                    D("HKCU", @"Software\Policies\Microsoft\Office\16.0\Common\ClientTelemetry", "SendTelemetry", 3),
                    D("HKCU", @"Software\Policies\Microsoft\Office\Common\ClientTelemetry", "SendTelemetry", 3),
                    D("HKCU", @"Software\Policies\Microsoft\Office\16.0\Common", "QMEnable", 0),
                }
            });
            t.Add(new Tweak
            {
                Id = "browser_tel", Category = CatPrivacy,
                Title = "Desativar telemetria do Chrome, Edge e Firefox",
                Description = "Os navegadores param de enviar estatísticas de uso e relatórios de falha.",
                Details = "Usa as políticas oficiais de cada navegador para desligar o envio de métricas. Suas abas, favoritos e sincronização não mudam.",
                Warning = "O Chrome e o Edge passam a mostrar \"Gerenciado pela sua organização\" no menu. Isso é normal com políticas.",
                Actions =
                {
                    D("HKLM", @"SOFTWARE\Policies\Google\Chrome", "MetricsReportingEnabled", 0),
                    D("HKLM", @"SOFTWARE\Policies\Google\Chrome", "ChromeCleanupReportingEnabled", 0),
                    D("HKLM", @"SOFTWARE\Policies\Microsoft\Edge", "MetricsReportingEnabled", 0),
                    D("HKLM", @"SOFTWARE\Policies\Microsoft\Edge", "PersonalizationReportingEnabled", 0),
                    D("HKLM", @"SOFTWARE\Policies\Mozilla\Firefox", "DisableTelemetry", 1),
                    D("HKLM", @"SOFTWARE\Policies\Mozilla\Firefox", "DisableDefaultBrowserAgent", 1),
                }
            });
            t.Add(new Tweak
            {
                Id = "vs_tel", Category = CatPrivacy,
                Title = "Desativar telemetria do Visual Studio",
                Description = "O Visual Studio para de participar do Programa de Aperfeiçoamento.",
                Details = "Só faz diferença para quem programa com o Visual Studio. Desliga a coleta de dados de uso (SQM).",
                Actions =
                {
                    D("HKLM", @"SOFTWARE\Policies\Microsoft\VisualStudio\SQM", "OptIn", 0),
                    D("HKLM", @"SOFTWARE\Microsoft\VSCommon\17.0\SQM", "OptIn", 0, optional: true),
                }
            });

            // =================================================================
            //  WINDOWS 11 E VISUAL
            // =================================================================
            t.Add(new Tweak
            {
                Id = "start_ads", Category = CatUi, Recommended = true, Restart = Restart.Explorer,
                Title = "Remover recomendações e anúncios do Iniciar",
                Description = "O Iniciar para de sugerir apps, arquivos \"recomendados\" e ofertas da Microsoft.",
                Details = "Desliga as recomendações e propagandas do menu Iniciar e impede que o Windows instale sozinho jogos e apps de parceiros (como Candy Crush) em contas novas.",
                Actions =
                {
                    D("HKCU", ADV, "Start_IrisRecommendations", 0, 1),
                    D("HKCU", ADV, "Start_AccountNotifications", 0, 1),
                    D("HKCU", CDM, "SystemPaneSuggestionsEnabled", 0, 1),
                    D("HKCU", CDM, "SubscribedContent-338388Enabled", 0, 1),
                    D("HKCU", CDM, "SilentInstalledAppsEnabled", 0, 1),
                    D("HKLM", POL + @"\CloudContent", "DisableWindowsConsumerFeatures", 1),
                }
            });
            t.Add(new Tweak
            {
                Id = "web_search", Category = CatUi, Recommended = true, Restart = Restart.Explorer,
                Title = "Pesquisa do Iniciar só no PC (sem Bing)",
                Description = "A busca do Iniciar fica mais rápida e não mostra resultados da internet.",
                Details = "Por padrão, tudo o que você digita no Iniciar também é enviado ao Bing. Desligar deixa a pesquisa mais rápida, mais privada e focada nos seus programas e arquivos.",
                Actions =
                {
                    D("HKCU", @"Software\Policies\Microsoft\Windows\Explorer", "DisableSearchBoxSuggestions", 1),
                    D("HKCU", @"Software\Microsoft\Windows\CurrentVersion\Search", "BingSearchEnabled", 0),
                }
            });
            t.Add(new Tweak
            {
                Id = "widgets", Category = CatUi, Recommended = true, Restart = Restart.Explorer,
                Title = "Desativar Widgets (notícias e clima)",
                Description = "Remove o painel de notícias e clima da barra de tarefas.",
                Details = "O painel de Widgets carrega notícias e anúncios do MSN e mantém processos rodando (Widgets.exe, WebView2). Desligar economiza memória e internet.",
                Actions =
                {
                    D("HKLM", @"SOFTWARE\Policies\Microsoft\Dsh", "AllowNewsAndInterests", 0),
                    D("HKCU", ADV, "TaskbarDa", 0, 1, optional: true),
                }
            });
            t.Add(new Tweak
            {
                Id = "copilot", Category = CatUi, Recommended = true, Restart = Restart.Explorer,
                Title = "Desativar Copilot",
                Description = "Remove o assistente de IA da Microsoft da barra de tarefas.",
                Details = "Desliga o Copilot do Windows e esconde o botão. Se você usa o Copilot, deixe como está.",
                Actions =
                {
                    D("HKCU", @"Software\Policies\Microsoft\Windows\WindowsCopilot", "TurnOffWindowsCopilot", 1),
                    D("HKLM", POL + @"\WindowsCopilot", "TurnOffWindowsCopilot", 1),
                    D("HKCU", ADV, "ShowCopilotButton", 0, 1, optional: true),
                }
            });
            t.Add(new Tweak
            {
                Id = "chat", Category = CatUi, Restart = Restart.Explorer,
                Title = "Remover Chat (Teams pessoal) da barra de tarefas",
                Description = "Esconde o ícone do Teams pessoal no Windows 11.",
                Actions =
                {
                    D("HKCU", ADV, "TaskbarMn", 0, 1, optional: true),
                    D("HKLM", POL + @"\Windows Chat", "ChatIcon", 3),
                },
                Details = "O botão de Chat abre o Teams gratuito. Se você não usa, esconder deixa a barra mais limpa."
            });
            t.Add(new Tweak
            {
                Id = "taskbar_left", Category = CatUi, Restart = Restart.Explorer,
                Title = "Alinhar barra de tarefas à esquerda",
                Description = "O botão Iniciar e os ícones voltam para o canto esquerdo, como no Windows 10.",
                Details = "Só muda a posição dos ícones. Ao desfazer eles voltam para o centro.",
                Actions = { D("HKCU", ADV, "TaskbarAl", 0, 1) }
            });
            t.Add(new Tweak
            {
                Id = "search_icon", Category = CatUi, Restart = Restart.Explorer,
                Title = "Barra de tarefas: pesquisa só como ícone",
                Description = "Troca a caixa de pesquisa grande por um ícone de lupa.",
                Details = "Libera espaço na barra de tarefas. A pesquisa continua igual (clique na lupa ou aperte a tecla Windows e digite).",
                Actions = { D("HKCU", @"Software\Microsoft\Windows\CurrentVersion\Search", "SearchboxTaskbarMode", 1, 2) }
            });
            t.Add(new Tweak
            {
                Id = "task_view", Category = CatUi, Restart = Restart.Explorer,
                Title = "Esconder botão Visão de Tarefas",
                Description = "Remove o botão das áreas de trabalho virtuais da barra de tarefas.",
                Details = "O atalho Win+Tab continua funcionando.",
                Actions = { D("HKCU", ADV, "ShowTaskViewButton", 0, 1) }
            });
            t.Add(new Tweak
            {
                Id = "classic_menu", Category = CatUi, Restart = Restart.Explorer,
                Title = "Menu de contexto clássico (botão direito)",
                Description = "O botão direito volta a mostrar todas as opções, sem o \"Mostrar mais opções\".",
                Details = "No Windows 11, o menu do botão direito esconde várias opções (como as do WinRAR e 7-Zip) atrás de \"Mostrar mais opções\". Este ajuste traz de volta o menu completo do Windows 10.",
                Actions = { new RegKey("HKCU", @"Software\Classes\CLSID\{86ca1aa0-34aa-4e8b-a509-50c905bae2a2}\InprocServer32") }
            });
            t.Add(new Tweak
            {
                Id = "end_task", Category = CatUi, Recommended = true, Restart = Restart.Explorer,
                Title = "Botão \"Finalizar tarefa\" na barra de tarefas",
                Description = "Clique com o botão direito em um app travado na barra e feche na hora.",
                Details = "Adiciona a opção \"Finalizar tarefa\" ao menu dos ícones da barra de tarefas (Windows 11 23H2 ou mais novo). Não precisa mais abrir o Gerenciador de Tarefas para fechar um programa travado.",
                Actions = { D("HKCU", ADV + @"\TaskbarDeveloperSettings", "TaskbarEndTask", 1) }
            });
            t.Add(new Tweak
            {
                Id = "show_ext", Category = CatUi, Recommended = true, Restart = Restart.Explorer,
                Title = "Mostrar extensões de arquivos",
                Description = "Mostra o final do nome dos arquivos (.exe, .pdf, .jpg...).",
                Details = "Além de ajudar a saber o tipo de cada arquivo, é uma proteção: vírus costumam se disfarçar com nomes como \"foto.jpg.exe\", que sem as extensões aparece só como \"foto.jpg\".",
                Actions = { D("HKCU", ADV, "HideFileExt", 0, 1) }
            });
            t.Add(new Tweak
            {
                Id = "show_hidden", Category = CatUi, Restart = Restart.Explorer,
                Title = "Mostrar arquivos e pastas ocultos",
                Description = "O Explorador passa a exibir arquivos ocultos (aparecem meio transparentes).",
                Details = "Útil para achar pastas como AppData e arquivos de configuração. Arquivos protegidos do sistema continuam escondidos.",
                Actions = { D("HKCU", ADV, "Hidden", 1, 2) }
            });
            t.Add(new Tweak
            {
                Id = "this_pc", Category = CatUi, Restart = Restart.Explorer,
                Title = "Explorador abre em \"Este Computador\"",
                Description = "Ao abrir o Explorador, aparecem os discos em vez de arquivos recentes.",
                Actions = { D("HKCU", ADV, "LaunchTo", 1) },
                Details = "Mostra direto os discos e pastas principais, o que é mais útil para a maioria das pessoas do que a página \"Início\"."
            });
            t.Add(new Tweak
            {
                Id = "no_recent", Category = CatUi, Restart = Restart.Explorer,
                Title = "Não mostrar arquivos recentes no Explorador",
                Description = "O Acesso Rápido para de listar arquivos e pastas abertos recentemente.",
                Details = "Mais privacidade se outras pessoas usam o PC. As pastas fixadas continuam lá.",
                Actions =
                {
                    D("HKCU", @"Software\Microsoft\Windows\CurrentVersion\Explorer", "ShowRecent", 0, 1),
                    D("HKCU", @"Software\Microsoft\Windows\CurrentVersion\Explorer", "ShowFrequent", 0, 1),
                }
            });
            t.Add(new Tweak
            {
                Id = "compact", Category = CatUi, Restart = Restart.Explorer,
                Title = "Modo compacto no Explorador",
                Description = "Diminui o espaço entre os itens para caber mais arquivos na tela.",
                Details = "O Windows 11 aumentou o espaçamento pensando em telas de toque. O modo compacto volta ao visual mais denso do Windows 10.",
                Actions = { D("HKCU", ADV, "UseCompactMode", 1, 0) }
            });
            t.Add(new Tweak
            {
                Id = "snap", Category = CatUi,
                Title = "Desativar sugestões do Snap",
                Description = "Ao encaixar uma janela no canto, o Windows não sugere outras janelas para o outro lado.",
                Actions = { D("HKCU", ADV, "SnapAssist", 0, 1) },
                Details = "O encaixe de janelas (arrastar para o canto, Win+setas) continua funcionando."
            });
            t.Add(new Tweak
            {
                Id = "lock_ads", Category = CatUi, Recommended = true,
                Title = "Remover dicas e anúncios da tela de bloqueio",
                Description = "Sem \"curiosidades\" e propagandas por cima da imagem da tela de bloqueio.",
                Actions =
                {
                    D("HKCU", CDM, "RotatingLockScreenOverlayEnabled", 0, 1),
                    D("HKCU", CDM, "SubscribedContent-338387Enabled", 0, 1),
                },
                Details = "A imagem de fundo continua igual; só somem os textos com dicas e ofertas."
            });
            t.Add(new Tweak
            {
                Id = "long_paths", Category = CatUi, Recommended = true,
                Title = "Permitir caminhos de arquivo longos",
                Description = "Programas podem usar pastas com mais de 260 caracteres no caminho.",
                Details = "Resolve erros ao extrair, copiar ou instalar coisas com muitas pastas dentro de pastas (comum em projetos de programação, mods de jogos e backups).",
                Actions = { D("HKLM", @"SYSTEM\CurrentControlSet\Control\FileSystem", "LongPathsEnabled", 1, 0) }
            });
            t.Add(new Tweak
            {
                Id = "cortana", Category = CatUi,
                Title = "Desativar Cortana",
                Description = "Impede a assistente Cortana de rodar.",
                Actions = { D("HKLM", POL + @"\Windows Search", "AllowCortana", 0) },
                Details = "A Cortana foi descontinuada pela Microsoft, mas ainda vem em algumas instalações do Windows 10 e 11."
            });

            // =================================================================
            //  SERVIÇOS
            // =================================================================
            void S(string id, string title, string desc, string details, string warn, Risk risk, bool rec, params (string Name, int Def)[] svcs)
            {
                var tw = new Tweak { Id = id, Category = CatServices, Title = title, Description = desc, Details = details, Warning = warn, Risk = risk, Recommended = rec };
                foreach (var s in svcs) tw.Actions.Add(Svc(s.Name, s.Def));
                t.Add(tw);
            }
            S("svc_fax", "Fax", "Desativa o serviço de envio e recebimento de fax.", "Só é útil se o PC está ligado a uma linha telefônica com modem de fax.", "", Risk.Safe, true, ("Fax", 3));
            S("svc_retail", "Modo de demonstração de loja", "Desativa o serviço usado em PCs de exposição nas lojas.", "Esse serviço só funciona quando o Windows está no modo demonstração das lojas.", "", Risk.Safe, true, ("RetailDemo", 3));
            S("svc_maps", "Mapas baixados", "Para o serviço que atualiza mapas offline do app Mapas.", "Se você não usa o app Mapas do Windows com mapas baixados, este serviço só ocupa recursos.", "", Risk.Safe, true, ("MapsBroker", 2));
            S("svc_insider", "Programa Windows Insider", "Desativa o serviço das versões de teste do Windows.", "Só é necessário se você participa do programa Insider (versões beta do Windows).", "", Risk.Safe, true, ("wisvc", 3));
            S("svc_remote_reg", "Registro remoto", "Impede que outros computadores alterem o registro deste PC pela rede.", "Já vem desligado em muitas versões. Manter desativado é mais seguro.", "", Risk.Safe, true, ("RemoteRegistry", 4));
            S("svc_wmp", "Compartilhamento do Windows Media Player", "Para o compartilhamento de músicas e vídeos pela rede do Media Player antigo.", "Quase ninguém usa esse recurso hoje.", "", Risk.Safe, true, ("WMPNetworkSvc", 3));
            S("svc_parental", "Controle dos Pais", "Desativa o serviço de controle parental da Família Microsoft.", "Só é necessário se crianças usam este PC com uma conta da Família Microsoft.", "", Risk.Safe, false, ("WpcMonSvc", 3));
            S("svc_spooler", "Spooler de impressão", "Para o serviço que gerencia impressoras.", "Se você não tem impressora, desativar economiza memória e fecha uma porta que já foi usada por vírus (PrintNightmare).", "Nenhuma impressora vai funcionar (nem \"Imprimir para PDF\") enquanto estiver desativado.", Risk.Moderate, false, ("Spooler", 2));
            S("svc_sensors", "Sensores", "Desativa os serviços de sensores (rotação de tela, luz ambiente).", "Em desktop esses serviços não têm o que fazer.", "Em notebook e tablet, a rotação automática da tela e o brilho automático param de funcionar.", Risk.Moderate, false, ("SensorService", 3), ("SensrSvc", 3), ("SensorDataService", 3));
            S("svc_bio", "Biometria (Windows Hello)", "Desativa o serviço de leitura de digital e reconhecimento facial.", "Se o PC não tem leitor de digital nem câmera de reconhecimento facial, o serviço é inútil.", "Desativa o login por digital e por rosto do Windows Hello.", Risk.Moderate, false, ("WbioSrvc", 3));
            S("svc_geo", "Localização", "Desativa o serviço de localização do Windows.", "Apps não conseguem mais saber onde você está.", "O app Clima, mapas, \"Encontrar meu dispositivo\" e o fuso horário automático param de funcionar.", Risk.Moderate, false, ("lfsvc", 3));
            S("svc_phone", "Telefonia e Vincular ao Celular", "Desativa serviços usados para ligações pelo PC.", "Só fazem falta se você usa o app Vincular ao Celular para fazer ligações.", "Chamadas pelo app Vincular ao Celular deixam de funcionar.", Risk.Moderate, false, ("PhoneSvc", 3), ("TapiSrv", 3));
            S("svc_smartcard", "Cartão inteligente", "Desativa o serviço de leitores de cartão inteligente.", "Só necessário para quem usa leitor de cartão ou token USB.", "NÃO desative se você usa certificado digital A3 (token ou cartão), como e-CPF, e-CNPJ ou assinatura de documentos.", Risk.Moderate, false, ("SCardSvr", 3));

            // =================================================================
            //  WINDOWS UPDATE
            // =================================================================
            t.Add(new Tweak
            {
                Id = "wu_restart", Category = CatUpdate, Recommended = true,
                Title = "Não reiniciar sozinho com alguém usando o PC",
                Description = "O Windows Update espera você reiniciar em vez de reiniciar no meio do uso.",
                Details = "Evita perder trabalho ou uma partida porque o Windows decidiu reiniciar para instalar atualizações. Você continua recebendo as atualizações normalmente.",
                Actions = { D("HKLM", POL + @"\WindowsUpdate\AU", "NoAutoRebootWithLoggedOnUsers", 1) }
            });
            t.Add(new Tweak
            {
                Id = "wu_drivers", Category = CatUpdate,
                Title = "Não instalar drivers pelo Windows Update",
                Description = "O Windows não troca mais os drivers que você instalou (ex.: vídeo).",
                Details = "O Windows Update às vezes substitui o driver da placa de vídeo, áudio ou rede por uma versão mais antiga ou genérica, causando problemas. Com este ajuste, você atualiza os drivers pelo site do fabricante.",
                Warning = "Em PCs novos, alguns drivers básicos podem deixar de ser instalados automaticamente.",
                Actions = { D("HKLM", POL + @"\WindowsUpdate", "ExcludeWUDriversInQualityUpdate", 1) }
            });
            t.Add(new Tweak
            {
                Id = "store_auto", Category = CatUpdate,
                Title = "Desativar atualização automática da Microsoft Store",
                Description = "Os apps da Store só atualizam quando você manda.",
                Details = "Evita que a Store baixe atualizações grandes em segundo plano (inclusive jogos do Game Pass) durante partidas ou em internet limitada.",
                Actions = { D("HKLM", @"SOFTWARE\Policies\Microsoft\WindowsStore", "AutoDownload", 2) }
            });
            t.Add(new Tweak
            {
                Id = "wu_defer", Category = CatUpdate, Risk = Risk.Moderate,
                Title = "Adiar grandes atualizações do Windows por 1 ano",
                Description = "Atualizações de versão (ex.: 24H2 → 25H2) só chegam depois de 365 dias.",
                Details = "As atualizações de segurança continuam chegando todo mês. Só as grandes atualizações de recursos, que às vezes trazem bugs no lançamento, ficam para depois. Funciona no Windows Pro, Enterprise e Education.",
                Warning = "No Windows Home esta política é ignorada.",
                Actions =
                {
                    D("HKLM", POL + @"\WindowsUpdate", "DeferFeatureUpdates", 1),
                    D("HKLM", POL + @"\WindowsUpdate", "DeferFeatureUpdatesPeriodInDays", 365),
                }
            });
            t.Add(new Tweak
            {
                Id = "wu_auto_off", Category = CatUpdate, Risk = Risk.Advanced,
                Title = "Desativar atualizações automáticas",
                Description = "O Windows só procura e instala atualizações quando você mandar.",
                Details = "Para quem quer controle total sobre quando atualizar (ex.: PC usado para trabalho ou competições). Você pode atualizar manualmente em Configurações > Windows Update.",
                Warning = "Sem atualizações o PC fica vulnerável a vírus e falhas de segurança. Lembre de atualizar manualmente pelo menos uma vez por mês.",
                Actions = { D("HKLM", POL + @"\WindowsUpdate\AU", "NoAutoUpdate", 1) }
            });

            return t;
        }
    }
}

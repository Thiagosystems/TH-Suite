using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace THSuite.Optimizer
{
    /// <summary>App que vem com o Windows e pode ser removido.</summary>
    public class BloatApp : Bindable
    {
        public string Pattern { get; init; } = "";      // nome do pacote (aceita *)
        public string Name { get; init; } = "";
        public string Description { get; init; } = "";
        public string Warning { get; init; } = "";
        public bool Recommended { get; init; }
        public List<string> Packages { get; } = new(); // nomes completos encontrados

        bool _checked;
        string _status = "";
        public bool IsChecked { get => _checked; set => Set(ref _checked, value); }
        public string Status { get => _status; set => Set(ref _status, value); }
        public bool Installed => Packages.Count > 0;
    }

    public static class Debloat
    {
        public static List<BloatApp> Catalog() => new()
        {
            new() { Pattern = "Microsoft.BingNews", Name = "Notícias (Microsoft Start)", Description = "Notícias do MSN com anúncios.", Recommended = true },
            new() { Pattern = "Microsoft.BingWeather", Name = "Clima", Description = "Previsão do tempo do MSN." },
            new() { Pattern = "Microsoft.BingSearch", Name = "Pesquisa do Bing", Description = "Integração extra do Bing com o Windows.", Recommended = true },
            new() { Pattern = "Microsoft.GetHelp", Name = "Obter Ajuda", Description = "Chat de suporte da Microsoft.", Recommended = true },
            new() { Pattern = "Microsoft.Getstarted", Name = "Dicas", Description = "App de dicas e tutoriais do Windows.", Recommended = true },
            new() { Pattern = "Microsoft.WindowsFeedbackHub", Name = "Hub de Comentários", Description = "Envio de sugestões e bugs para a Microsoft.", Recommended = true },
            new() { Pattern = "Microsoft.MicrosoftSolitaireCollection", Name = "Microsoft Solitaire Collection", Description = "Jogos de cartas com anúncios.", Recommended = true },
            new() { Pattern = "Microsoft.People", Name = "Pessoas", Description = "Agenda de contatos antiga.", Recommended = true },
            new() { Pattern = "Microsoft.WindowsMaps", Name = "Mapas", Description = "Mapas offline da Microsoft.", Recommended = true },
            new() { Pattern = "Microsoft.MixedReality.Portal", Name = "Portal de Realidade Misturada", Description = "Só útil com óculos de realidade virtual do Windows.", Recommended = true },
            new() { Pattern = "Microsoft.Microsoft3DViewer", Name = "Visualizador 3D", Description = "Abre modelos 3D.", Recommended = true },
            new() { Pattern = "Microsoft.MSPaint", Name = "Paint 3D", Description = "Editor 3D descontinuado (o Paint normal continua).", Recommended = true },
            new() { Pattern = "Microsoft.Office.OneNote", Name = "OneNote para Windows 10", Description = "Versão antiga do OneNote." },
            new() { Pattern = "Microsoft.MicrosoftOfficeHub", Name = "Microsoft 365 (Office)", Description = "Atalho para o Office online com propaganda da assinatura. Não remove o Office instalado.", Recommended = true },
            new() { Pattern = "Microsoft.SkypeApp", Name = "Skype", Description = "O Skype foi encerrado pela Microsoft.", Recommended = true },
            new() { Pattern = "MicrosoftTeams", Name = "Teams (pessoal)", Description = "Versão gratuita do Teams para uso pessoal.", Recommended = true },
            new() { Pattern = "MSTeams", Name = "Microsoft Teams", Description = "Teams novo.", Warning = "Não remova se usa o Teams para trabalho ou escola." },
            new() { Pattern = "Microsoft.Todos", Name = "Microsoft To Do", Description = "Lista de tarefas." },
            new() { Pattern = "Microsoft.PowerAutomateDesktop", Name = "Power Automate", Description = "Automação de tarefas para empresas.", Recommended = true },
            new() { Pattern = "Clipchamp.Clipchamp", Name = "Clipchamp", Description = "Editor de vídeo online.", Recommended = true },
            new() { Pattern = "Microsoft.549981C3F5F10", Name = "Cortana", Description = "Assistente descontinuada.", Recommended = true },
            new() { Pattern = "Microsoft.ZuneVideo", Name = "Filmes e TV", Description = "Player de vídeo antigo." },
            new() { Pattern = "Microsoft.ZuneMusic", Name = "Media Player / Groove", Description = "Player de música.", Warning = "No Windows 11 este é o \"Media Player\" padrão. Instale outro player (ex.: VLC) antes." },
            new() { Pattern = "Microsoft.YourPhone", Name = "Vincular ao Celular", Description = "Integração do Android/iPhone com o PC." },
            new() { Pattern = "Microsoft.WindowsAlarms", Name = "Relógio e Alarmes", Description = "Alarmes, timer e cronômetro." },
            new() { Pattern = "Microsoft.WindowsSoundRecorder", Name = "Gravador de Som", Description = "Gravação de áudio simples." },
            new() { Pattern = "Microsoft.MicrosoftStickyNotes", Name = "Notas Autoadesivas", Description = "Post-its na área de trabalho." },
            new() { Pattern = "microsoft.windowscommunicationsapps", Name = "Email e Calendário (antigo)", Description = "Substituído pelo novo Outlook." },
            new() { Pattern = "Microsoft.OutlookForWindows", Name = "Outlook (novo)", Description = "Cliente de e-mail novo da Microsoft." },
            new() { Pattern = "MicrosoftCorporationII.QuickAssist", Name = "Assistência Rápida", Description = "Acesso remoto da Microsoft. Golpistas costumam pedir para abrir este app.", Recommended = true },
            new() { Pattern = "Microsoft.Wallet", Name = "Carteira", Description = "Carteira digital descontinuada.", Recommended = true },
            new() { Pattern = "MicrosoftCorporationII.MicrosoftFamily", Name = "Família Microsoft", Description = "Controle parental.", Recommended = true },
            new() { Pattern = "Microsoft.Copilot", Name = "Copilot", Description = "Assistente de IA da Microsoft." },
            new() { Pattern = "Microsoft.Windows.DevHome", Name = "Dev Home", Description = "Painel para programadores (descontinuado).", Recommended = true },
            new() { Pattern = "Microsoft.GamingApp", Name = "Xbox", Description = "App Xbox / Game Pass.", Warning = "Necessário para o Game Pass e jogos da Microsoft no PC." },
            new() { Pattern = "Microsoft.XboxGamingOverlay", Name = "Xbox Game Bar", Description = "Barra do Win+G.", Warning = "Alguns jogos mostram aviso pedindo a Game Bar." },
            new() { Pattern = "Microsoft.XboxSpeechToTextOverlay", Name = "Xbox Fala para Texto", Description = "Legendas do chat de voz do Xbox.", Recommended = true },
            new() { Pattern = "*CandyCrush*", Name = "Candy Crush", Description = "Jogo pré-instalado por parceiros.", Recommended = true },
            new() { Pattern = "*BubbleWitch*", Name = "Bubble Witch", Description = "Jogo pré-instalado por parceiros.", Recommended = true },
            new() { Pattern = "*Spotify*", Name = "Spotify (atalho de instalação)", Description = "Remove o Spotify instalado pela Store." },
            new() { Pattern = "*Disney*", Name = "Disney+", Description = "Atalho pré-instalado.", Recommended = true },
            new() { Pattern = "*Facebook*", Name = "Facebook", Description = "Atalho pré-instalado.", Recommended = true },
            new() { Pattern = "*Instagram*", Name = "Instagram", Description = "Atalho pré-instalado.", Recommended = true },
            new() { Pattern = "*TikTok*", Name = "TikTok", Description = "Atalho pré-instalado.", Recommended = true },
            new() { Pattern = "*AmazonPrimeVideo*", Name = "Prime Video", Description = "Atalho pré-instalado.", Recommended = true },
            new() { Pattern = "*LinkedIn*", Name = "LinkedIn", Description = "Atalho pré-instalado.", Recommended = true },
        };

        /// <summary>Procura quais apps da lista estão instalados.</summary>
        public static async Task ScanAsync(List<BloatApp> apps)
        {
            var (_, output) = await Cmd.PowerShellAsync("Get-AppxPackage | ForEach-Object { $_.Name + '|' + $_.PackageFullName }", null, 60000);
            var installed = output.Split('\n').Select(l => l.Trim()).Where(l => l.Contains('|'))
                .Select(l => (Name: l[..l.IndexOf('|')], Full: l[(l.IndexOf('|') + 1)..])).ToList();
            foreach (var a in apps)
            {
                a.Packages.Clear();
                var rx = new Regex("^" + Regex.Escape(a.Pattern).Replace("\\*", ".*") + "$", RegexOptions.IgnoreCase);
                foreach (var p in installed.Where(p => rx.IsMatch(p.Name))) a.Packages.Add(p.Full);
            }
        }

        /// <summary>Remove o app do usuário atual (e, opcionalmente, impede que volte em contas novas).</summary>
        public static async Task<bool> RemoveAsync(BloatApp app, bool provisioned)
        {
            string pat = app.Pattern.Replace("'", "");
            string script = $"Get-AppxPackage -Name '{pat}' | Remove-AppxPackage -ErrorAction SilentlyContinue; ";
            if (provisioned)
                script += $"Get-AppxProvisionedPackage -Online | Where-Object {{ $_.DisplayName -like '{pat}' }} | Remove-AppxProvisionedPackage -Online -ErrorAction SilentlyContinue | Out-Null; ";
            script += $"if (Get-AppxPackage -Name '{pat}') {{ 'AINDA' }} else {{ 'OK' }}";
            var (_, o) = await Cmd.PowerShellAsync(script, null, 180000);
            return o.Contains("OK");
        }
    }
}

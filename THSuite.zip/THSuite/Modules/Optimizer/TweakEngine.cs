using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace THSuite.Optimizer
{
    public enum Risk { Safe, Moderate, Advanced }
    public enum Restart { None, Explorer, Logoff, Reboot }

    // =====================================================================
    //  Backup: guarda o valor original de tudo que o otimizador muda
    // =====================================================================

    public class TweakRecord
    {
        public bool Applied { get; set; }
        public DateTime Date { get; set; }
        public Dictionary<string, string?> Originals { get; set; } = new();
    }

    public class BackupStore
    {
        public Dictionary<string, TweakRecord> Tweaks { get; set; } = new();

        static string FilePath => Path.Combine(SuiteSettings.DataDir, "otimizador-backup.json");

        public static BackupStore Load()
        {
            try
            {
                if (File.Exists(FilePath))
                    return JsonSerializer.Deserialize<BackupStore>(File.ReadAllText(FilePath)) ?? new BackupStore();
            }
            catch { }
            return new BackupStore();
        }

        public void Save()
        {
            try
            {
                Directory.CreateDirectory(SuiteSettings.DataDir);
                File.WriteAllText(FilePath, JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true }));
            }
            catch { }
        }

        public TweakRecord For(string id)
        {
            if (!Tweaks.TryGetValue(id, out var r)) Tweaks[id] = r = new TweakRecord();
            return r;
        }
    }

    // =====================================================================
    //  Ações
    // =====================================================================

    /// <summary>Uma alteração no sistema que sabe se está aplicada, aplicar e desfazer.</summary>
    public abstract class TweakAction
    {
        /// <summary>true = aplicada, false = não aplicada, null = não dá para saber (ou não existe neste PC).</summary>
        public abstract bool? IsApplied();
        public abstract void Apply(TweakRecord r);
        public abstract void Revert(TweakRecord r);
        /// <summary>Se falhar, não conta como erro (ex.: valor protegido em algumas versões do Windows).</summary>
        public bool Optional { get; init; }
        /// <summary>Esta ação não existe neste PC (ex.: serviço não instalado).</summary>
        public virtual bool Exists => true;
    }

    internal static class Reg
    {
        public static RegistryKey Root(string hive) => hive switch
        {
            "HKCU" => Registry.CurrentUser,
            "HKCR" => Registry.ClassesRoot,
            _ => Registry.LocalMachine
        };

        public static object? Get(string hive, string path, string name)
        {
            try
            {
                using var k = Root(hive).OpenSubKey(path);
                return k?.GetValue(name, null, RegistryValueOptions.DoNotExpandEnvironmentNames);
            }
            catch { return null; }
        }

        public static RegistryValueKind? Kind(string hive, string path, string name)
        {
            try
            {
                using var k = Root(hive).OpenSubKey(path);
                if (k == null || k.GetValue(name) == null) return null;
                return k.GetValueKind(name);
            }
            catch { return null; }
        }

        public static void Set(string hive, string path, string name, object value, RegistryValueKind kind)
        {
            using var k = Root(hive).CreateSubKey(path, true) ?? throw new Exception("Não foi possível abrir " + path);
            k.SetValue(name, value, kind);
        }

        public static void Delete(string hive, string path, string name)
        {
            using var k = Root(hive).OpenSubKey(path, true);
            k?.DeleteValue(name, false);
        }

        /// <summary>Texto para guardar no backup ("kind|valor").</summary>
        public static string? Serialize(object? v, RegistryValueKind? kind)
        {
            if (v == null || kind == null) return null;
            string data = v switch
            {
                byte[] b => Convert.ToBase64String(b),
                string[] a => string.Join("\u0001", a),
                int i => i.ToString(),
                long l => l.ToString(),
                _ => v.ToString() ?? ""
            };
            return $"{(int)kind}|{data}";
        }

        public static (object Value, RegistryValueKind Kind) Deserialize(string s)
        {
            int p = s.IndexOf('|');
            var kind = (RegistryValueKind)int.Parse(s[..p]);
            string d = s[(p + 1)..];
            object v = kind switch
            {
                RegistryValueKind.DWord => int.Parse(d),
                RegistryValueKind.QWord => long.Parse(d),
                RegistryValueKind.Binary => Convert.FromBase64String(d),
                RegistryValueKind.MultiString => d.Split('\u0001'),
                _ => d
            };
            return (v, kind);
        }

        public static bool Same(object? a, object? b)
        {
            if (a == null || b == null) return a == null && b == null;
            if (a is byte[] x && b is byte[] y) return x.SequenceEqual(y);
            if (a is int ia && b is int ib) return ia == ib;
            return string.Equals(Convert.ToString(a), Convert.ToString(b), StringComparison.OrdinalIgnoreCase);
        }
    }

    /// <summary>Valor do registro. Ao desfazer, volta o valor original (ou o padrão do Windows).</summary>
    public class RegValue : TweakAction
    {
        public string Hive { get; }
        public string Path { get; }
        public string Name { get; }
        public object Value { get; }
        public RegistryValueKind Kind { get; }
        /// <summary>Valor usado ao desfazer se não houver backup. null = apagar o valor.</summary>
        public object? Default { get; init; }

        public RegValue(string hive, string path, string name, object value, RegistryValueKind kind = RegistryValueKind.DWord)
        {
            Hive = hive; Path = path; Name = name; Value = value; Kind = kind;
        }

        string Key => $"reg:{Hive}\\{Path}\\{Name}";

        public override bool? IsApplied() => Reg.Same(Reg.Get(Hive, Path, Name), Value);

        public override void Apply(TweakRecord r)
        {
            if (!r.Originals.ContainsKey(Key))
                r.Originals[Key] = Reg.Serialize(Reg.Get(Hive, Path, Name), Reg.Kind(Hive, Path, Name));
            Reg.Set(Hive, Path, Name, Value, Kind);
        }

        public override void Revert(TweakRecord r)
        {
            if (r.Originals.TryGetValue(Key, out var orig))
            {
                if (orig == null) Reg.Delete(Hive, Path, Name);
                else { var (v, k) = Reg.Deserialize(orig); Reg.Set(Hive, Path, Name, v, k); }
                r.Originals.Remove(Key);
            }
            else if (Default == null) Reg.Delete(Hive, Path, Name);
            else Reg.Set(Hive, Path, Name, Default, Kind);
        }
    }

    /// <summary>Chave do registro que precisa existir (ex.: menu de contexto clássico).</summary>
    public class RegKey : TweakAction
    {
        readonly string _hive, _path;
        public RegKey(string hive, string path) { _hive = hive; _path = path; }

        public override bool? IsApplied()
        {
            try { using var k = Reg.Root(_hive).OpenSubKey(_path); return k != null; } catch { return false; }
        }

        public override void Apply(TweakRecord r)
        {
            using var k = Reg.Root(_hive).CreateSubKey(_path, true);
            k?.SetValue("", "", RegistryValueKind.String);
        }

        public override void Revert(TweakRecord r)
        {
            // apaga a chave pai criada (ex.: CLSID\{...})
            string parent = _path.Contains('\\') ? _path[.._path.LastIndexOf('\\')] : _path;
            Reg.Root(_hive).DeleteSubKeyTree(parent, false);
        }
    }

    /// <summary>Tipo de inicialização de um serviço (2 automático, 3 manual, 4 desativado).</summary>
    public class ServiceStart : TweakAction
    {
        readonly string _name;
        readonly int _start, _default;
        string RegPath => @"SYSTEM\CurrentControlSet\Services\" + _name;

        public ServiceStart(string name, int start = 4, int defaultStart = 3)
        {
            _name = name; _start = start; _default = defaultStart;
        }

        public override bool Exists => Reg.Get("HKLM", RegPath, "Start") != null;

        public override bool? IsApplied()
        {
            var v = Reg.Get("HKLM", RegPath, "Start");
            if (v == null) return null;
            return v is int i && i == _start;
        }

        public override void Apply(TweakRecord r)
        {
            if (!Exists) return;
            string key = "svc:" + _name;
            if (!r.Originals.ContainsKey(key)) r.Originals[key] = Convert.ToString(Reg.Get("HKLM", RegPath, "Start"));
            Reg.Set("HKLM", RegPath, "Start", _start, RegistryValueKind.DWord);
            if (_start == 4) Proc.Run("sc.exe", $"stop \"{_name}\"", 15000);
        }

        public override void Revert(TweakRecord r)
        {
            if (!Exists) return;
            string key = "svc:" + _name;
            int start = r.Originals.TryGetValue(key, out var o) && int.TryParse(o, out int x) ? x : _default;
            Reg.Set("HKLM", RegPath, "Start", start, RegistryValueKind.DWord);
            r.Originals.Remove(key);
            if (start == 2) Proc.Run("sc.exe", $"start \"{_name}\"", 15000);
        }
    }

    /// <summary>Tarefa agendada do Windows que deve ficar desativada.</summary>
    public class TaskOff : TweakAction
    {
        readonly string _path;
        public TaskOff(string path) { _path = path; }

        string File => System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System), "Tasks", _path.TrimStart('\\'));
        public override bool Exists => System.IO.File.Exists(File);

        public override bool? IsApplied()
        {
            try
            {
                if (!Exists) return null;
                string xml = System.IO.File.ReadAllText(File);
                int s = xml.IndexOf("<Settings>", StringComparison.Ordinal);
                if (s < 0) return false;
                int e = xml.IndexOf("</Settings>", s, StringComparison.Ordinal);
                string settings = e > s ? xml[s..e] : xml[s..];
                // <Enabled> direto dentro de <Settings> (ignora o de <IdleSettings>)
                settings = Regex.Replace(settings, @"<IdleSettings>.*?</IdleSettings>", "", RegexOptions.Singleline);
                return settings.Contains("<Enabled>false</Enabled>");
            }
            catch { return null; }
        }

        public override void Apply(TweakRecord r) { if (Exists) Proc.Run("schtasks.exe", $"/Change /TN \"{_path}\" /Disable", 20000); }
        public override void Revert(TweakRecord r) { if (Exists) Proc.Run("schtasks.exe", $"/Change /TN \"{_path}\" /Enable", 20000); }
    }

    /// <summary>Configuração do plano de energia atual (CA e bateria).</summary>
    public class PowerSetting : TweakAction
    {
        readonly string _sub, _setting;
        readonly int _value, _default;
        readonly bool _hidden;

        public PowerSetting(string sub, string setting, int value, int defaultValue, bool hidden = false)
        {
            _sub = sub; _setting = setting; _value = value; _default = defaultValue; _hidden = hidden;
        }

        (int Ac, int Dc)? Current()
        {
            // Configurações ocultas não aparecem no /query até serem reveladas
            if (_hidden) Proc.Run("powercfg.exe", $"-attributes {_sub} {_setting} -ATTRIB_HIDE", 15000);
            var (code, output) = Proc.Run("powercfg.exe", $"/query SCHEME_CURRENT {_sub} {_setting}", 15000);
            if (code != 0) return null;
            var hex = Regex.Matches(output, @"0x([0-9a-fA-F]{8})").Select(m => Convert.ToInt32(m.Groups[1].Value, 16)).ToList();
            if (hex.Count < 2) return null;
            return (hex[^2], hex[^1]);
        }

        public override bool? IsApplied()
        {
            var c = Current();
            if (c == null) return null;
            return c.Value.Ac == _value && c.Value.Dc == _value;
        }

        public override void Apply(TweakRecord r)
        {
            string key = $"pwr:{_sub}:{_setting}";
            if (!r.Originals.ContainsKey(key) && Current() is { } c) r.Originals[key] = $"{c.Ac},{c.Dc}";
            Set(_value, _value);
        }

        public override void Revert(TweakRecord r)
        {
            string key = $"pwr:{_sub}:{_setting}";
            int ac = _default, dc = _default;
            if (r.Originals.TryGetValue(key, out var o) && o != null)
            {
                var p = o.Split(',');
                if (p.Length == 2) { int.TryParse(p[0], out ac); int.TryParse(p[1], out dc); }
                r.Originals.Remove(key);
            }
            Set(ac, dc);
        }

        void Set(int ac, int dc)
        {
            Proc.Run("powercfg.exe", $"/setacvalueindex SCHEME_CURRENT {_sub} {_setting} {ac}", 15000);
            Proc.Run("powercfg.exe", $"/setdcvalueindex SCHEME_CURRENT {_sub} {_setting} {dc}", 15000);
            Proc.Run("powercfg.exe", "/setactive SCHEME_CURRENT", 15000);
        }
    }

    /// <summary>Ação feita com comandos (PowerShell). Se não houver como detectar, usa o que o TH Suite registrou.</summary>
    public class ScriptAction : TweakAction
    {
        readonly Func<bool?>? _detect;
        readonly string _apply, _revert;
        readonly string _id;

        public ScriptAction(string id, string apply, string revert, Func<bool?>? detect = null)
        {
            _id = id; _apply = apply; _revert = revert; _detect = detect;
        }

        public override bool? IsApplied() => _detect?.Invoke();
        public override void Apply(TweakRecord r) => Proc.PowerShell(_apply);
        public override void Revert(TweakRecord r) => Proc.PowerShell(_revert);
    }

    /// <summary>Mesmo valor em todas as subchaves que já têm esse valor (ex.: EnableUlps das placas AMD).</summary>
    public class RegEach : TweakAction
    {
        readonly string _path, _name;
        readonly int _value, _default;

        public RegEach(string path, string name, int value, int defaultValue)
        {
            _path = path; _name = name; _value = value; _default = defaultValue;
        }

        List<string> Keys()
        {
            var list = new List<string>();
            try
            {
                using var root = Registry.LocalMachine.OpenSubKey(_path);
                if (root == null) return list;
                foreach (var sub in root.GetSubKeyNames())
                {
                    try
                    {
                        using var k = root.OpenSubKey(sub);
                        if (k?.GetValue(_name) != null) list.Add(_path + "\\" + sub);
                    }
                    catch { }
                }
            }
            catch { }
            return list;
        }

        public override bool Exists => Keys().Count > 0;

        public override bool? IsApplied()
        {
            var keys = Keys();
            if (keys.Count == 0) return null;
            return keys.All(k => Reg.Get("HKLM", k, _name) is int i && i == _value);
        }

        public override void Apply(TweakRecord r)
        {
            foreach (var k in Keys()) Reg.Set("HKLM", k, _name, _value, RegistryValueKind.DWord);
        }

        public override void Revert(TweakRecord r)
        {
            foreach (var k in Keys()) Reg.Set("HKLM", k, _name, _default, RegistryValueKind.DWord);
        }
    }

    /// <summary>Executa processos de forma síncrona (o otimizador roda em segundo plano).</summary>
    internal static class Proc
    {
        public static (int Code, string Output) Run(string exe, string args, int timeoutMs = 60000) =>
            Cmd.RunAsync(exe, args, null, timeoutMs).GetAwaiter().GetResult();

        public static (int Code, string Output) PowerShell(string script, int timeoutMs = 180000) =>
            Cmd.PowerShellAsync(script, null, timeoutMs).GetAwaiter().GetResult();
    }

    // =====================================================================
    //  Ajuste
    // =====================================================================

    public class Tweak : Bindable
    {
        public string Id { get; init; } = "";
        public string Category { get; init; } = "";
        public string Title { get; set; } = "";
        /// <summary>O que faz, em uma frase.</summary>
        public string Description { get; set; } = "";
        /// <summary>Explicação completa: por que usar, quando não usar.</summary>
        public string Details { get; init; } = "";
        public string Warning { get; init; } = "";
        public Risk Risk { get; init; } = Risk.Safe;
        public bool Recommended { get; init; }
        public Restart Restart { get; init; } = Restart.None;
        /// <summary>"nvidia", "amd", "intel" ou vazio.</summary>
        public string Vendor { get; init; } = "";
        public bool NotebookWarning { get; init; }
        public List<TweakAction> Actions { get; init; } = new();

        bool _applied, _desired, _expanded, _available = true, _busy;
        string _status = "";

        /// <summary>Estado atual no PC.</summary>
        public bool IsApplied
        {
            get => _applied;
            set { if (Set(ref _applied, value)) { OnChanged(nameof(Pending)); OnChanged(nameof(StateText)); } }
        }

        /// <summary>O que o usuário escolheu (o botão).</summary>
        public bool Desired
        {
            get => _desired;
            set { if (Set(ref _desired, value)) { OnChanged(nameof(Pending)); OnChanged(nameof(StateText)); PendingChanged?.Invoke(); } }
        }

        public bool Pending => Available && Desired != IsApplied;
        public bool Expanded { get => _expanded; set => Set(ref _expanded, value); }
        public bool Available { get => _available; set { if (Set(ref _available, value)) OnChanged(nameof(StateText)); } }
        public bool Busy { get => _busy; set => Set(ref _busy, value); }
        public string Status { get => _status; set => Set(ref _status, value); }

        public string StateText => !Available ? "Não se aplica a este PC"
                                 : Pending ? (Desired ? "Será ativado" : "Será desfeito")
                                 : IsApplied ? "Ativado" : "Desativado";

        public string RiskText => Risk switch { Risk.Advanced => "Avançado", Risk.Moderate => "Moderado", _ => "Seguro" };

        public string RestartText => Restart switch
        {
            Restart.Reboot => "Requer reiniciar o PC",
            Restart.Logoff => "Requer sair e entrar na conta",
            Restart.Explorer => "Reinicia o Explorer",
            _ => ""
        };

        public event Action? PendingChanged;

        /// <summary>Lê o estado no PC (rodar fora da thread da interface).</summary>
        public (bool Applied, bool Available) Detect(BackupStore store)
        {
            var existing = Actions.Where(a => a.Exists).ToList();
            if (existing.Count == 0) return (false, false);
            var states = existing.Select(a => a.IsApplied()).ToList();
            var known = states.Where(s => s.HasValue).Select(s => s!.Value).ToList();
            bool applied = known.Count > 0
                ? known.All(x => x)
                : store.Tweaks.TryGetValue(Id, out var rec) && rec.Applied;
            return (applied, true);
        }

        /// <summary>Aplica ou desfaz. Retorna as mensagens de erro (vazio = tudo certo).</summary>
        public List<string> Run(bool apply, BackupStore store)
        {
            var errors = new List<string>();
            var rec = store.For(Id);
            foreach (var a in apply ? Actions : Enumerable.Reverse(Actions))
            {
                try
                {
                    if (apply) a.Apply(rec); else a.Revert(rec);
                }
                catch (Exception ex)
                {
                    if (!a.Optional) errors.Add(ex.Message);
                }
            }
            rec.Applied = apply;
            rec.Date = DateTime.Now;
            if (!apply && rec.Originals.Count == 0) store.Tweaks.Remove(Id);
            return errors;
        }
    }
}

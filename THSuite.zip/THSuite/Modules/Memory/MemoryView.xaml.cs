using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
using WF = System.Windows.Forms;

namespace THSuite.Memory
{
    public partial class MemoryView : UserControl
    {
        const int MaxSamples = 300; // 5 min com 1 amostra/s

        readonly Settings _s = Settings.Load();
        readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromSeconds(1) };
        readonly GameBooster _booster;
        readonly SystemStats _stats = new();
        readonly HotkeyManager _hotkey = new();
        readonly OverlayWindow _overlay = new();
        readonly Queue<double> _samples = new();
        readonly Dictionary<string, DateTime> _procWarned = new(StringComparer.OrdinalIgnoreCase);


        GameProfile? _selectedGame; // null = perfil dos jogos detectados automaticamente
        double _targetPct, _shownPct = -1;
        int _lastIconKey = int.MinValue;
        bool? _danger;
        DateTime _lastClean = DateTime.Now, _lastLowWarn = DateTime.MinValue,
                 _lastProcList = DateTime.MinValue, _lastProcAlert = DateTime.MinValue;
        bool _cleaning, _bgBusy, _loading = true, _settingsOpen, _hotkeyAttached;

        public MemoryView()
        {
            InitializeComponent();

            _booster = new GameBooster(_s);
            _booster.GameStarted += name => Dispatcher.InvokeAsync(() =>
                ShowBalloon(Loc.T("T_GameDetected", name), null));
            _booster.Cleaned += freed => Dispatcher.InvokeAsync(() =>
                AddHistory(freed, "game", _booster.GameName));

            LoadSettingsToUi();
            HookEvents();

            _hotkey.Pressed += () => Dispatcher.InvokeAsync(() => _ = CleanAsync("hotkey"));
            Loaded += (_, _) =>
            {
                if (_hotkeyAttached) return;
                var w = Window.GetWindow(this);
                if (w == null) return;
                _hotkey.Attach(w);
                _hotkeyAttached = true;
                ApplyHotkey();
            };

            _timer.Tick += (_, _) => Tick();
            _timer.Start();
            Tick();

            CompositionTarget.Rendering += Animate;
            _loading = false;
        }

        // =====================================================================
        //  Integração com o TH Suite
        // =====================================================================

        /// <summary>Chamado quando o TH Suite fecha.</summary>
        public void Shutdown()
        {
            _timer.Stop();
            CompositionTarget.Rendering -= Animate;
            try { _booster.Stop(); } catch { }
            _hotkey.Dispose();
            try { _overlay.Close(); } catch { }
            _s.Save();
        }

        /// <summary>Abre uma aba: clean, auto, game, proc, hist, widget.</summary>
        public void ShowTab(string tab)
        {
            var rb = tab switch { "auto" => TabAuto, "game" => TabGame, "proc" => TabProc, "hist" => TabHist, "widget" => TabWidget, _ => TabClean };
            rb.IsChecked = true;
        }

        public Task CleanNowAsync() => CleanAsync("manual");

        /// <summary>Uso de memória atual (%).</summary>
        public double LoadPercent => _targetPct;

        public bool GameModeOn
        {
            get => ChkGameMode.IsChecked == true;
            set => ChkGameMode.IsChecked = value;
        }

        /// <summary>Recalcula cores que dependem do tema.</summary>
        public void OnThemeChanged()
        {
            _danger = null;
            UpdateGaugeColors();
            BuildGameList();
        }

        void ShowBalloon(string text, Action? onClick) => Host.Notify(text, onClick);

        void UpdateTray(int pct, ulong used, ulong total)
        {
            Host.SetTrayPart("1mem", $"RAM {pct}%");
            int key = _s.TrayShowPercent ? pct : -1;
            if (key == _lastIconKey) return;
            _lastIconKey = key;
            if (_s.TrayShowPercent) Host.SetTrayIcon(IconFactory.Percent(pct));
            else Host.ResetTrayIcon();
        }

        // =====================================================================
        //  Configurações
        // =====================================================================

        void LoadSettingsToUi()
        {
            _loading = true;
            ChkWorkingSet.IsChecked = _s.WorkingSet;
            ChkSystemCache.IsChecked = _s.SystemCache;
            ChkModified.IsChecked = _s.ModifiedList;
            ChkStandby.IsChecked = _s.StandbyList;
            ChkStandbyLow.IsChecked = _s.StandbyLowPriority;

            ChkAuto.IsChecked = _s.AutoClean;
            SldThreshold.Value = _s.AutoThreshold;
            ChkInterval.IsChecked = _s.IntervalClean;
            SldInterval.Value = _s.IntervalMinutes;
            ChkLowRam.IsChecked = _s.LowRamWarn;
            SldLowRam.Value = _s.LowRamThreshold;
            ChkProcAlert.IsChecked = _s.ProcAlert;
            SldProcAlert.Value = _s.ProcAlertMB;

            ChkGameMode.IsChecked = _s.GameMode;
            ChkGameDetect.IsChecked = _s.AutoDetectGames;
            TxtHeavy.Text = _s.HeavyApps;

            ChkWidget.IsChecked = _s.WidgetEnabled;
            ChkWidgetGame.IsChecked = _s.WidgetOnlyInGame;
            ChkWidgetExtra.IsChecked = _s.WidgetShowExtra;
            RbCornerTL.IsChecked = _s.WidgetCorner == 0;
            RbCornerTR.IsChecked = _s.WidgetCorner == 1;
            RbCornerBL.IsChecked = _s.WidgetCorner == 2;
            RbCornerBR.IsChecked = _s.WidgetCorner == 3;


            ChkHotkey.IsChecked = _s.HotkeyEnabled;
            TxtHotkey.Text = _s.Hotkey;
            ChkTrayPct.IsChecked = _s.TrayShowPercent;

            BuildGameList();
            LoadGameConfig();
            UpdateLabels();
            _loading = false;
        }

        void HookEvents()
        {
            foreach (var cb in new[] { ChkWorkingSet, ChkSystemCache, ChkModified, ChkStandby, ChkStandbyLow,
                                       ChkAuto, ChkInterval, ChkLowRam, ChkProcAlert,
                                       ChkGameMode, ChkGameDetect, ChkGameClean, ChkGamePower,
                                       ChkWidget, ChkWidgetGame, ChkWidgetExtra,
                                       ChkTrayPct })
            {
                cb.Checked += SettingChanged;
                cb.Unchecked += SettingChanged;
            }
            foreach (var sl in new[] { SldThreshold, SldInterval, SldLowRam, SldProcAlert, SldTrim })
                sl.ValueChanged += (_, _) => SettingChanged(null, null);

            foreach (var rb in new[] { RbHeavyNone, RbHeavyPause, RbHeavyClose })
                rb.Checked += SettingChanged;

            foreach (var rb in new[] { RbCornerTL, RbCornerTR, RbCornerBL, RbCornerBR })
                rb.Checked += Corner_Checked;





            ChkHotkey.Checked += (_, _) => HotkeyToggled();
            ChkHotkey.Unchecked += (_, _) => HotkeyToggled();
            TxtHotkey.GotKeyboardFocus += (_, _) => { _hotkey.Unregister(); TxtHotkey.Text = Loc.T("T_HotkeyPress"); };
            TxtHotkey.LostKeyboardFocus += (_, _) => { TxtHotkey.Text = _s.Hotkey; ApplyHotkey(); };
            TxtHotkey.PreviewKeyDown += HotkeyBox_KeyDown;


            TxtGame.KeyDown += (_, e) => { if (e.Key == Key.Enter) AddGame_Click(this, new RoutedEventArgs()); };
            TxtHeavy.LostFocus += (_, _) => CommitHeavy();
            TxtHeavy.KeyDown += (_, e) => { if (e.Key == Key.Enter) CommitHeavy(); };

        }

        void SettingChanged(object? sender, RoutedEventArgs? e)
        {
            UpdateLabels();
            if (_loading) return;

            _s.WorkingSet = ChkWorkingSet.IsChecked == true;
            _s.SystemCache = ChkSystemCache.IsChecked == true;
            _s.ModifiedList = ChkModified.IsChecked == true;
            _s.StandbyList = ChkStandby.IsChecked == true;
            _s.StandbyLowPriority = ChkStandbyLow.IsChecked == true;

            _s.AutoClean = ChkAuto.IsChecked == true;
            _s.AutoThreshold = (int)SldThreshold.Value;
            _s.IntervalClean = ChkInterval.IsChecked == true;
            _s.IntervalMinutes = (int)SldInterval.Value;
            _s.LowRamWarn = ChkLowRam.IsChecked == true;
            _s.LowRamThreshold = (int)SldLowRam.Value;
            _s.ProcAlert = ChkProcAlert.IsChecked == true;
            _s.ProcAlertMB = (int)SldProcAlert.Value;

            _s.GameMode = ChkGameMode.IsChecked == true;
            _s.AutoDetectGames = ChkGameDetect.IsChecked == true;
            var p = CurrentProfile;
            p.CleanOnStart = ChkGameClean.IsChecked == true;
            p.PowerPlan = ChkGamePower.IsChecked == true;
            p.HeavyAction = RbHeavyClose.IsChecked == true ? 2 : RbHeavyPause.IsChecked == true ? 1 : 0;
            p.TrimSeconds = (int)SldTrim.Value;

            _s.WidgetEnabled = ChkWidget.IsChecked == true;
            _s.WidgetOnlyInGame = ChkWidgetGame.IsChecked == true;
            _s.WidgetShowExtra = ChkWidgetExtra.IsChecked == true;

            _s.TrayShowPercent = ChkTrayPct.IsChecked == true;
            _s.Save();

            _lastIconKey = int.MinValue; // força redesenho do ícone
        }


        void UpdateLabels()
        {
            ChkAuto.Content = Loc.T("T_AutoWhen", (int)SldThreshold.Value);
            ChkInterval.Content = Loc.T("T_AutoEvery", (int)SldInterval.Value);
            ChkLowRam.Content = Loc.T("T_LowRam", (int)SldLowRam.Value);
            ChkProcAlert.Content = Loc.T("T_ProcAlertLbl", Fmt((ulong)SldProcAlert.Value * 1024 * 1024));
            SldThreshold.Opacity = ChkAuto.IsChecked == true ? 1 : 0.4;
            SldInterval.Opacity = ChkInterval.IsChecked == true ? 1 : 0.4;
            SldLowRam.Opacity = ChkLowRam.IsChecked == true ? 1 : 0.4;
            SldProcAlert.Opacity = ChkProcAlert.IsChecked == true ? 1 : 0.4;

            LblTrim.Text = Loc.T("T_Trim", (int)SldTrim.Value);

            TxtHotkey.Opacity = ChkHotkey.IsChecked == true ? 1 : 0.4;
        }


        // =====================================================================
        //  Atalho global
        // =====================================================================

        void ApplyHotkey()
        {
            _hotkey.Unregister();
            if (!_s.HotkeyEnabled) return;
            if (!_hotkey.Register(_s.Hotkey))
                ShowBalloon(Loc.T("T_HotkeyFail"), null);
        }

        void HotkeyToggled()
        {
            UpdateLabels();
            if (_loading) return;
            _s.HotkeyEnabled = ChkHotkey.IsChecked == true;
            _s.Save();
            ApplyHotkey();
        }

        void HotkeyBox_KeyDown(object sender, KeyEventArgs e)
        {
            e.Handled = true;
            if (e.Key == Key.Escape) { Keyboard.ClearFocus(); return; }
            string? combo = HotkeyManager.FromKeyEvent(e);
            if (combo == null || !HotkeyManager.TryParse(combo, out _, out _)) return;
            _s.Hotkey = combo;
            _s.Save();
            TxtHotkey.Text = combo;
            Keyboard.ClearFocus(); // LostKeyboardFocus registra o novo atalho
        }

        // =====================================================================
        //  Aparência
        // =====================================================================










        // =====================================================================
        //  Modo jogo
        // =====================================================================

        GameProfile CurrentProfile => _selectedGame ?? _s.AutoProfile;

        void BuildGameList()
        {
            GameList.Children.Clear();
            GameList.Children.Add(GameRow(null));
            foreach (var g in _s.Games) GameList.Children.Add(GameRow(g));
        }

        UIElement GameRow(GameProfile? g)
        {
            bool selected = _selectedGame == g;
            var row = new Border
            {
                CornerRadius = new CornerRadius(6),
                Padding = new Thickness(8, 2, 2, 2),
                Margin = new Thickness(0, 0, 0, 2),
                Cursor = Cursors.Hand,
                MinHeight = 26
            };
            row.SetResourceReference(Border.BackgroundProperty, selected ? "TrackBrush" : "CardBrush");

            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition());
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var name = new TextBlock
            {
                Text = g == null ? Loc.T("T_GameAutoRow") : g.Exe + ".exe",
                FontSize = 12,
                VerticalAlignment = VerticalAlignment.Center,
                TextTrimming = TextTrimming.CharacterEllipsis,
                FontStyle = g == null ? FontStyles.Italic : FontStyles.Normal
            };
            name.SetResourceReference(TextBlock.ForegroundProperty, g == null ? "MutedBrush" : "TextBrush");
            grid.Children.Add(name);

            if (g != null)
            {
                var chk = new CheckBox { Style = (Style)FindResource("Toggle"), IsChecked = g.Enabled, Margin = new Thickness(6, 0, 2, 0) };
                chk.Checked += (_, _) => { g.Enabled = true; _s.Save(); };
                chk.Unchecked += (_, _) => { g.Enabled = false; _s.Save(); };
                Grid.SetColumn(chk, 1);
                grid.Children.Add(chk);

                var del = new Button
                {
                    Style = (Style)FindResource("TitleButton"),
                    Content = "",
                    Width = 24, Height = 22,
                    ToolTip = Loc.T("T_GameRemove")
                };
                del.Click += (_, _) =>
                {
                    _s.Games.Remove(g);
                    if (_selectedGame == g) _selectedGame = null;
                    _s.Save();
                    BuildGameList();
                    LoadGameConfig();
                };
                Grid.SetColumn(del, 2);
                grid.Children.Add(del);
            }

            row.Child = grid;
            row.MouseLeftButtonUp += (_, _) =>
            {
                _selectedGame = g;
                BuildGameList();
                LoadGameConfig();
            };
            return row;
        }

        void LoadGameConfig()
        {
            bool wasLoading = _loading;
            _loading = true;
            var p = CurrentProfile;
            LblGameConfig.Text = Loc.T("T_GameConfig", _selectedGame == null ? Loc.T("T_GameAutoRow") : _selectedGame.Exe + ".exe");
            ChkGameClean.IsChecked = p.CleanOnStart;
            ChkGamePower.IsChecked = p.PowerPlan;
            RbHeavyNone.IsChecked = p.HeavyAction == 0;
            RbHeavyPause.IsChecked = p.HeavyAction == 1;
            RbHeavyClose.IsChecked = p.HeavyAction == 2;
            SldTrim.Value = p.TrimSeconds;
            _loading = wasLoading;
            UpdateLabels();
        }

        void AddGame_Click(object sender, RoutedEventArgs e)
        {
            string exe = GameBooster.Normalize(TxtGame.Text);
            if (exe.Length == 0) return;

            var existing = _s.Games.FirstOrDefault(g => g.Exe.Equals(exe, StringComparison.OrdinalIgnoreCase));
            if (existing == null)
            {
                existing = new GameProfile { Exe = exe };
                _s.Games.Add(existing);
            }
            _selectedGame = existing;
            _s.Save();
            TxtGame.Text = "";
            BuildGameList();
            LoadGameConfig();
            if (ChkGameMode.IsChecked != true) ChkGameMode.IsChecked = true;
        }

        void CommitHeavy()
        {
            if (_loading) return;
            _s.HeavyApps = TxtHeavy.Text.Trim();
            _s.Save();
        }

        void PickGame_Click(object sender, RoutedEventArgs e)
        {
            LstGames.Items.Clear();
            foreach (var (exe, title) in GameBooster.WindowedApps())
            {
                var tb = new TextBlock { TextTrimming = TextTrimming.CharacterEllipsis, FontSize = 12 };
                tb.Inlines.Add(new Run(exe + ".exe") { FontWeight = FontWeights.SemiBold });
                var t = new Run("  " + title);
                t.SetResourceReference(TextElement.ForegroundProperty, "MutedBrush");
                tb.Inlines.Add(t);
                LstGames.Items.Add(new ListBoxItem { Content = tb, Tag = exe, ToolTip = title, Style = (Style)FindResource("ListItem") });
            }
            if (LstGames.Items.Count == 0)
                LstGames.Items.Add(new ListBoxItem { Content = Loc.T("T_NoWindows"), IsEnabled = false, Style = (Style)FindResource("ListItem") });
            GamePopup.IsOpen = true;
        }

        void LstGames_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (LstGames.SelectedItem is not ListBoxItem { Tag: string exe }) return;
            GamePopup.IsOpen = false;
            TxtGame.Text = exe;
            AddGame_Click(this, new RoutedEventArgs());
        }

        void UpdateGameUi()
        {
            TxtGameStatus.Text = _booster.Status;
            GameDot.SetResourceReference(Shape.FillProperty, _booster.Active ? "AccentBrush" : "MutedBrush");
            GameBadge.Visibility = _booster.Active ? Visibility.Visible : Visibility.Collapsed;
            TxtGameBadge.Text = _booster.Active ? Loc.T("T_GamePrioritized", _booster.GameName) : "";
        }

        // =====================================================================
        //  Processos
        // =====================================================================

        void BuildProcList(List<(int Pid, string Name, long Bytes)> procs)
        {
            ProcList.Children.Clear();
            long max = procs.Count > 0 ? Math.Max(1, procs[0].Bytes) : 1;

            foreach (var (pid, name, bytes) in procs)
            {
                var grid = new Grid { Margin = new Thickness(0, 0, 4, 7) };
                grid.ColumnDefinitions.Add(new ColumnDefinition());
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

                var left = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
                var tb = new TextBlock { Text = name, FontSize = 12, TextTrimming = TextTrimming.CharacterEllipsis };
                tb.SetResourceReference(TextBlock.ForegroundProperty, "TextBrush");
                var bar = new Border
                {
                    Height = 3,
                    CornerRadius = new CornerRadius(1.5),
                    HorizontalAlignment = HorizontalAlignment.Left,
                    Width = Math.Max(4, 140.0 * bytes / max),
                    Margin = new Thickness(0, 3, 0, 0)
                };
                bar.SetResourceReference(Border.BackgroundProperty, "AccentBrush");
                left.Children.Add(tb);
                left.Children.Add(bar);
                grid.Children.Add(left);

                var mb = new TextBlock { Text = Fmt((ulong)bytes), FontSize = 11.5, Margin = new Thickness(8, 0, 8, 0), VerticalAlignment = VerticalAlignment.Center };
                mb.SetResourceReference(TextBlock.ForegroundProperty, "MutedBrush");
                Grid.SetColumn(mb, 1);
                grid.Children.Add(mb);

                var btn = new Button
                {
                    Style = (Style)FindResource("SecondaryButton"),
                    Height = 22,
                    FontSize = 11,
                    Content = Loc.T("T_ProcCleanBtn")
                };
                btn.Click += async (_, _) =>
                {
                    btn.IsEnabled = false;
                    long freed = await Task.Run(() => MemoryCleaner.CleanProcess(pid));
                    TxtProcStatus.Text = Loc.T("T_ProcFreed", name, Fmt((ulong)freed));
                    AddHistory(freed, "process", name);
                    _lastProcList = DateTime.MinValue;
                };
                Grid.SetColumn(btn, 2);
                grid.Children.Add(btn);

                ProcList.Children.Add(grid);
            }
        }

        void CheckProcAlert(List<(int Pid, string Name, long Bytes)> procs)
        {
            long limit = (long)_s.ProcAlertMB * 1024 * 1024;
            foreach (var (pid, name, bytes) in procs)
            {
                if (bytes < limit) break; // lista está ordenada
                if (_booster.Active && name.Equals(_booster.GameName, StringComparison.OrdinalIgnoreCase)) continue;
                if (_procWarned.TryGetValue(name, out var t) && (DateTime.Now - t).TotalMinutes < 15) continue;

                _procWarned[name] = DateTime.Now;
                ShowBalloon(Loc.T("T_ProcAlertMsg", name, Fmt((ulong)bytes)), async () =>
                {
                    long freed = await Task.Run(() => MemoryCleaner.CleanProcess(pid));
                    AddHistory(freed, "process", name);
                });
                break;
            }
        }

        // =====================================================================
        //  Histórico
        // =====================================================================

        void AddHistory(long freed, string kind, string detail = "")
        {
            _s.History.Insert(0, new HistoryEntry { Time = DateTime.Now, Freed = Math.Max(0, freed), Kind = kind, Detail = detail });
            if (_s.History.Count > 200) _s.History.RemoveRange(200, _s.History.Count - 200);
            _s.Save();
            if (PanelHist.Visibility == Visibility.Visible) BuildHistory();
        }

        void BuildHistory()
        {
            HistList.Children.Clear();
            var today = _s.History.Where(h => h.Time.Date == DateTime.Today).ToList();
            TxtHistSummary.Text = _s.History.Count == 0
                ? Loc.T("T_HistEmpty")
                : Loc.T("T_HistSummary", today.Count, Fmt((ulong)today.Sum(h => h.Freed)), Fmt((ulong)_s.History.Sum(h => h.Freed)));

            foreach (var h in _s.History.Take(100))
            {
                var grid = new Grid { Margin = new Thickness(0, 0, 4, 7) };
                grid.ColumnDefinitions.Add(new ColumnDefinition());
                grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

                var left = new StackPanel();
                var kind = new TextBlock { Text = KindText(h), FontSize = 12, TextTrimming = TextTrimming.CharacterEllipsis };
                kind.SetResourceReference(TextBlock.ForegroundProperty, "TextBrush");
                var time = new TextBlock { Text = h.Time.ToString("dd/MM HH:mm"), FontSize = 10.5 };
                time.SetResourceReference(TextBlock.ForegroundProperty, "MutedBrush");
                left.Children.Add(kind);
                left.Children.Add(time);
                grid.Children.Add(left);

                var freed = new TextBlock { Text = Fmt((ulong)h.Freed), FontSize = 12, FontWeight = FontWeights.SemiBold, VerticalAlignment = VerticalAlignment.Center };
                freed.SetResourceReference(TextBlock.ForegroundProperty, "AccentSolidBrush");
                Grid.SetColumn(freed, 1);
                grid.Children.Add(freed);

                HistList.Children.Add(grid);
            }
        }

        static string KindText(HistoryEntry h) => h.Kind switch
        {
            "auto" => Loc.T("T_KAuto"),
            "game" => Loc.T("T_KGame") + (h.Detail.Length > 0 ? $" · {h.Detail}" : ""),
            "hotkey" => Loc.T("T_KHotkey"),
            "process" => Loc.T("T_KProcess") + (h.Detail.Length > 0 ? $" · {h.Detail}" : ""),
            _ => Loc.T("T_KManual")
        };

        void ClearHistory_Click(object sender, RoutedEventArgs e)
        {
            _s.History.Clear();
            _s.Save();
            BuildHistory();
        }

        // =====================================================================
        //  Widget
        // =====================================================================

        void Corner_Checked(object sender, RoutedEventArgs e)
        {
            if (_loading) return;
            _s.WidgetCorner = sender == RbCornerTL ? 0 : sender == RbCornerBL ? 2 : sender == RbCornerBR ? 3 : 1;
            _s.Save();
            _overlay.SetCorner(_s.WidgetCorner);
        }

        bool OverlayShouldShow() => _s.WidgetEnabled && (!_s.WidgetOnlyInGame || _booster.Active);

        void UpdateOverlay(uint load, bool extra)
        {
            if (!OverlayShouldShow())
            {
                if (_overlay.IsVisible) _overlay.Hide();
                return;
            }

            string? ex = null;
            if (extra)
            {
                string gpu = _stats.Gpu is double g ? $"{g:0}%" : Loc.T("T_NA");
                string temp = _stats.TempC is double t ? $"  ·  {t:0} °C" : "";
                ex = $"CPU {_stats.Cpu:0}%  ·  GPU {gpu}{temp}";
            }
            _overlay.Update((int)load, ex, _booster.Active ? _booster.GameName + ".exe" : null);

            if (!_overlay.IsVisible)
            {
                _overlay.Show();
                _overlay.SetCorner(_s.WidgetCorner);
            }
        }

        // =====================================================================
        //  Navegação
        // =====================================================================


        void Tab_Checked(object sender, RoutedEventArgs e)
        {
            if (PanelClean == null) return; // XAML ainda carregando
            PanelClean.Visibility = sender == TabClean ? Visibility.Visible : Visibility.Collapsed;
            PanelAuto.Visibility = sender == TabAuto ? Visibility.Visible : Visibility.Collapsed;
            PanelGame.Visibility = sender == TabGame ? Visibility.Visible : Visibility.Collapsed;
            PanelProc.Visibility = sender == TabProc ? Visibility.Visible : Visibility.Collapsed;
            PanelHist.Visibility = sender == TabHist ? Visibility.Visible : Visibility.Collapsed;
            PanelWidget.Visibility = sender == TabWidget ? Visibility.Visible : Visibility.Collapsed;

            bool wasOpen = _settingsOpen;
            _settingsOpen = sender != TabClean;
            if (wasOpen && !_settingsOpen) _shownPct = -1;
            if (sender == TabProc) _lastProcList = DateTime.MinValue;
            if (sender == TabHist) BuildHistory();
        }


        // =====================================================================
        //  Monitoramento
        // =====================================================================

        void Tick()
        {
            var (total, avail, load) = MemoryCleaner.GetStatus();
            ulong used = total - avail;
            _targetPct = load;

            _samples.Enqueue(load);
            while (_samples.Count > MaxSamples) _samples.Dequeue();

            TxtUsed.Text = Fmt(used);
            TxtFree.Text = Fmt(avail);
            TxtTotal.Text = Fmt(total);
            var (cUsed, cLimit) = MemoryCleaner.GetCommit();
            TxtCommit.Text = cLimit > 0 ? Loc.T("T_Virtual", Fmt(cUsed), Fmt(cLimit)) : "";

            if (IsVisible && !_settingsOpen) DrawGraph();
            UpdateTray((int)load, used, total);
            RunBackground(load);

            if (_cleaning) return;
            var now = DateTime.Now;
            var since = now - _lastClean;
            bool autoWillClean = _s.AutoClean && load >= _s.AutoThreshold;

            if (autoWillClean && since.TotalSeconds >= 60)
                _ = CleanAsync("auto");
            else if (_s.IntervalClean && since.TotalMinutes >= _s.IntervalMinutes)
                _ = CleanAsync("auto");
            else if (_s.LowRamWarn && !autoWillClean && load >= _s.LowRamThreshold && (now - _lastLowWarn).TotalMinutes >= 10)
            {
                _lastLowWarn = now;
                ShowBalloon(Loc.T("T_LowRamMsg", load), () => _ = CleanAsync("manual"));
            }
        }

        /// <summary>Trabalho pesado (modo jogo, CPU/GPU, lista de processos) fora da thread da interface.</summary>
        async void RunBackground(uint load)
        {
            if (_bgBusy) return;
            _bgBusy = true;

            var now = DateTime.Now;
            bool extra = OverlayShouldShow() && _s.WidgetShowExtra;
            bool needList = IsVisible && _settingsOpen && TabProc.IsChecked == true && (now - _lastProcList).TotalSeconds >= 3;
            bool needAlert = _s.ProcAlert && (now - _lastProcAlert).TotalSeconds >= 10;
            List<(int Pid, string Name, long Bytes)>? procs = null;

            try
            {
                await Task.Run(() =>
                {
                    _booster.Update();
                    _stats.Update(extra);
                    if (needList || needAlert) procs = MemoryCleaner.TopProcesses(15);
                });
            }
            catch { }
            _bgBusy = false;

            UpdateGameUi();
            UpdateOverlay(load, extra);
            if (procs != null)
            {
                if (needList) { _lastProcList = now; BuildProcList(procs); }
                if (needAlert) { _lastProcAlert = now; CheckProcAlert(procs); }
            }
        }

        void DrawGraph()
        {
            double w = GraphHost.ActualWidth, h = GraphHost.ActualHeight;
            if (w <= 0 || h <= 0 || _samples.Count < 2) return;

            double step = w / (MaxSamples - 1);
            double x0 = w - (_samples.Count - 1) * step;
            double Y(double v) => h - 2 - (h - 4) * v / 100.0;

            var line = new StreamGeometry();
            using (var c = line.Open())
            {
                int i = 0;
                foreach (var v in _samples)
                {
                    var pt = new Point(x0 + i * step, Y(v));
                    if (i == 0) c.BeginFigure(pt, false, false);
                    else c.LineTo(pt, true, true);
                    i++;
                }
            }

            var fill = new StreamGeometry();
            using (var c = fill.Open())
            {
                c.BeginFigure(new Point(x0, h), true, true);
                int i = 0;
                foreach (var v in _samples)
                {
                    c.LineTo(new Point(x0 + i * step, Y(v)), false, true);
                    i++;
                }
                c.LineTo(new Point(w, h), false, false);
            }

            line.Freeze();
            fill.Freeze();
            GraphLine.Data = line;
            GraphFill.Data = fill;
        }

        void Animate(object? sender, EventArgs e)
        {
            if (!IsVisible || _settingsOpen) return;
            if (_shownPct < 0) _shownPct = _targetPct;
            else if (Math.Abs(_targetPct - _shownPct) < 0.05) return;
            else _shownPct += (_targetPct - _shownPct) * 0.12;

            DrawArc(_shownPct);
            TxtPct.Text = $"{Math.Round(_shownPct)}%";
            UpdateGaugeColors();
        }

        void UpdateGaugeColors()
        {
            bool danger = _shownPct >= 85;
            if (_danger == danger) return;
            _danger = danger;
            GaugeArc.SetResourceReference(Shape.StrokeProperty, danger ? "DangerBrush" : "AccentBrush");
            GaugeGlow.Color = danger ? Color.FromRgb(0xEF, 0x44, 0x44) : (Color)FindResource("AccentColorA");
        }

        void DrawArc(double pct)
        {
            const double c = 80, r = 72;
            double a = Math.Clamp(pct, 0.5, 99.99) * 3.6 * Math.PI / 180.0;
            var end = new Point(c + r * Math.Sin(a), c - r * Math.Cos(a));

            var fig = new PathFigure { StartPoint = new Point(c, c - r), IsClosed = false };
            fig.Segments.Add(new ArcSegment(end, new Size(r, r), 0, pct > 50, SweepDirection.Clockwise, true));
            GaugeArc.Data = new PathGeometry(new[] { fig });
        }

        // =====================================================================
        //  Limpeza
        // =====================================================================

        async void Clean_Click(object sender, RoutedEventArgs e) => await CleanAsync("manual");

        async Task CleanAsync(string kind)
        {
            if (_cleaning) return;
            _cleaning = true;
            BtnClean.IsEnabled = false;
            BtnClean.SetResourceReference(ContentProperty, "T_Cleaning");

            try
            {
                long freed = await Task.Run(() => MemoryCleaner.Clean(_s));
                string msg = Loc.T("T_Freed", Fmt((ulong)Math.Max(0, freed)), DateTime.Now.ToString("HH:mm"));
                TxtResult.Text = kind == "auto" ? msg + Loc.T("T_AutoSuffix") : msg;
                AddHistory(freed, kind);
                if (!Host.WindowVisible && kind != "auto")
                    ShowBalloon(msg, null);
            }
            catch (Exception ex)
            {
                TxtResult.Text = Loc.T("T_Error", ex.Message);
            }
            finally
            {
                _lastClean = DateTime.Now;
                _cleaning = false;
                BtnClean.IsEnabled = true;
                BtnClean.SetResourceReference(ContentProperty, "T_Clean");
            }
        }

        static string Fmt(ulong bytes)
        {
            double gb = bytes / 1024d / 1024d / 1024d;
            return gb >= 1 ? $"{gb:0.0} GB" : $"{bytes / 1024d / 1024d:0} MB";
        }

        // =====================================================================
        //  Bandeja
        // =====================================================================








        // =====================================================================
        //  Janela
        // =====================================================================



    }
}

using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace THSuite.Memory
{
    public class GameProfile
    {
        public string Exe { get; set; } = "";
        public bool Enabled { get; set; } = true;
        public bool CleanOnStart { get; set; } = true;
        public bool PowerPlan { get; set; } = false;
        public int HeavyAction { get; set; } = 0;   // 0 = nada, 1 = pausar, 2 = fechar
        public int TrimSeconds { get; set; } = 30;
    }

    public class HistoryEntry
    {
        public DateTime Time { get; set; }
        public long Freed { get; set; }
        public string Kind { get; set; } = "manual";   // manual | auto | game | hotkey | process
        public string Detail { get; set; } = "";
    }

    public class Settings
    {
        // Limpeza
        public bool WorkingSet { get; set; } = true;
        public bool SystemCache { get; set; } = true;
        public bool ModifiedList { get; set; } = true;
        public bool StandbyList { get; set; } = true;
        public bool StandbyLowPriority { get; set; } = false;

        // Automático e avisos
        public bool AutoClean { get; set; } = false;
        public int AutoThreshold { get; set; } = 90;
        public bool IntervalClean { get; set; } = false;
        public int IntervalMinutes { get; set; } = 30;
        public bool LowRamWarn { get; set; } = true;
        public int LowRamThreshold { get; set; } = 90;
        public bool ProcAlert { get; set; } = false;
        public int ProcAlertMB { get; set; } = 4096;

        // Modo jogo
        public bool GameMode { get; set; } = false;
        public bool AutoDetectGames { get; set; } = true;
        public List<GameProfile> Games { get; set; } = new();
        public GameProfile AutoProfile { get; set; } = new();
        public string HeavyApps { get; set; } = "chrome, msedge, firefox, opera, discord";

        // Widget
        public bool WidgetEnabled { get; set; } = false;
        public bool WidgetOnlyInGame { get; set; } = false;
        public bool WidgetShowExtra { get; set; } = true;
        public int WidgetCorner { get; set; } = 1;   // 0 ↖  1 ↗  2 ↙  3 ↘

        // Aparência
        public string Theme { get; set; } = "dark";
        public string AccentA { get; set; } = "#22D3EE";
        public string AccentB { get; set; } = "#8B5CF6";
        public int Scale { get; set; } = 100;
        public int WindowOpacity { get; set; } = 100;
        public bool Topmost { get; set; } = false;
        public bool LogoUseAccent { get; set; } = false;
        public string LogoPrimary { get; set; } = "#E10600";
        public string LogoSecondary { get; set; } = "#E6E6E6";

        // Sistema
        public string Language { get; set; } = "pt";
        public bool HotkeyEnabled { get; set; } = true;
        public string Hotkey { get; set; } = "Ctrl+Shift+L";
        public bool StartWithWindows { get; set; } = false;
        public bool StartMinimized { get; set; } = true;
        public bool TrayShowPercent { get; set; } = true;
        public bool TrayHintShown { get; set; } = false;

        // Histórico
        public List<HistoryEntry> History { get; set; } = new();

        // Legado (v1.0) — migrado para Games
        public string? GameExe { get; set; }
        public bool? GameCleanOnStart { get; set; }
        public int? GameTrimSeconds { get; set; }

        static string FilePath => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "THSuite", "memory.json");

        public static Settings Load()
        {
            Settings s;
            try
            {
                s = File.Exists(FilePath)
                    ? JsonSerializer.Deserialize<Settings>(File.ReadAllText(FilePath)) ?? new Settings()
                    : new Settings();
            }
            catch { s = new Settings(); }

            if (!string.IsNullOrWhiteSpace(s.GameExe) && s.Games.Count == 0)
            {
                s.Games.Add(new GameProfile
                {
                    Exe = s.GameExe!,
                    CleanOnStart = s.GameCleanOnStart ?? true,
                    TrimSeconds = s.GameTrimSeconds ?? 30
                });
            }
            s.GameExe = null; s.GameCleanOnStart = null; s.GameTrimSeconds = null;
            s.AutoProfile ??= new GameProfile();
            s.Games ??= new List<GameProfile>();
            s.History ??= new List<HistoryEntry>();
            return s;
        }

        public void Save()
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(FilePath)!);
                File.WriteAllText(FilePath, JsonSerializer.Serialize(this, new JsonSerializerOptions
                {
                    WriteIndented = true,
                    DefaultIgnoreCondition = System.Text.Json.Serialization.JsonIgnoreCondition.WhenWritingNull
                }));
            }
            catch { }
        }
    }
}

using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;

namespace THSuite.Memory
{
    /// <summary>Atalho de teclado global (funciona mesmo com o app minimizado ou dentro de jogos).</summary>
    public sealed class HotkeyManager : IDisposable
    {
        const int Id = 0x5448;
        const int WM_HOTKEY = 0x0312;
        const uint MOD_ALT = 1, MOD_CONTROL = 2, MOD_SHIFT = 4, MOD_WIN = 8, MOD_NOREPEAT = 0x4000;

        IntPtr _hwnd;
        HwndSource? _source;
        bool _registered;

        public event Action? Pressed;

        public void Attach(Window w)
        {
            _hwnd = new WindowInteropHelper(w).EnsureHandle();
            _source = HwndSource.FromHwnd(_hwnd);
            _source.AddHook(Hook);
        }

        public bool Register(string combo)
        {
            Unregister();
            if (!TryParse(combo, out uint mods, out uint vk)) return false;
            _registered = Native.RegisterHotKey(_hwnd, Id, mods | MOD_NOREPEAT, vk);
            return _registered;
        }

        public void Unregister()
        {
            if (!_registered) return;
            Native.UnregisterHotKey(_hwnd, Id);
            _registered = false;
        }

        IntPtr Hook(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            if (msg == WM_HOTKEY && wParam.ToInt32() == Id)
            {
                Pressed?.Invoke();
                handled = true;
            }
            return IntPtr.Zero;
        }

        public static bool TryParse(string combo, out uint mods, out uint vk)
        {
            mods = 0; vk = 0;
            foreach (var raw in combo.Split('+'))
            {
                string part = raw.Trim();
                switch (part.ToLowerInvariant())
                {
                    case "ctrl": mods |= MOD_CONTROL; break;
                    case "alt": mods |= MOD_ALT; break;
                    case "shift": mods |= MOD_SHIFT; break;
                    case "win": mods |= MOD_WIN; break;
                    default:
                        if (Enum.TryParse<Key>(part, true, out var key))
                            vk = (uint)KeyInterop.VirtualKeyFromKey(key);
                        break;
                }
            }
            return vk != 0 && mods != 0;
        }

        /// <summary>Converte a tecla pressionada em texto ("Ctrl+Shift+L"). Retorna null se ainda incompleto.</summary>
        public static string? FromKeyEvent(KeyEventArgs e)
        {
            Key key = e.Key == Key.System ? e.SystemKey : e.Key;
            if (key is Key.LeftCtrl or Key.RightCtrl or Key.LeftAlt or Key.RightAlt
                    or Key.LeftShift or Key.RightShift or Key.LWin or Key.RWin or Key.None)
                return null;

            var m = Keyboard.Modifiers;
            if (m == ModifierKeys.None) return null;

            var parts = new List<string>();
            if (m.HasFlag(ModifierKeys.Control)) parts.Add("Ctrl");
            if (m.HasFlag(ModifierKeys.Alt)) parts.Add("Alt");
            if (m.HasFlag(ModifierKeys.Shift)) parts.Add("Shift");
            if (m.HasFlag(ModifierKeys.Windows)) parts.Add("Win");
            parts.Add(key.ToString());
            return string.Join("+", parts);
        }

        public void Dispose()
        {
            Unregister();
            _source?.RemoveHook(Hook);
        }
    }
}

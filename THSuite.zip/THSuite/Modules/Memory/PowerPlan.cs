using System.Diagnostics;
using System.Text.RegularExpressions;

namespace THSuite.Memory
{
    /// <summary>Troca para o plano "Alto desempenho" e restaura o anterior.</summary>
    internal static class PowerPlan
    {
        static string? _saved;

        public static void SetHighPerformance()
        {
            try
            {
                _saved ??= ActiveGuid();
                Run("/setactive SCHEME_MIN"); // SCHEME_MIN = Alto desempenho
            }
            catch { }
        }

        public static void Restore()
        {
            if (_saved == null) return;
            try { Run("/setactive " + _saved); } catch { }
            _saved = null;
        }

        static string? ActiveGuid()
        {
            var m = Regex.Match(Run("/getactivescheme"),
                @"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}");
            return m.Success ? m.Value : null;
        }

        static string Run(string args)
        {
            var psi = new ProcessStartInfo("powercfg.exe", args)
            {
                CreateNoWindow = true,
                UseShellExecute = false,
                RedirectStandardOutput = true
            };
            using var p = Process.Start(psi)!;
            string output = p.StandardOutput.ReadToEnd();
            p.WaitForExit(3000);
            return output;
        }
    }
}

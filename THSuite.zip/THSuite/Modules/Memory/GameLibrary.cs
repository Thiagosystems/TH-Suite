using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.RegularExpressions;
using Microsoft.Win32;

namespace THSuite.Memory
{
    /// <summary>Descobre as pastas de jogos da Steam, Epic Games e Riot Games.</summary>
    internal static class GameLibrary
    {
        static List<string>? _roots;
        static DateTime _scannedAt;

        static readonly string[] Ignore =
        {
            "crash", "launcher", "anticheat", "battleye", "setup", "redist", "unins", "helper",
            "updater", "report", "bootstrap", "webhelper", "riotclient", "leagueclient", "vanguard",
            "overlay", "steamservice", "epicgames", "wallpaper", "steamvr", "vrserver", "vrmonitor", "soundpad"
        };

        public static IReadOnlyList<string> Roots()
        {
            if (_roots == null || (DateTime.Now - _scannedAt).TotalMinutes > 5)
            {
                _roots = Scan();
                _scannedAt = DateTime.Now;
            }
            return _roots;
        }

        public static bool IsGame(string path, string name)
        {
            if (Ignore.Any(x => name.Contains(x, StringComparison.OrdinalIgnoreCase))) return false;
            return Roots().Any(r => path.StartsWith(r, StringComparison.OrdinalIgnoreCase));
        }

        static List<string> Scan()
        {
            var list = new List<string>();

            // Steam: pasta principal + bibliotecas extras (libraryfolders.vdf)
            try
            {
                using var key = Registry.CurrentUser.OpenSubKey(@"Software\Valve\Steam");
                if (key?.GetValue("SteamPath") is string steam)
                {
                    steam = steam.Replace('/', '\\');
                    Add(list, Path.Combine(steam, "steamapps", "common"));
                    string vdf = Path.Combine(steam, "steamapps", "libraryfolders.vdf");
                    if (File.Exists(vdf))
                    {
                        foreach (Match m in Regex.Matches(File.ReadAllText(vdf), "\"path\"\\s+\"([^\"]+)\""))
                            Add(list, Path.Combine(m.Groups[1].Value.Replace(@"\\", @"\"), "steamapps", "common"));
                    }
                }
            }
            catch { }

            // Epic Games: manifestos .item têm o InstallLocation
            try
            {
                string manifests = Path.Combine(
                    Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
                    @"Epic\EpicGamesLauncher\Data\Manifests");
                if (Directory.Exists(manifests))
                {
                    foreach (var f in Directory.GetFiles(manifests, "*.item"))
                    {
                        try
                        {
                            using var doc = JsonDocument.Parse(File.ReadAllText(f));
                            if (doc.RootElement.TryGetProperty("InstallLocation", out var loc))
                                Add(list, loc.GetString());
                        }
                        catch { }
                    }
                }
            }
            catch { }

            // Riot Games: pasta padrão em cada disco
            try
            {
                foreach (var d in DriveInfo.GetDrives().Where(d => d.DriveType == DriveType.Fixed && d.IsReady))
                    Add(list, Path.Combine(d.RootDirectory.FullName, "Riot Games"));
            }
            catch { }

            return list;
        }

        static void Add(List<string> list, string? dir)
        {
            if (string.IsNullOrWhiteSpace(dir) || !Directory.Exists(dir)) return;
            string full = Path.GetFullPath(dir).TrimEnd('\\') + "\\";
            if (!list.Contains(full, StringComparer.OrdinalIgnoreCase)) list.Add(full);
        }
    }
}

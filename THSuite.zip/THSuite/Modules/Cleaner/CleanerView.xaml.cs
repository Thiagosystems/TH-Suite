using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using Microsoft.Win32;
using WF = System.Windows.Forms;

namespace THSuite.Cleaner
{
    public partial class CleanerView : UserControl
    {
        static readonly int[] LargeSizesMB = { 50, 100, 250, 500, 1000, 2000, 5000, 10000 };

        readonly AppSettings _s;
        readonly List<CleanCategory> _categories;
        readonly ObservableCollection<ProgramInfo> _programs = new();
        readonly ObservableCollection<BigFile> _large = new();
        readonly ObservableCollection<StoreApp> _store = new();
        readonly ObservableCollection<Leftover> _leftovers = new();
        readonly ICollectionView _programView;
        readonly ICollectionView _storeView;

        CancellationTokenSource? _cleanCts, _largeCts;
        TaskCompletionSource<bool>? _leftoverChoice;
        string _largeType = "Todos";
        bool _started;
        bool _loading = true, _storeLoaded, _cleanBusy;

        public CleanerView()
        {
            InitializeComponent();
            _s = AppSettings.Load();


            // ---- Limpeza
            _categories = DiskCleaner.BuildCategories();
            foreach (var c in _categories)
            {
                c.IsChecked = _s.CategoryState.TryGetValue(c.Id, out bool on) ? on : c.DefaultOn;
                c.PropertyChanged += Category_PropertyChanged;
            }
            ListWindows.ItemsSource = _categories.Where(c => c.Group == "Windows").ToList();
            ListBrowsers.ItemsSource = _categories.Where(c => c.Group == "Navegadores").ToList();
            ListApps.ItemsSource = _categories.Where(c => c.Group == "Aplicativos").ToList();
            CardBrowsers.Visibility = _categories.Any(c => c.Group == "Navegadores") ? Visibility.Visible : Visibility.Collapsed;
            CardApps.Visibility = _categories.Any(c => c.Group == "Aplicativos") ? Visibility.Visible : Visibility.Collapsed;
            UpdateCleanTotals();
            UpdateDiskInfo();

            // ---- Arquivos grandes
            LstLarge.ItemsSource = _large;
            foreach (var type in LargeFiles.Types.Keys)
            {
                var rb = new RadioButton { Style = (Style)FindResource("Pill"), GroupName = "ltype", Content = type, IsChecked = type == "Todos", Margin = new Thickness(0, 0, 6, 6) };
                rb.Checked += (_, _) => _largeType = type;
                LargeTypes.Children.Add(rb);
            }
            TxtLargeFolder.Text = Directory.Exists(_s.LargeFolder) ? _s.LargeFolder : Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            int idx = Array.IndexOf(LargeSizesMB, _s.LargeMinMB);
            SldLargeMin.Value = idx >= 0 ? idx : 3;
            SldLargeMin.ValueChanged += (_, _) => { UpdateLargeLabel(); if (!_loading) { _s.LargeMinMB = LargeSizesMB[(int)SldLargeMin.Value]; _s.Save(); } };
            ChkLargeRecycle.IsChecked = _s.LargeToRecycle;
            ChkLargeRecycle.Checked += (_, _) => { _s.LargeToRecycle = true; _s.Save(); };
            ChkLargeRecycle.Unchecked += (_, _) => { _s.LargeToRecycle = false; _s.Save(); };
            UpdateLargeLabel();

            // ---- Programas / Store / sobras
            _programView = CollectionViewSource.GetDefaultView(_programs);
            _programView.Filter = o => o is ProgramInfo p && Matches(TxtProgSearch.Text, p.Name, p.Publisher);
            _programView.SortDescriptions.Add(new SortDescription(nameof(ProgramInfo.Name), ListSortDirection.Ascending));
            LstPrograms.ItemsSource = _programView;

            _storeView = CollectionViewSource.GetDefaultView(_store);
            _storeView.Filter = o => o is StoreApp a && Matches(TxtStoreSearch.Text, a.DisplayName, a.Name);
            LstStore.ItemsSource = _storeView;

            LstLeftovers.ItemsSource = _leftovers;

            // ---- Configurações
            LoadSettingsUi();
            HookSettings();

            Loaded += async (_, _) => { if (_started) return; _started = true; await LoadProgramsAsync(); };
            _loading = false;
        }

        static bool Matches(string query, params string[] fields)
        {
            query = query.Trim();
            return query.Length == 0 || fields.Any(f => f.Contains(query, StringComparison.CurrentCultureIgnoreCase));
        }

        /// <summary>Chamado quando o TH Suite fecha.</summary>
        public void Shutdown()
        {
            _cleanCts?.Cancel();
            _largeCts?.Cancel();
            _s.Save();
        }

        /// <summary>Abre uma aba: clean, large, programs, store, backups, options.</summary>
        public void ShowTab(string tab)
        {
            var rb = tab switch { "large" => NavLarge, "programs" => NavPrograms, "store" => NavStore, "backups" => NavBackups, "options" => NavSettings, _ => NavClean };
            rb.IsChecked = true;
        }

        /// <summary>Limpeza rápida (tela inicial): limpa os itens marcados, sem perguntar, pulando apps abertos.</summary>
        public async Task<long> QuickCleanAsync(Action<string>? log = null)
        {
            if (_cleanBusy) return 0;
            var cats = _categories.Where(c => c.IsChecked && !c.HasWarning).ToList();
            long total = 0;
            var token = CancellationToken.None;
            foreach (var c in cats)
            {
                if (c.Processes.Length > 0 && await Task.Run(() => DiskCleaner.IsRunning(c)))
                {
                    log?.Invoke($"  • {c.Name}: ignorado (programa aberto)");
                    continue;
                }
                var (freed, _, _) = await Task.Run(() => DiskCleaner.Clean(c, _s, token));
                total += freed;
                if (freed > 0) log?.Invoke($"  • {c.Name}: {Fmt.Size(freed)}");
            }
            UpdateDiskInfo();
            Activity.Log("Limpeza", $"Limpeza rápida: {Fmt.Size(total)} liberados");
            return total;
        }

        /// <summary>Atalho da tela inicial: abre a limpeza e já analisa.</summary>
        public void QuickAnalyze()
        {
            NavClean.IsChecked = true;
            if (BtnAnalyze.IsEnabled) Analyze_Click(BtnAnalyze, new RoutedEventArgs());
        }

        void Status(string text) => TxtStatus.Text = text;

        void ShowBusy(string title, string sub = "")
        {
            TxtBusy.Text = title;
            TxtBusySub.Text = sub;
            BusyOverlay.Visibility = Visibility.Visible;
        }

        void HideBusy() => BusyOverlay.Visibility = Visibility.Collapsed;

        bool Confirm(string text, string title = "TH Suite") =>
            MessageBox.Show(Host.Owner, text, title, MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes;

        void Info(string text) => MessageBox.Show(Host.Owner, text, "TH Suite", MessageBoxButton.OK, MessageBoxImage.Information);

        // =====================================================================
        //  Navegação e janela
        // =====================================================================

        void Nav_Checked(object sender, RoutedEventArgs e)
        {
            if (PageClean == null) return; // XAML ainda carregando
            PageClean.Visibility = sender == NavClean ? Visibility.Visible : Visibility.Collapsed;
            PageLarge.Visibility = sender == NavLarge ? Visibility.Visible : Visibility.Collapsed;
            PagePrograms.Visibility = sender == NavPrograms ? Visibility.Visible : Visibility.Collapsed;
            PageStore.Visibility = sender == NavStore ? Visibility.Visible : Visibility.Collapsed;
            PageBackups.Visibility = sender == NavBackups ? Visibility.Visible : Visibility.Collapsed;
            PageSettings.Visibility = sender == NavSettings ? Visibility.Visible : Visibility.Collapsed;

            if (sender == NavStore && !_storeLoaded) _ = LoadStoreAsync();
            if (sender == NavBackups) LoadBackups();
            if (sender == NavClean) UpdateDiskInfo();
        }



        // =====================================================================
        //  Limpeza de disco
        // =====================================================================

        void Category_PropertyChanged(object? sender, PropertyChangedEventArgs e)
        {
            if (sender is not CleanCategory c) return;
            if (e.PropertyName == nameof(CleanCategory.IsChecked))
            {
                _s.CategoryState[c.Id] = c.IsChecked;
                if (!_loading) _s.Save();
                UpdateCleanTotals();
            }
            else if (e.PropertyName == nameof(CleanCategory.Size))
                UpdateCleanTotals();
        }

        void UpdateCleanTotals()
        {
            void Group(string g, CheckBox chk, TextBlock txt)
            {
                var items = _categories.Where(c => c.Group == g).ToList();
                if (items.Count == 0) return;
                chk.IsChecked = items.All(c => c.IsChecked) ? true : items.Any(c => c.IsChecked) ? null : false;
                long size = items.Where(c => c.IsChecked && c.Size > 0).Sum(c => c.Size);
                txt.Text = items.Any(c => c.Size >= 0) ? Fmt.Size(size) : $"{items.Count(c => c.IsChecked)} de {items.Count}";
            }
            Group("Windows", ChkGroupWindows, TxtGroupWindows);
            Group("Navegadores", ChkGroupBrowsers, TxtGroupBrowsers);
            Group("Aplicativos", ChkGroupApps, TxtGroupApps);

            if (!_cleanBusy && _categories.Any(c => c.Size >= 0))
            {
                long total = _categories.Where(c => c.IsChecked && c.Size > 0).Sum(c => c.Size);
                TxtCleanTotal.Text = $"{Fmt.Size(total)} podem ser liberados";
            }
        }

        void GroupCheck_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not CheckBox chk || chk.Tag is not string group) return;
            var items = _categories.Where(c => c.Group == group).ToList();
            bool target = !items.All(c => c.IsChecked);
            foreach (var c in items) c.IsChecked = target;
            UpdateCleanTotals();
        }

        void UpdateDiskInfo()
        {
            try
            {
                string sysRoot = Path.GetPathRoot(Environment.GetFolderPath(Environment.SpecialFolder.Windows)) ?? "C:\\";
                var d = new DriveInfo(sysRoot);
                long used = d.TotalSize - d.TotalFreeSpace;
                TxtDiskName.Text = $"Disco {sysRoot.TrimEnd('\\')}";
                TxtDiskFree.Text = $"{Fmt.Size(d.TotalFreeSpace)} livres de {Fmt.Size(d.TotalSize)}";
                PrgDisk.Value = used * 100.0 / d.TotalSize;
            }
            catch { }
        }

        void SetCleanBusy(bool busy)
        {
            _cleanBusy = busy;
            BtnAnalyze.IsEnabled = !busy;
            BtnClean.IsEnabled = !busy;
            BtnCleanStop.Visibility = busy ? Visibility.Visible : Visibility.Collapsed;
            PrgClean.Visibility = busy ? Visibility.Visible : Visibility.Hidden;
            NavLarge.IsEnabled = NavPrograms.IsEnabled = NavStore.IsEnabled = !busy;
        }

        async void Analyze_Click(object sender, RoutedEventArgs e) => await AnalyzeAsync();

        async Task AnalyzeAsync()
        {
            var cats = _categories.Where(c => c.IsChecked).ToList();
            if (cats.Count == 0) { Status("Marque pelo menos um item para analisar."); return; }

            _cleanCts = new CancellationTokenSource();
            var token = _cleanCts.Token;
            SetCleanBusy(true);
            TxtCleanTotal.Text = "Analisando...";
            foreach (var c in _categories) { c.Status = ""; if (!c.IsChecked) c.Size = -1; }

            for (int i = 0; i < cats.Count && !token.IsCancellationRequested; i++)
            {
                var c = cats[i];
                TxtCleanStatus.Text = $"Analisando: {c.Name}";
                PrgClean.Value = i * 100.0 / cats.Count;
                var (size, files) = await Task.Run(() => DiskCleaner.Measure(c, _s, token));
                c.Files = files;
                c.Size = size;
                if (c.Processes.Length > 0 && DiskCleaner.IsRunning(c))
                    c.Status = _s.CloseBrowsers ? "Está aberto — será fechado na limpeza" : "Está aberto — feche para limpar (ou ative \"fechar\" nas configurações)";
            }

            SetCleanBusy(false);
            long total = cats.Where(c => c.Size > 0).Sum(c => c.Size);
            int count = cats.Sum(c => c.Files);
            TxtCleanTotal.Text = $"{Fmt.Size(total)} podem ser liberados";
            TxtCleanStatus.Text = token.IsCancellationRequested ? "Análise interrompida" : $"{count:N0} arquivos encontrados em {cats.Count} itens";
            Status("Análise concluída.");
        }

        async void Clean_Click(object sender, RoutedEventArgs e)
        {
            var cats = _categories.Where(c => c.IsChecked).ToList();
            if (cats.Count == 0) { Status("Marque pelo menos um item para limpar."); return; }

            var warnings = cats.Where(c => c.HasWarning).Select(c => $"• {c.Name}: {c.Warning}").ToList();
            if (_s.ConfirmClean)
            {
                string msg = $"Limpar {cats.Count} itens selecionados?";
                if (warnings.Count > 0) msg += "\n\nAtenção:\n" + string.Join("\n", warnings);
                if (!Confirm(msg)) return;
            }

            _cleanCts = new CancellationTokenSource();
            var token = _cleanCts.Token;
            SetCleanBusy(true);
            long total = 0; int deleted = 0, failed = 0, skipped = 0;

            for (int i = 0; i < cats.Count && !token.IsCancellationRequested; i++)
            {
                var c = cats[i];
                TxtCleanStatus.Text = $"Limpando: {c.Name}";
                TxtCleanTotal.Text = $"{Fmt.Size(total)} liberados";
                PrgClean.Value = i * 100.0 / cats.Count;

                if (c.Processes.Length > 0 && DiskCleaner.IsRunning(c))
                {
                    if (_s.CloseBrowsers) await Task.Run(() => DiskCleaner.CloseProcesses(c));
                    else { c.Status = "Ignorado: o programa está aberto"; skipped++; continue; }
                }

                var (freed, del, fail) = await Task.Run(() => DiskCleaner.Clean(c, _s, token));
                total += freed; deleted += del; failed += fail;
                c.Status = fail > 0 ? $"{Fmt.Size(freed)} liberados · {fail} arquivos em uso foram mantidos" : $"{Fmt.Size(freed)} liberados";
                c.Size = await Task.Run(() => DiskCleaner.Measure(c, _s, token).Size);
            }

            SetCleanBusy(false);
            TxtCleanTotal.Text = $"{Fmt.Size(total)} liberados";
            TxtCleanStatus.Text = $"{deleted:N0} arquivos apagados"
                                  + (failed > 0 ? $" · {failed:N0} em uso (normal)" : "")
                                  + (skipped > 0 ? $" · {skipped} ignorados por estarem abertos" : "");
            UpdateDiskInfo();
            Status($"Limpeza concluída: {Fmt.Size(total)} liberados.");
            Activity.Log("Limpeza", $"Limpeza de disco: {Fmt.Size(total)} liberados ({deleted:N0} arquivos)");
        }

        void CleanStop_Click(object sender, RoutedEventArgs e) => _cleanCts?.Cancel();

        void OpenCleanmgr_Click(object sender, RoutedEventArgs e) => Shell.OpenUrl("cleanmgr.exe");
        void OpenStorage_Click(object sender, RoutedEventArgs e) => Shell.OpenUrl("ms-settings:storagesense");

        // =====================================================================
        //  Arquivos grandes
        // =====================================================================

        void UpdateLargeLabel()
        {
            int mb = LargeSizesMB[(int)SldLargeMin.Value];
            LblLargeMin.Text = "Tamanho mínimo: " + (mb >= 1000 ? $"{mb / 1000} GB" : $"{mb} MB");
        }

        void PickLargeFolder_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFolderDialog { Title = "Escolha onde procurar", InitialDirectory = TxtLargeFolder.Text };
            if (dlg.ShowDialog(Host.Owner) == true) TxtLargeFolder.Text = dlg.FolderName;
        }

        async void LargeScan_Click(object sender, RoutedEventArgs e)
        {
            if (_largeCts != null) { _largeCts.Cancel(); return; }

            string folder = TxtLargeFolder.Text.Trim();
            if (!Directory.Exists(folder)) { Info("Pasta não encontrada."); return; }
            _s.LargeFolder = folder;
            _s.Save();

            long min = LargeSizesMB[(int)SldLargeMin.Value] * 1024L * 1024L;
            string type = _largeType;
            _largeCts = new CancellationTokenSource();
            var token = _largeCts.Token;
            BtnLargeScan.Content = "Parar";
            PrgLarge.Visibility = Visibility.Visible;
            _large.Clear();
            UpdateLargeSelection();

            var progress = new Progress<string>(t => TxtLargeStatus.Text = t);
            List<BigFile> result;
            try { result = await Task.Run(() => LargeFiles.Scan(folder, min, type, progress, token)); }
            catch (Exception ex) { result = new(); TxtLargeStatus.Text = "Erro: " + ex.Message; }

            foreach (var f in result)
            {
                f.PropertyChanged += (_, _) => UpdateLargeSelection();
                _large.Add(f);
            }
            TxtLargeStatus.Text = (token.IsCancellationRequested ? "Busca interrompida · " : "")
                                  + $"{result.Count} arquivos encontrados · {Fmt.Size(result.Sum(f => f.Size))} no total";
            PrgLarge.Visibility = Visibility.Collapsed;
            BtnLargeScan.Content = "Procurar";
            _largeCts = null;
        }

        void UpdateLargeSelection()
        {
            var sel = _large.Where(f => f.IsChecked).ToList();
            TxtLargeSelected.Text = sel.Count == 0 ? "" : $"{sel.Count} selecionados · {Fmt.Size(sel.Sum(f => f.Size))}";
        }

        void LargeSelectAll_Click(object sender, RoutedEventArgs e) { foreach (var f in _large) f.IsChecked = true; }
        void LargeSelectNone_Click(object sender, RoutedEventArgs e) { foreach (var f in _large) f.IsChecked = false; }

        void LargeOpen_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as FrameworkElement)?.DataContext is BigFile f) Shell.OpenFolder(f.Path);
        }

        async void LargeDelete_Click(object sender, RoutedEventArgs e)
        {
            var sel = _large.Where(f => f.IsChecked).ToList();
            if (sel.Count == 0) { Status("Nenhum arquivo selecionado."); return; }
            string how = _s.LargeToRecycle ? "enviados para a Lixeira" : "apagados PERMANENTEMENTE";
            if (!Confirm($"{sel.Count} arquivos ({Fmt.Size(sel.Sum(f => f.Size))}) serão {how}. Continuar?")) return;

            ShowBusy("Excluindo arquivos...");
            bool recycle = _s.LargeToRecycle;
            int ok = 0, fail = 0;
            foreach (var f in sel)
            {
                bool done = await Task.Run(() =>
                {
                    try
                    {
                        if (recycle) Native.SendToRecycleBin(f.Path);
                        else { File.SetAttributes(f.Path, FileAttributes.Normal); File.Delete(f.Path); }
                    }
                    catch { }
                    return !File.Exists(f.Path);
                });
                if (done) { ok++; _large.Remove(f); } else fail++;
            }
            HideBusy();
            UpdateLargeSelection();
            UpdateDiskInfo();
            Status($"{ok} arquivos excluídos" + (fail > 0 ? $" · {fail} não puderam ser excluídos (em uso ou protegidos)" : ""));
        }

        // =====================================================================
        //  Programas
        // =====================================================================

        async Task LoadProgramsAsync()
        {
            Status("Carregando programas instalados...");
            bool showSystem = _s.ShowSystem;
            var list = await Task.Run(() => Uninstaller.LoadPrograms(showSystem));

            _programs.Clear();
            foreach (var p in list)
            {
                p.PropertyChanged += Program_PropertyChanged;
                _programs.Add(p);
            }
            UpdateProgramCount();
            Status($"{list.Count} programas encontrados.");

            // Ícones em segundo plano
            _ = Task.Run(() =>
            {
                foreach (var p in list)
                {
                    var icon = Uninstaller.LoadIcon(p.IconPath);
                    if (icon != null) Dispatcher.InvokeAsync(() => p.Icon = icon);
                }
            });
        }

        void Program_PropertyChanged(object? sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(ProgramInfo.IsChecked)) UpdateProgramSelection();
        }

        void UpdateProgramCount()
        {
            long total = _programs.Where(p => p.SizeBytes > 0).Sum(p => p.SizeBytes);
            TxtProgCount.Text = $"{_programs.Count} programas · {Fmt.Size(total)} (tamanho informado pelos instaladores)";
            UpdateProgramSelection();
        }

        void UpdateProgramSelection()
        {
            int n = _programs.Count(p => p.IsChecked);
            TxtProgSelected.Text = n == 0 ? "Marque vários para desinstalar em sequência" : $"{n} selecionados";
            BtnBatchUninstall.IsEnabled = n > 0;
            BtnBatchUninstall.Content = n > 0 ? $"Desinstalar selecionados ({n})" : "Desinstalar selecionados";
        }

        void ProgSearch_Changed(object sender, TextChangedEventArgs e)
        {
            PhProgSearch.Visibility = TxtProgSearch.Text.Length == 0 ? Visibility.Visible : Visibility.Collapsed;
            _programView?.Refresh();
        }

        void ProgSort_Checked(object sender, RoutedEventArgs e)
        {
            if (_programView == null) return;
            _programView.SortDescriptions.Clear();
            if (sender == SortSize) _programView.SortDescriptions.Add(new SortDescription(nameof(ProgramInfo.SizeBytes), ListSortDirection.Descending));
            else if (sender == SortDate) _programView.SortDescriptions.Add(new SortDescription(nameof(ProgramInfo.InstallDate), ListSortDirection.Descending));
            else if (sender == SortPub) _programView.SortDescriptions.Add(new SortDescription(nameof(ProgramInfo.Publisher), ListSortDirection.Ascending));
            _programView.SortDescriptions.Add(new SortDescription(nameof(ProgramInfo.Name), ListSortDirection.Ascending));
        }

        async void ProgRefresh_Click(object sender, RoutedEventArgs e) => await LoadProgramsAsync();

        void ProgSelectNone_Click(object sender, RoutedEventArgs e) { foreach (var p in _programs) p.IsChecked = false; }

        ProgramInfo? Selected => LstPrograms.SelectedItem as ProgramInfo;

        void LstPrograms_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var p = Selected;
            ProgDetails.DataContext = p;
            ProgDetails.Visibility = p != null ? Visibility.Visible : Visibility.Collapsed;
            TxtNoSelection.Visibility = p == null ? Visibility.Visible : Visibility.Collapsed;
        }

        async void LstPrograms_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (Selected is ProgramInfo p) await UninstallAsync(p, false, false);
        }

        async void Uninstall_Click(object sender, RoutedEventArgs e)
        {
            if (Selected is ProgramInfo p) await UninstallAsync(p, false, false);
        }

        async void ForceUninstall_Click(object sender, RoutedEventArgs e)
        {
            if (Selected is ProgramInfo p) await UninstallAsync(p, true, false);
        }

        async void BatchUninstall_Click(object sender, RoutedEventArgs e)
        {
            var sel = _programs.Where(p => p.IsChecked).ToList();
            if (sel.Count == 0) return;
            if (!Confirm($"Desinstalar {sel.Count} programas, um de cada vez?\n\n" + string.Join("\n", sel.Select(p => "• " + p.Name))))
                return;

            if (_s.RestorePoint)
            {
                ShowBusy("Criando ponto de restauração...", "Isso pode levar alguns segundos.");
                bool ok = await Uninstaller.CreateRestorePointAsync($"{sel.Count} programas");
                HideBusy();
                if (!ok) Status("Não foi possível criar o ponto de restauração (Proteção do Sistema desativada ou já criado hoje).");
            }

            int i = 0;
            foreach (var p in sel)
            {
                i++;
                Status($"Desinstalando {i} de {sel.Count}: {p.Name}");
                bool cont = await UninstallAsync(p, false, true);
                if (!cont) break;
            }
            UpdateProgramSelection();
        }

        /// <summary>Desinstala e procura sobras. Retorna false se o usuário quiser parar (no modo em lote).</summary>
        async Task<bool> UninstallAsync(ProgramInfo p, bool forced, bool batch)
        {
            if (!batch)
            {
                string q = forced
                    ? $"Remoção forçada de \"{p.Name}\"?\n\nO desinstalador NÃO será executado. O TH Suite vai procurar pastas, atalhos e registros do programa para você escolher o que apagar."
                    : $"Desinstalar \"{p.Name}\"?";
                if (!Confirm(q)) return false;

                if (_s.RestorePoint)
                {
                    ShowBusy("Criando ponto de restauração...", "Isso pode levar alguns segundos.");
                    bool ok = await Uninstaller.CreateRestorePointAsync(p.Name);
                    if (!ok) Status("Não foi possível criar o ponto de restauração (Proteção do Sistema desativada ou já criado hoje).");
                }
            }

            if (!forced)
            {
                if (p.UninstallString.Length == 0)
                {
                    HideBusy();
                    if (!Confirm($"\"{p.Name}\" não tem desinstalador. Fazer remoção forçada?")) return true;
                    forced = true;
                }
                else
                {
                    ShowBusy($"Desinstalando {p.Name}...", "Siga as instruções do desinstalador do programa. O TH Suite aguarda ele terminar.");
                    try { await Uninstaller.RunUninstallerAsync(p, _s.QuietUninstall); }
                    catch (Exception ex)
                    {
                        HideBusy();
                        if (!Confirm($"Não foi possível abrir o desinstalador:\n{ex.Message}\n\nFazer remoção forçada?")) return true;
                        forced = true;
                    }

                    if (!forced && Uninstaller.StillInstalled(p))
                    {
                        HideBusy();
                        var r = MessageBox.Show(Host.Owner,
                            $"\"{p.Name}\" ainda parece instalado (a desinstalação pode ter sido cancelada).\n\nProcurar sobras mesmo assim?",
                            "TH Suite", MessageBoxButton.YesNoCancel, MessageBoxImage.Warning);
                        if (r == MessageBoxResult.Cancel) return false;
                        if (r == MessageBoxResult.No) return true;
                    }
                }
            }

            ShowBusy($"Procurando sobras de {p.Name}...", "Pastas, atalhos e chaves do registro.");
            var others = _programs.ToList();
            var found = await Task.Run(() => Uninstaller.ScanLeftovers(p, true, others));
            HideBusy();

            if (found.Count == 0)
            {
                Status($"{p.Name}: nenhuma sobra encontrada.");
            }
            else
            {
                bool remove = await AskLeftoversAsync(p, found);
                if (remove)
                {
                    var chosen = found.Where(l => l.IsChecked).ToList();
                    if (chosen.Count > 0)
                    {
                        ShowBusy("Removendo sobras...");
                        var (ok, failed, backup) = await Uninstaller.RemoveLeftoversAsync(p.Name, chosen, _s.BackupRegistry, _s.LeftoversToRecycle);
                        HideBusy();
                        Status($"{p.Name}: {ok} sobras removidas" + (failed > 0 ? $" · {failed} não puderam ser removidas" : "")
                               + (backup != null ? " · backup do registro salvo" : ""));
                    }
                }
            }

            if (!Uninstaller.StillInstalled(p))
            {
                Activity.Log("Desinstalador", $"Desinstalado: {p.Name}");
                p.PropertyChanged -= Program_PropertyChanged;
                _programs.Remove(p);
                UpdateProgramCount();
            }
            UpdateDiskInfo();
            return true;
        }

        Task<bool> AskLeftoversAsync(ProgramInfo p, List<Leftover> items)
        {
            _leftovers.Clear();
            foreach (var l in items.OrderBy(l => l.Kind).ThenBy(l => l.Path)) _leftovers.Add(l);
            long size = items.Where(l => l.Size > 0).Sum(l => l.Size);
            TxtLeftTitle.Text = $"{items.Count} sobras de \"{p.Name}\"" + (size > 0 ? $" · {Fmt.Size(size)}" : "");
            LeftoverOverlay.Visibility = Visibility.Visible;
            _leftoverChoice = new TaskCompletionSource<bool>();
            return _leftoverChoice.Task;
        }

        void CloseLeftovers(bool remove)
        {
            LeftoverOverlay.Visibility = Visibility.Collapsed;
            _leftoverChoice?.TrySetResult(remove);
        }

        void LeftAll_Click(object sender, RoutedEventArgs e) { foreach (var l in _leftovers) l.IsChecked = true; }
        void LeftNone_Click(object sender, RoutedEventArgs e) { foreach (var l in _leftovers) l.IsChecked = false; }
        void LeftSkip_Click(object sender, RoutedEventArgs e) => CloseLeftovers(false);

        void LeftRemove_Click(object sender, RoutedEventArgs e)
        {
            int n = _leftovers.Count(l => l.IsChecked);
            if (n == 0) { CloseLeftovers(false); return; }
            if (!Confirm($"Remover {n} itens selecionados?")) return;
            CloseLeftovers(true);
        }

        void ProgOpenFolder_Click(object sender, RoutedEventArgs e)
        {
            if (Selected is ProgramInfo p && p.HasInstallFolder) Shell.OpenFolder(p.InstallLocation);
            else Status("Esse programa não informou a pasta de instalação.");
        }

        void ProgOpenReg_Click(object sender, RoutedEventArgs e)
        {
            if (Selected is ProgramInfo p) Uninstaller.OpenInRegedit(p.RegPath);
        }

        void ProgSearchWeb_Click(object sender, RoutedEventArgs e)
        {
            if (Selected is ProgramInfo p)
                Shell.OpenUrl("https://www.google.com/search?q=" + Uri.EscapeDataString($"{p.Name} {p.Publisher}"));
        }

        void ProgExport_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new SaveFileDialog
            {
                Title = "Exportar lista de programas",
                FileName = $"programas_{DateTime.Now:yyyy-MM-dd}.csv",
                Filter = "Planilha CSV (*.csv)|*.csv|Texto (*.txt)|*.txt"
            };
            if (dlg.ShowDialog(Host.Owner) != true) return;

            var sb = new StringBuilder();
            bool csv = dlg.FileName.EndsWith(".csv", StringComparison.OrdinalIgnoreCase);
            sb.AppendLine(csv ? "Nome;Fabricante;Versão;Instalado em;Tamanho;Pasta" : "Programas instalados — " + DateTime.Now.ToString("dd/MM/yyyy HH:mm"));
            foreach (var p in _programs.OrderBy(p => p.Name))
            {
                sb.AppendLine(csv
                    ? string.Join(";", new[] { p.Name, p.Publisher, p.Version, p.DateText, p.SizeText, p.InstallLocation }.Select(v => v.Replace(";", ",")))
                    : $"{p.Name}  |  {p.Publisher}  |  {p.Version}  |  {p.DateText}  |  {p.SizeText}");
            }
            File.WriteAllText(dlg.FileName, sb.ToString(), new UTF8Encoding(true));
            Status("Lista exportada: " + dlg.FileName);
        }

        // =====================================================================
        //  Apps da Store
        // =====================================================================

        async Task LoadStoreAsync()
        {
            _storeLoaded = true;
            ShowBusy("Carregando apps da Store...", "Pode levar alguns segundos.");
            var list = await Uninstaller.LoadStoreAppsAsync();
            HideBusy();
            _store.Clear();
            foreach (var a in list) _store.Add(a);
            TxtStoreCount.Text = $"{list.Count} apps instalados · {list.Count(a => a.NonRemovable)} do sistema não podem ser removidos";
        }

        void StoreSearch_Changed(object sender, TextChangedEventArgs e)
        {
            PhStoreSearch.Visibility = TxtStoreSearch.Text.Length == 0 ? Visibility.Visible : Visibility.Collapsed;
            _storeView?.Refresh();
        }

        async void StoreRefresh_Click(object sender, RoutedEventArgs e) => await LoadStoreAsync();

        async void StoreRemoveOne_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as FrameworkElement)?.DataContext is not StoreApp app) return;
            if (!Confirm($"Remover \"{app.DisplayName}\"?")) return;
            await RemoveStoreAppsAsync(new List<StoreApp> { app });
        }

        async void StoreRemoveSelected_Click(object sender, RoutedEventArgs e)
        {
            var sel = _store.Where(a => a.IsChecked && a.CanRemove).ToList();
            if (sel.Count == 0) { Status("Nenhum app selecionado."); return; }
            if (!Confirm($"Remover {sel.Count} apps?\n\n" + string.Join("\n", sel.Select(a => "• " + a.DisplayName)))) return;
            await RemoveStoreAppsAsync(sel);
        }

        async Task RemoveStoreAppsAsync(List<StoreApp> apps)
        {
            int ok = 0, fail = 0, i = 0;
            foreach (var a in apps)
            {
                i++;
                ShowBusy($"Removendo {a.DisplayName}...", $"{i} de {apps.Count}");
                if (await Uninstaller.RemoveStoreAppAsync(a)) { ok++; _store.Remove(a); }
                else fail++;
            }
            HideBusy();
            Status($"{ok} apps removidos" + (fail > 0 ? $" · {fail} não puderam ser removidos" : ""));
            if (ok > 0) Activity.Log("Desinstalador", $"{ok} app(s) da Store removido(s)");
        }

        // =====================================================================
        //  Backups
        // =====================================================================

        void LoadBackups()
        {
            var list = Uninstaller.ListBackups();
            LstBackups.ItemsSource = list;
            TxtNoBackups.Visibility = list.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
        }

        async void BackupRestore_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as FrameworkElement)?.DataContext is not BackupEntry b) return;
            if (!Confirm($"Restaurar as chaves do registro de \"{b.Title}\"?")) return;
            ShowBusy("Restaurando registro...");
            int ok = await Uninstaller.RestoreBackupAsync(b);
            HideBusy();
            Status($"{ok} de {b.Keys} chaves restauradas.");
        }

        void BackupOpen_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as FrameworkElement)?.DataContext is BackupEntry b) Shell.OpenFolder(b.Folder);
        }

        void BackupDelete_Click(object sender, RoutedEventArgs e)
        {
            if ((sender as FrameworkElement)?.DataContext is not BackupEntry b) return;
            if (!Confirm($"Excluir o backup de \"{b.Title}\"?")) return;
            try { Directory.Delete(b.Folder, true); } catch { }
            LoadBackups();
        }

        void BackupFolder_Click(object sender, RoutedEventArgs e)
        {
            Directory.CreateDirectory(AppSettings.BackupDir);
            Shell.OpenFolder(AppSettings.BackupDir);
        }

        // =====================================================================
        //  Configurações
        // =====================================================================

        void LoadSettingsUi()
        {
            bool was = _loading;
            _loading = true;

            SldTempAge.Value = _s.TempMinAgeHours;
            ChkCloseBrowsers.IsChecked = _s.CloseBrowsers;
            ChkConfirmClean.IsChecked = _s.ConfirmClean;
            TxtExclusions.Text = string.Join(Environment.NewLine, _s.Exclusions);

            ChkRestorePoint.IsChecked = _s.RestorePoint;
            ChkBackupReg.IsChecked = _s.BackupRegistry;
            ChkLeftRecycle.IsChecked = _s.LeftoversToRecycle;
            ChkQuiet.IsChecked = _s.QuietUninstall;
            ChkShowSystem.IsChecked = _s.ShowSystem;

            UpdateSettingsLabels();
            _loading = was;
        }

        void HookSettings()
        {
            foreach (var cb in new[] { ChkCloseBrowsers, ChkConfirmClean, ChkRestorePoint, ChkBackupReg, ChkLeftRecycle, ChkQuiet })
            {
                cb.Checked += SettingChanged;
                cb.Unchecked += SettingChanged;
            }
            SldTempAge.ValueChanged += (_, _) => SettingChanged(null, null);

            ChkShowSystem.Checked += ShowSystem_Changed;
            ChkShowSystem.Unchecked += ShowSystem_Changed;



            TxtExclusions.LostFocus += (_, _) => CommitExclusions();
        }

        void SettingChanged(object? sender, RoutedEventArgs? e)
        {
            UpdateSettingsLabels();
            if (_loading) return;
            _s.TempMinAgeHours = (int)SldTempAge.Value;
            _s.CloseBrowsers = ChkCloseBrowsers.IsChecked == true;
            _s.ConfirmClean = ChkConfirmClean.IsChecked == true;
            _s.RestorePoint = ChkRestorePoint.IsChecked == true;
            _s.BackupRegistry = ChkBackupReg.IsChecked == true;
            _s.LeftoversToRecycle = ChkLeftRecycle.IsChecked == true;
            _s.QuietUninstall = ChkQuiet.IsChecked == true;
            _s.Save();
        }

        async void ShowSystem_Changed(object sender, RoutedEventArgs e)
        {
            if (_loading) return;
            _s.ShowSystem = ChkShowSystem.IsChecked == true;
            _s.Save();
            await LoadProgramsAsync();
        }

        void UpdateSettingsLabels()
        {
            int h = (int)SldTempAge.Value;
            LblTempAge.Text = h == 0
                ? "Apagar todos os arquivos temporários"
                : $"Só apagar temporários com mais de {h} horas";
        }

        void CommitExclusions()
        {
            if (_loading) return;
            _s.Exclusions = TxtExclusions.Text
                .Split(new[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries)
                .Select(x => x.Trim().Trim('"'))
                .Where(x => x.Length > 2)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();
            _s.Save();
        }

        void AddExclusion_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFolderDialog { Title = "Pasta que nunca deve ser apagada" };
            if (dlg.ShowDialog(Host.Owner) != true) return;
            TxtExclusions.Text = (TxtExclusions.Text.TrimEnd() + Environment.NewLine + dlg.FolderName).Trim();
            CommitExclusions();
        }








        void ResetSettings_Click(object sender, RoutedEventArgs e)
        {
            if (!Confirm("Voltar todas as configurações ao padrão? (backups e exclusões são mantidos)")) return;
            var d = new AppSettings { Exclusions = _s.Exclusions };
            _s.TempMinAgeHours = d.TempMinAgeHours; _s.CloseBrowsers = d.CloseBrowsers; _s.ConfirmClean = d.ConfirmClean;
            _s.RestorePoint = d.RestorePoint; _s.BackupRegistry = d.BackupRegistry; _s.LeftoversToRecycle = d.LeftoversToRecycle;
            _s.QuietUninstall = d.QuietUninstall; _s.ShowSystem = d.ShowSystem;
            _s.CategoryState.Clear();
            _s.Save();
            LoadSettingsUi();
            _loading = true;
            foreach (var c in _categories) c.IsChecked = c.DefaultOn;
            _loading = false;
            Status("Configurações restauradas.");
        }

    }
}

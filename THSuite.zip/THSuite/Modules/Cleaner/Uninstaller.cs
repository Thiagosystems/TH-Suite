using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Xml.Linq;
using Microsoft.Win32;

namespace THSuite.Cleaner
{
    // =========================================================================
    //  Modelos
    // =========================================================================

    public class ProgramInfo : Observable
    {
        bool _isChecked;
        ImageSource? _icon;

        public string Name { get; init; } = "";
        public string Publisher { get; init; } = "";
        public string Version { get; init; } = "";
        public DateTime? InstallDate { get; init; }
        public long SizeBytes { get; init; } = -1;
        public string InstallLocation { get; init; } = "";
        public string UninstallString { get; init; } = "";
        public string QuietUninstallString { get; init; } = "";
        public string IconPath { get; init; } = "";
        public string RegPath { get; init; } = "";   // ex: HKLM\SOFTWARE\...\Uninstall\{GUID}
        public bool IsSystem { get; init; }

        public bool IsChecked { get => _isChecked; set => Set(ref _isChecked, value); }
        public ImageSource? Icon { get => _icon; set => Set(ref _icon, value); }

        public string SizeText => SizeBytes > 0 ? Fmt.Size(SizeBytes) : "";
        public string DateText => InstallDate?.ToString("dd/MM/yyyy") ?? "";
        public string SubText => string.Join("  ·  ", new[] { Publisher, Version }.Where(x => x.Length > 0));
        public bool IsMsi => UninstallString.Contains("msiexec", StringComparison.OrdinalIgnoreCase);
        public bool HasInstallFolder => InstallLocation.Length > 3 && Directory.Exists(InstallLocation);
    }

    public class Leftover : Observable
    {
        bool _isChecked;
        public string Kind { get; init; } = "";        // Pasta | Atalho | Registro
        public string Path { get; init; } = "";
        public string Reason { get; init; } = "";
        public long Size { get; init; } = -1;
        public bool IsChecked { get => _isChecked; set => Set(ref _isChecked, value); }
        public string Glyph => Kind switch { "Registro" => "", "Atalho" => "", _ => "" };
        public string SizeText => Size > 0 ? Fmt.Size(Size) : "";
    }

    public class StoreApp : Observable
    {
        bool _isChecked;
        public string Name { get; init; } = "";
        public string DisplayName { get; init; } = "";
        public string Publisher { get; init; } = "";
        public string Version { get; init; } = "";
        public string FullName { get; init; } = "";
        public string InstallLocation { get; init; } = "";
        public bool NonRemovable { get; init; }
        public bool CanRemove => !NonRemovable;
        public string SubText => $"{Publisher}  ·  {Version}";
        public bool IsChecked { get => _isChecked; set => Set(ref _isChecked, value); }
    }

    public class BackupEntry
    {
        public string Folder { get; init; } = "";
        public string Title { get; init; } = "";
        public DateTime Date { get; init; }
        public int Keys { get; init; }
        public string SubText => $"{Date:dd/MM/yyyy HH:mm}  ·  {Keys} chave(s) do registro";
    }

    // =========================================================================
    //  Desinstalador
    // =========================================================================

    public static class Uninstaller
    {
        const string UninstallKey = @"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall";

        static readonly HashSet<string> Generic = new(StringComparer.OrdinalIgnoreCase)
        {
            "microsoft", "microsoftcorporation", "windows", "google", "googlellc", "intel", "intelcorporation",
            "nvidia", "nvidiacorporation", "amd", "advancedmicrodevicesinc", "realtek", "common", "commonfiles",
            "programs", "program", "temp", "update", "updater", "packages", "package", "system", "drivers",
            "runtime", "redistributable", "software", "user", "users", "data", "cache", "app", "apps", "games",
            "game", "steamapps", "tools", "tool", "setup", "installer", "launcher", "client", "service",
            "services", "config", "settings", "logs", "local", "roaming", "locallow", "inc", "llc", "ltd",
            "corporation", "company", "classes", "policies", "wow6432node", "clients", "mozilla", "adobe", "apple"
        };

        // ---------------------------------------------------------------- lista

        public static List<ProgramInfo> LoadPrograms(bool showSystem)
        {
            var list = new List<ProgramInfo>();
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

            void Read(RegistryHive hive, RegistryView view, string prefix)
            {
                try
                {
                    using var baseKey = RegistryKey.OpenBaseKey(hive, view);
                    using var root = baseKey.OpenSubKey(UninstallKey);
                    if (root == null) return;
                    foreach (var sub in root.GetSubKeyNames())
                    {
                        try
                        {
                            using var k = root.OpenSubKey(sub);
                            if (k == null) continue;
                            string name = Str(k, "DisplayName");
                            string uninstall = Str(k, "UninstallString");
                            if (name.Length == 0) continue;

                            bool system = Int(k, "SystemComponent") == 1
                                          || Str(k, "ParentKeyName").Length > 0
                                          || Regex.IsMatch(Str(k, "ReleaseType"), "update|hotfix", RegexOptions.IgnoreCase)
                                          || uninstall.Length == 0;
                            if (system && !showSystem) continue;

                            string version = Str(k, "DisplayVersion");
                            if (!seen.Add(name + "|" + version)) continue;

                            long size = Int(k, "EstimatedSize");
                            list.Add(new ProgramInfo
                            {
                                Name = name.Trim(),
                                Publisher = Str(k, "Publisher").Trim(),
                                Version = version,
                                InstallDate = ParseDate(Str(k, "InstallDate")),
                                SizeBytes = size > 0 ? size * 1024 : -1,
                                InstallLocation = Environment.ExpandEnvironmentVariables(Str(k, "InstallLocation").Trim().Trim('"')),
                                UninstallString = uninstall,
                                QuietUninstallString = Str(k, "QuietUninstallString"),
                                IconPath = Str(k, "DisplayIcon"),
                                RegPath = prefix + "\\" + sub,
                                IsSystem = system
                            });
                        }
                        catch { }
                    }
                }
                catch { }
            }

            Read(RegistryHive.LocalMachine, RegistryView.Registry64, @"HKLM\" + UninstallKey);
            Read(RegistryHive.LocalMachine, RegistryView.Registry32, @"HKLM\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall");
            Read(RegistryHive.CurrentUser, RegistryView.Default, @"HKCU\" + UninstallKey);

            return list.OrderBy(p => p.Name, StringComparer.CurrentCultureIgnoreCase).ToList();
        }

        static string Str(RegistryKey k, string name) => k.GetValue(name)?.ToString() ?? "";

        static long Int(RegistryKey k, string name)
        {
            var v = k.GetValue(name);
            return v switch { int i => (uint)i, long l => l, string s when long.TryParse(s, out var n) => n, _ => 0 };
        }

        static DateTime? ParseDate(string s) =>
            DateTime.TryParseExact(s, "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var d) ? d : null;

        public static ImageSource? LoadIcon(string raw)
        {
            if (string.IsNullOrWhiteSpace(raw)) return null;
            string p = raw.Trim().Trim('"');
            int comma = p.LastIndexOf(',');
            if (comma > 2 && !File.Exists(p)) p = p[..comma].Trim().Trim('"');
            p = Environment.ExpandEnvironmentVariables(p);
            if (!File.Exists(p)) return null;
            try
            {
                using var ico = System.Drawing.Icon.ExtractAssociatedIcon(p);
                if (ico == null) return null;
                var src = Imaging.CreateBitmapSourceFromHIcon(ico.Handle, Int32Rect.Empty, BitmapSizeOptions.FromWidthAndHeight(32, 32));
                src.Freeze();
                return src;
            }
            catch { return null; }
        }

        // ---------------------------------------------------------- desinstalar

        public static async Task RunUninstallerAsync(ProgramInfo p, bool quiet)
        {
            string exe, args;
            string cmd = quiet && p.QuietUninstallString.Length > 0 ? p.QuietUninstallString : p.UninstallString;

            var guid = Regex.Match(cmd, @"\{[0-9A-Fa-f\-]{36}\}");
            if (p.IsMsi && guid.Success)
            {
                exe = "msiexec.exe";
                args = $"/x {guid.Value}" + (quiet ? " /qb" : "");
            }
            else
            {
                (exe, args) = SplitCommand(cmd);
            }

            using (var proc = Process.Start(new ProcessStartInfo(exe, args) { UseShellExecute = true }))
            {
                if (proc != null) await proc.WaitForExitAsync();
            }

            // Muitos desinstaladores se copiam para a pasta Temp e continuam rodando
            for (int i = 0; i < 600 && UninstallerRunning(); i++)
                await Task.Delay(500);
            await Task.Delay(800);
        }

        public static (string Exe, string Args) SplitCommand(string cmd)
        {
            cmd = Environment.ExpandEnvironmentVariables(cmd.Trim());
            if (cmd.StartsWith("\""))
            {
                int end = cmd.IndexOf('"', 1);
                if (end > 0) return (cmd[1..end], cmd[(end + 1)..].Trim());
            }
            int exeIdx = cmd.IndexOf(".exe", StringComparison.OrdinalIgnoreCase);
            if (exeIdx > 0) return (cmd[..(exeIdx + 4)], cmd[(exeIdx + 4)..].Trim());
            int space = cmd.IndexOf(' ');
            return space > 0 ? (cmd[..space], cmd[(space + 1)..]) : (cmd, "");
        }

        static bool UninstallerRunning()
        {
            foreach (var p in Process.GetProcesses())
            {
                string n = p.ProcessName.ToLowerInvariant();
                p.Dispose();
                if (n.StartsWith("un_a") || n.StartsWith("au_") || n.StartsWith("unins") || n.StartsWith("uninst")
                    || n == "uninstall" || n == "_iu14d2n" || n.StartsWith("setup_uninst"))
                    return true;
            }
            return false;
        }

        public static bool StillInstalled(ProgramInfo p) => KeyExists(p.RegPath);

        public static async Task<bool> CreateRestorePointAsync(string name)
        {
            string safe = name.Replace("'", "");
            var (code, _) = await Shell.PowerShellAsync(
                $"Checkpoint-Computer -Description 'TH Suite - {safe}' -RestorePointType 'APPLICATION_UNINSTALL' -ErrorAction Stop", 180000);
            return code == 0;
        }

        // --------------------------------------------------------------- sobras

        public static List<Leftover> ScanLeftovers(ProgramInfo p, bool includeUninstallKey, IEnumerable<ProgramInfo> others)
        {
            var result = new List<Leftover>();
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            var names = NameVariants(p);

            // Segurança: se outro programa instalado tem o mesmo nome (ex.: Python 3.11 e 3.12)
            // ou fica dentro da mesma pasta, nada é marcado automaticamente.
            var otherList = others.Where(o => !ReferenceEquals(o, p)).ToList();
            var otherNames = new HashSet<string>(otherList.Select(o => Norm(CleanName(o.Name))));
            bool sharedName = names.Any(otherNames.Contains);
            string myFolder = p.HasInstallFolder ? p.InstallLocation.TrimEnd('\\') + "\\" : "";
            bool sharedFolder = myFolder.Length > 0 && otherList.Any(o => o.HasInstallFolder &&
                (o.InstallLocation.TrimEnd('\\') + "\\").StartsWith(myFolder, StringComparison.OrdinalIgnoreCase));
            string pub = Norm(CleanName(p.Publisher));
            string pubFirst = Norm(p.Publisher.Split(' ', StringSplitOptions.RemoveEmptyEntries).FirstOrDefault() ?? "");

            void Add(string kind, string path, bool check, string reason, bool measure = false)
            {
                if (!seen.Add(path)) return;
                if (kind != "Registro" && !IsSafePath(path)) return;
                if (sharedName && check && path != p.RegPath) { check = false; reason += " (outro programa com nome igual ainda está instalado)"; }
                if (sharedFolder && check && kind == "Pasta" && myFolder.StartsWith(path.TrimEnd('\\') + "\\", StringComparison.OrdinalIgnoreCase))
                { check = false; reason += " (outro programa usa esta pasta)"; }
                result.Add(new Leftover { Kind = kind, Path = path, IsChecked = check, Reason = reason, Size = measure ? DirSize(path) : -1 });
            }

            int Match(string name)
            {
                string n = Norm(name);
                if (n.Length < 3 || Generic.Contains(n)) return 0;
                if (names.Contains(n)) return 2;
                if (n.Length >= 5 && names.Any(v => v.Length >= 5 && (n.StartsWith(v) || v.StartsWith(n)))) return 1;
                return 0;
            }

            bool IsPublisherFolder(string name)
            {
                string n = Norm(name);
                return n.Length >= 3 && !Generic.Contains(n) && (n == pub || n == pubFirst);
            }

            // 1) Pasta de instalação
            if (p.HasInstallFolder)
            {
                int m = Match(Path.GetFileName(p.InstallLocation.TrimEnd('\\')));
                Add("Pasta", p.InstallLocation.TrimEnd('\\'), m > 0, "Pasta de instalação", true);
            }

            // 2) Pastas com o nome do programa (ou dentro da pasta do fabricante)
            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            string profile = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile);
            var roots = new[]
            {
                Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),
                Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),
                Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),
                Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
                local,
                Path.Combine(local, "Programs"),
                Path.Combine(profile, @"AppData\LocalLow"),
            }.Where(Directory.Exists).Distinct(StringComparer.OrdinalIgnoreCase);

            foreach (var root in roots)
            {
                foreach (var dir in SafeDirs(root))
                {
                    string name = Path.GetFileName(dir);
                    int m = Match(name);
                    if (m > 0) { Add("Pasta", dir, m == 2, m == 2 ? "Nome igual ao do programa" : "Nome parecido", true); continue; }
                    if (IsPublisherFolder(name))
                    {
                        foreach (var sub in SafeDirs(dir))
                        {
                            int ms = Match(Path.GetFileName(sub));
                            if (ms > 0) Add("Pasta", sub, ms == 2, "Dentro da pasta do fabricante", true);
                        }
                    }
                }
            }

            // 3) Atalhos no Menu Iniciar e na Área de Trabalho
            var startRoots = new[]
            {
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonStartMenu), "Programs"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.StartMenu), "Programs"),
            };
            foreach (var sr in startRoots.Where(Directory.Exists))
            {
                foreach (var dir in SafeDirs(sr))
                {
                    int m = Match(Path.GetFileName(dir));
                    if (m > 0) Add("Atalho", dir, m == 2, "Pasta no Menu Iniciar");
                }
                foreach (var lnk in SafeFiles(sr, "*.lnk"))
                {
                    int m = Match(Path.GetFileNameWithoutExtension(lnk));
                    if (m > 0) Add("Atalho", lnk, m == 2, "Atalho no Menu Iniciar");
                }
            }
            foreach (var desk in new[] { Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),
                                         Environment.GetFolderPath(Environment.SpecialFolder.CommonDesktopDirectory) })
            {
                if (!Directory.Exists(desk)) continue;
                foreach (var lnk in SafeFiles(desk, "*.lnk"))
                {
                    int m = Match(Path.GetFileNameWithoutExtension(lnk));
                    if (m == 2) Add("Atalho", lnk, true, "Atalho na Área de Trabalho");
                }
            }

            // 4) Registro
            foreach (var regRoot in new[] { @"HKCU\Software", @"HKLM\SOFTWARE", @"HKLM\SOFTWARE\WOW6432Node" })
            {
                foreach (var sub in SubKeys(regRoot))
                {
                    int m = Match(sub);
                    if (m == 2) { Add("Registro", regRoot + "\\" + sub, true, "Chave com o nome do programa"); continue; }
                    if (IsPublisherFolder(sub))
                    {
                        foreach (var sub2 in SubKeys(regRoot + "\\" + sub))
                            if (Match(sub2) == 2) Add("Registro", regRoot + "\\" + sub + "\\" + sub2, true, "Chave dentro do fabricante");
                    }
                }
            }
            if (includeUninstallKey && KeyExists(p.RegPath))
                Add("Registro", p.RegPath, true, "Registro de desinstalação");

            return result;
        }

        static HashSet<string> NameVariants(ProgramInfo p)
        {
            var set = new HashSet<string>();
            void Add(string s)
            {
                string n = Norm(s);
                if (n.Length >= 3 && !Generic.Contains(n)) set.Add(n);
            }

            string clean = CleanName(p.Name);
            Add(clean);
            var words = clean.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            if (words.Length > 1 && p.Publisher.StartsWith(words[0], StringComparison.OrdinalIgnoreCase))
                Add(string.Join(" ", words.Skip(1)));
            if (p.HasInstallFolder)
                Add(Path.GetFileName(p.InstallLocation.TrimEnd('\\')));
            return set;
        }

        public static string CleanName(string name)
        {
            string s = Regex.Replace(name, @"\(.*?\)|\[.*?\]", " ");
            s = Regex.Replace(s, @"\b(v|version|versão)?\s*\d+(\.\d+)+[a-z0-9\-]*", " ", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\b(x64|x86|64-bit|32-bit|64 bits|32 bits|amd64|win64|win32|en-us|pt-br)\b", " ", RegexOptions.IgnoreCase);
            s = Regex.Replace(s, @"\s+", " ");
            return s.Trim(' ', '-', '–', '_', '.', ',');
        }

        public static string Norm(string s) => new string(s.ToLowerInvariant().Where(char.IsLetterOrDigit).ToArray());

        static IEnumerable<string> SafeDirs(string root)
        {
            try { return Directory.GetDirectories(root); } catch { return Array.Empty<string>(); }
        }

        static IEnumerable<string> SafeFiles(string root, string pattern)
        {
            try { return Directory.GetFiles(root, pattern); } catch { return Array.Empty<string>(); }
        }

        static long DirSize(string path)
        {
            try
            {
                if (File.Exists(path)) return new FileInfo(path).Length;
                var opt = new EnumerationOptions { RecurseSubdirectories = true, IgnoreInaccessible = true, AttributesToSkip = FileAttributes.ReparsePoint };
                long total = 0;
                foreach (var f in Directory.EnumerateFiles(path, "*", opt))
                {
                    try { total += new FileInfo(f).Length; } catch { }
                }
                return total;
            }
            catch { return -1; }
        }

        /// <summary>Nunca apagar pastas raiz do sistema/usuário.</summary>
        public static bool IsSafePath(string path)
        {
            string full;
            try { full = Path.GetFullPath(path).TrimEnd('\\'); } catch { return false; }

            string root = Path.GetPathRoot(full)?.TrimEnd('\\') ?? "";
            if (full.Length <= root.Length + 1) return false;

            var blocked = new[]
            {
                Environment.SpecialFolder.Windows, Environment.SpecialFolder.System, Environment.SpecialFolder.SystemX86,
                Environment.SpecialFolder.ProgramFiles, Environment.SpecialFolder.ProgramFilesX86,
                Environment.SpecialFolder.CommonProgramFiles, Environment.SpecialFolder.CommonProgramFilesX86,
                Environment.SpecialFolder.CommonApplicationData, Environment.SpecialFolder.ApplicationData,
                Environment.SpecialFolder.LocalApplicationData, Environment.SpecialFolder.UserProfile,
                Environment.SpecialFolder.Desktop, Environment.SpecialFolder.DesktopDirectory, Environment.SpecialFolder.MyDocuments,
                Environment.SpecialFolder.StartMenu, Environment.SpecialFolder.CommonStartMenu,
                Environment.SpecialFolder.Programs, Environment.SpecialFolder.CommonPrograms,
            }.Select(f => Environment.GetFolderPath(f).TrimEnd('\\')).Where(x => x.Length > 0);

            string local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
            var extra = new[] { Path.Combine(local, "Programs"), Path.Combine(local, "Temp"), Path.Combine(root + "\\", "Users") };

            return !blocked.Concat(extra).Any(b => string.Equals(b.TrimEnd('\\'), full, StringComparison.OrdinalIgnoreCase));
        }

        // ------------------------------------------------------------- registro

        static (RegistryKey? Base, string Sub) Split(string path)
        {
            int i = path.IndexOf('\\');
            if (i < 0) return (null, "");
            string hive = path[..i].ToUpperInvariant();
            string sub = path[(i + 1)..];
            RegistryKey? b = hive switch
            {
                "HKLM" or "HKEY_LOCAL_MACHINE" => RegistryKey.OpenBaseKey(RegistryHive.LocalMachine, RegistryView.Registry64),
                "HKCU" or "HKEY_CURRENT_USER" => RegistryKey.OpenBaseKey(RegistryHive.CurrentUser, RegistryView.Registry64),
                _ => null
            };
            return (b, sub);
        }

        static IEnumerable<string> SubKeys(string path)
        {
            var (b, sub) = Split(path);
            if (b == null) return Array.Empty<string>();
            try
            {
                using (b)
                using (var k = b.OpenSubKey(sub))
                    return k?.GetSubKeyNames() ?? Array.Empty<string>();
            }
            catch { return Array.Empty<string>(); }
        }

        public static bool KeyExists(string path)
        {
            var (b, sub) = Split(path);
            if (b == null) return false;
            try
            {
                using (b)
                using (var k = b.OpenSubKey(sub))
                    return k != null;
            }
            catch { return false; }
        }

        static bool DeleteKey(string path)
        {
            var (b, sub) = Split(path);
            if (b == null || sub.Count(c => c == '\\') < 1) return false; // nunca apaga HKLM\SOFTWARE etc.
            if (Generic.Contains(Norm(sub[(sub.LastIndexOf('\\') + 1)..]))) { b.Dispose(); return false; }
            try
            {
                using (b) b.DeleteSubKeyTree(sub, false);
                return true;
            }
            catch { return false; }
        }

        public static void OpenInRegedit(string path)
        {
            try
            {
                string full = path.Replace("HKLM\\", "HKEY_LOCAL_MACHINE\\").Replace("HKCU\\", "HKEY_CURRENT_USER\\");
                using (var k = Registry.CurrentUser.CreateSubKey(@"Software\Microsoft\Windows\CurrentVersion\Applets\Regedit"))
                    k.SetValue("LastKey", "Computador\\" + full);
                foreach (var p in Process.GetProcessesByName("regedit")) { try { p.Kill(); } catch { } p.Dispose(); }
                Process.Start(new ProcessStartInfo("regedit.exe", "-m") { UseShellExecute = true });
            }
            catch { }
        }

        // ------------------------------------------------------ remover sobras

        public static async Task<(int Ok, int Failed, string? BackupFolder)> RemoveLeftoversAsync(
            string programName, IEnumerable<Leftover> items, bool backup, bool toRecycle)
        {
            var list = items.ToList();
            int ok = 0, failed = 0;
            string? folder = null;

            var reg = list.Where(l => l.Kind == "Registro").ToList();
            if (backup && reg.Count > 0)
            {
                folder = Path.Combine(AppSettings.BackupDir, $"{DateTime.Now:yyyy-MM-dd_HH-mm-ss}_{SafeFileName(programName)}");
                Directory.CreateDirectory(folder);
                File.WriteAllText(Path.Combine(folder, "info.txt"),
                    programName + Environment.NewLine + string.Join(Environment.NewLine, reg.Select(r => r.Path)), Encoding.UTF8);
                int n = 1;
                foreach (var r in reg)
                {
                    string target = Path.Combine(folder, $"{n++:00}.reg");
                    await Shell.RunAsync("reg.exe", $"export \"{r.Path}\" \"{target}\" /y", 30000);
                }
            }

            foreach (var item in list)
            {
                bool success;
                if (item.Kind == "Registro") success = DeleteKey(item.Path);
                else success = await Task.Run(() => DeletePath(item.Path, toRecycle));
                if (success) ok++; else failed++;
            }
            return (ok, failed, folder);
        }

        static bool DeletePath(string path, bool toRecycle)
        {
            if (!IsSafePath(path)) return false;
            try
            {
                if (toRecycle && Native.SendToRecycleBin(path)) return !File.Exists(path) && !Directory.Exists(path);
                if (File.Exists(path)) { File.SetAttributes(path, FileAttributes.Normal); File.Delete(path); }
                else if (Directory.Exists(path)) Directory.Delete(path, true);
                return true;
            }
            catch { return false; }
        }

        static string SafeFileName(string s)
        {
            var bad = Path.GetInvalidFileNameChars();
            var clean = new string(s.Select(c => bad.Contains(c) ? '_' : c).ToArray());
            return clean.Length > 40 ? clean[..40] : clean;
        }

        // ---------------------------------------------------------------- backups

        public static List<BackupEntry> ListBackups()
        {
            var list = new List<BackupEntry>();
            if (!Directory.Exists(AppSettings.BackupDir)) return list;
            foreach (var d in Directory.GetDirectories(AppSettings.BackupDir))
            {
                try
                {
                    string info = Path.Combine(d, "info.txt");
                    string title = File.Exists(info) ? File.ReadLines(info).FirstOrDefault() ?? Path.GetFileName(d) : Path.GetFileName(d);
                    list.Add(new BackupEntry
                    {
                        Folder = d,
                        Title = title,
                        Date = Directory.GetCreationTime(d),
                        Keys = Directory.GetFiles(d, "*.reg").Length
                    });
                }
                catch { }
            }
            return list.OrderByDescending(b => b.Date).ToList();
        }

        public static async Task<int> RestoreBackupAsync(BackupEntry b)
        {
            int ok = 0;
            foreach (var f in Directory.GetFiles(b.Folder, "*.reg").OrderBy(x => x))
            {
                var (code, _) = await Shell.RunAsync("reg.exe", $"import \"{f}\"", 30000);
                if (code == 0) ok++;
            }
            return ok;
        }

        // ------------------------------------------------------- apps da Store

        public static async Task<List<StoreApp>> LoadStoreAppsAsync()
        {
            var (_, output) = await Shell.PowerShellAsync(
                "Get-AppxPackage | Where-Object { -not $_.IsFramework -and $_.SignatureKind -ne 'System' } | " +
                "Select-Object Name,PackageFullName,Publisher,@{n='Version';e={$_.Version.ToString()}},InstallLocation,NonRemovable | " +
                "ConvertTo-Json -Compress", 120000);

            var list = new List<StoreApp>();
            int start = output.IndexOfAny(new[] { '[', '{' });
            if (start < 0) return list;
            try
            {
                using var doc = JsonDocument.Parse(output[start..]);
                var items = doc.RootElement.ValueKind == JsonValueKind.Array
                    ? doc.RootElement.EnumerateArray().ToList()
                    : new List<JsonElement> { doc.RootElement };

                foreach (var e in items)
                {
                    string name = Get(e, "Name");
                    string loc = Get(e, "InstallLocation");
                    list.Add(new StoreApp
                    {
                        Name = name,
                        DisplayName = ManifestName(loc) ?? Pretty(name),
                        Publisher = Regex.Match(Get(e, "Publisher"), @"CN=([^,]+)").Groups[1].Value.Trim('"', ' '),
                        Version = Get(e, "Version"),
                        FullName = Get(e, "PackageFullName"),
                        InstallLocation = loc,
                        NonRemovable = e.TryGetProperty("NonRemovable", out var nr) && nr.ValueKind == JsonValueKind.True
                    });
                }
            }
            catch { }
            return list.OrderBy(a => a.DisplayName, StringComparer.CurrentCultureIgnoreCase).ToList();
        }

        static string Get(JsonElement e, string name) =>
            e.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() ?? "" : "";

        static string? ManifestName(string location)
        {
            try
            {
                string manifest = Path.Combine(location, "AppxManifest.xml");
                if (!File.Exists(manifest)) return null;
                var doc = XDocument.Load(manifest);
                var dn = doc.Descendants().FirstOrDefault(x => x.Name.LocalName == "DisplayName")?.Value;
                return string.IsNullOrWhiteSpace(dn) || dn.StartsWith("ms-resource", StringComparison.OrdinalIgnoreCase) ? null : dn.Trim();
            }
            catch { return null; }
        }

        static string Pretty(string name)
        {
            string s = name.Contains('.') ? name[(name.LastIndexOf('.') + 1)..] : name;
            return Regex.Replace(s, "(?<=[a-z])(?=[A-Z])", " ");
        }

        public static async Task<bool> RemoveStoreAppAsync(StoreApp app)
        {
            var (code, output) = await Shell.PowerShellAsync($"Remove-AppxPackage -Package '{app.FullName.Replace("'", "")}' -ErrorAction Stop", 180000);
            return code == 0 && !output.Contains("Exception", StringComparison.OrdinalIgnoreCase);
        }
    }
}

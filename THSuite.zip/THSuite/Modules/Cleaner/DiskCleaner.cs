using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using Microsoft.Win32;

namespace THSuite.Cleaner
{
    public enum SpecialAction { None, RecycleBin, DnsCache }

    /// <summary>Uma pasta (ou padrão de arquivos) a ser limpa.</summary>
    public record CleanTarget(string Dir, string Pattern = "*", bool Recursive = true, int MinAgeHours = 0);

    public class CleanCategory : Observable
    {
        bool _isChecked;
        long _size = -1;
        int _files;
        string _status = "";

        public string Id { get; init; } = "";
        public string Group { get; init; } = "";
        public string Name { get; init; } = "";
        public string Description { get; init; } = "";
        public string Warning { get; init; } = "";
        public bool DefaultOn { get; init; } = true;
        public bool UsesTempAge { get; init; }
        public SpecialAction Special { get; init; }
        public string[] Processes { get; init; } = Array.Empty<string>();
        public List<CleanTarget> Targets { get; init; } = new();

        public bool HasWarning => Warning.Length > 0;
        public bool IsChecked { get => _isChecked; set => Set(ref _isChecked, value); }
        public long Size { get => _size; set { if (Set(ref _size, value)) Raise(nameof(SizeText)); } }
        public int Files { get => _files; set => Set(ref _files, value); }
        public string Status { get => _status; set => Set(ref _status, value); }

        public string SizeText => Special == SpecialAction.DnsCache ? (Size >= 0 ? "—" : "")
                                : Size < 0 ? "" : Fmt.Size(Size);

        /// <summary>Existe algo dessa categoria neste PC?</summary>
        public bool Available => Special != SpecialAction.None || Group == "Windows" || Targets.Any(t => Directory.Exists(t.Dir));
    }

    public static class DiskCleaner
    {
        static readonly string Local = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        static readonly string Roaming = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
        static readonly string Win = Environment.GetFolderPath(Environment.SpecialFolder.Windows);
        static readonly string ProgData = Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
        static readonly string UserTemp = Path.GetTempPath();

        // =====================================================================
        //  Categorias
        // =====================================================================

        public static List<CleanCategory> BuildCategories()
        {
            var list = new List<CleanCategory>
            {
                // ---------------- Windows ----------------
                new() { Id = "user_temp", Group = "Windows", Name = "Arquivos temporários do usuário", UsesTempAge = true,
                        Description = "Pasta %TEMP% — sobras de instaladores e programas",
                        Targets = { new(UserTemp) } },
                new() { Id = "win_temp", Group = "Windows", Name = "Temporários do Windows", UsesTempAge = true,
                        Description = "C:\\Windows\\Temp",
                        Targets = { new(Path.Combine(Win, "Temp")) } },
                new() { Id = "recycle", Group = "Windows", Name = "Lixeira", Special = SpecialAction.RecycleBin,
                        Description = "Esvazia a Lixeira de todos os discos" },
                new() { Id = "thumbs", Group = "Windows", Name = "Cache de miniaturas",
                        Description = "Miniaturas de fotos e vídeos do Explorador (são recriadas)",
                        Targets = { new(Path.Combine(Local, @"Microsoft\Windows\Explorer"), "thumbcache_*.db", false),
                                    new(Path.Combine(Local, @"Microsoft\Windows\Explorer"), "iconcache_*.db", false) } },
                new() { Id = "wu", Group = "Windows", Name = "Cache do Windows Update",
                        Description = "Atualizações já instaladas que ficaram baixadas",
                        Targets = { new(Path.Combine(Win, @"SoftwareDistribution\Download")) } },
                new() { Id = "delivery", Group = "Windows", Name = "Otimização de Entrega",
                        Description = "Cache de atualizações compartilhadas na rede",
                        Targets = { new(Path.Combine(Win, @"ServiceProfiles\NetworkService\AppData\Local\Microsoft\Windows\DeliveryOptimization\Cache")) } },
                new() { Id = "wer", Group = "Windows", Name = "Relatórios de erro",
                        Description = "Relatórios de travamentos de programas",
                        Targets = { new(Path.Combine(ProgData, @"Microsoft\Windows\WER\ReportArchive")),
                                    new(Path.Combine(ProgData, @"Microsoft\Windows\WER\ReportQueue")),
                                    new(Path.Combine(Local, @"Microsoft\Windows\WER")) } },
                new() { Id = "dumps", Group = "Windows", Name = "Despejos de memória",
                        Description = "Arquivos gerados em telas azuis e travamentos",
                        Targets = { new(Path.Combine(Win, "Minidump")),
                                    new(Win, "MEMORY.DMP", false),
                                    new(Path.Combine(Local, "CrashDumps")) } },
                new() { Id = "logs", Group = "Windows", Name = "Logs antigos do Windows",
                        Description = "Arquivos .log com mais de 7 dias",
                        Targets = { new(Path.Combine(Win, "Logs"), "*.log", true, 24 * 7),
                                    new(Path.Combine(Win, @"System32\LogFiles"), "*.log", true, 24 * 7) } },
                new() { Id = "shader", Group = "Windows", Name = "Cache de shaders (DirectX / placa de vídeo)", DefaultOn = false,
                        Description = "Shaders de jogos e da GPU",
                        Warning = "Jogos podem travar um pouco na primeira vez que abrirem depois",
                        Targets = { new(Path.Combine(Local, "D3DSCache")),
                                    new(Path.Combine(Local, @"NVIDIA\DXCache")), new(Path.Combine(Local, @"NVIDIA\GLCache")),
                                    new(Path.Combine(Local, @"AMD\DxCache")), new(Path.Combine(Local, @"AMD\GLCache")),
                                    new(Path.Combine(Local, @"Intel\ShaderCache")) } },
                new() { Id = "prefetch", Group = "Windows", Name = "Prefetch", DefaultOn = false,
                        Description = "Dados que o Windows usa para abrir programas mais rápido",
                        Warning = "Os programas podem abrir um pouco mais devagar por alguns dias",
                        Targets = { new(Path.Combine(Win, "Prefetch"), "*.pf", false) } },
                new() { Id = "recent", Group = "Windows", Name = "Lista de arquivos recentes", DefaultOn = false,
                        Description = "Histórico de arquivos abertos (privacidade)",
                        Targets = { new(Path.Combine(Roaming, @"Microsoft\Windows\Recent"), "*.lnk", false),
                                    new(Path.Combine(Roaming, @"Microsoft\Windows\Recent\AutomaticDestinations"), "*", false),
                                    new(Path.Combine(Roaming, @"Microsoft\Windows\Recent\CustomDestinations"), "*", false) } },
                new() { Id = "dns", Group = "Windows", Name = "Cache DNS", Special = SpecialAction.DnsCache, DefaultOn = false,
                        Description = "Ajuda quando sites não abrem ou mudaram de endereço" },
            };

            // ---------------- Navegadores ----------------
            AddChromium(list, "chrome", "Google Chrome", Path.Combine(Local, @"Google\Chrome\User Data"), null);
            AddChromium(list, "edge", "Microsoft Edge", Path.Combine(Local, @"Microsoft\Edge\User Data"), null);
            AddChromium(list, "brave", "Brave", Path.Combine(Local, @"BraveSoftware\Brave-Browser\User Data"), null);
            AddChromium(list, "vivaldi", "Vivaldi", Path.Combine(Local, @"Vivaldi\User Data"), null);
            AddChromium(list, "opera", "Opera", Path.Combine(Roaming, @"Opera Software\Opera Stable"), Path.Combine(Local, @"Opera Software\Opera Stable"));
            AddChromium(list, "operagx", "Opera GX", Path.Combine(Roaming, @"Opera Software\Opera GX Stable"), Path.Combine(Local, @"Opera Software\Opera GX Stable"));
            AddFirefox(list);

            // ---------------- Aplicativos ----------------
            list.Add(new() { Id = "discord", Group = "Aplicativos", Name = "Discord — cache", Processes = new[] { "Discord" },
                             Description = "Imagens, vídeos e arquivos em cache",
                             Targets = Dirs(Path.Combine(Roaming, "discord"), "Cache", "Code Cache", "GPUCache") });
            list.Add(new() { Id = "spotify", Group = "Aplicativos", Name = "Spotify — cache", Processes = new[] { "Spotify" },
                             Description = "Músicas em cache (são baixadas de novo)",
                             Targets = { new(Path.Combine(Local, @"Spotify\Data")), new(Path.Combine(Local, @"Spotify\Browser\Cache")) } });
            string? steam = SteamPath();
            var steamTargets = new List<CleanTarget> { new(Path.Combine(Local, @"Steam\htmlcache")) };
            if (steam != null)
            {
                steamTargets.Add(new(Path.Combine(steam, @"appcache\httpcache")));
                steamTargets.Add(new(Path.Combine(steam, "logs"), "*", true, 24));
                steamTargets.Add(new(Path.Combine(steam, "dumps")));
            }
            list.Add(new() { Id = "steam", Group = "Aplicativos", Name = "Steam — cache e logs", Processes = new[] { "steam", "steamwebhelper" },
                             Description = "Cache da loja, logs e dumps", Targets = steamTargets });
            list.Add(new() { Id = "epic", Group = "Aplicativos", Name = "Epic Games — cache", Processes = new[] { "EpicGamesLauncher", "EpicWebHelper" },
                             Description = "Cache web e logs do launcher",
                             Targets = { new(Path.Combine(Local, @"EpicGamesLauncher\Saved\webcache")),
                                         new(Path.Combine(Local, @"EpicGamesLauncher\Saved\webcache_4147")),
                                         new(Path.Combine(Local, @"EpicGamesLauncher\Saved\webcache_4430")),
                                         new(Path.Combine(Local, @"EpicGamesLauncher\Saved\Logs")) } });
            list.Add(new() { Id = "teams", Group = "Aplicativos", Name = "Microsoft Teams (clássico) — cache", Processes = new[] { "Teams" },
                             Description = "Cache do Teams clássico",
                             Targets = Dirs(Path.Combine(Roaming, @"Microsoft\Teams"), "Cache", "Code Cache", "GPUCache", "blob_storage", "tmp") });
            list.Add(new() { Id = "vscode", Group = "Aplicativos", Name = "VS Code — cache", Processes = new[] { "Code" },
                             Description = "Cache e logs do Visual Studio Code",
                             Targets = Dirs(Path.Combine(Roaming, "Code"), "Cache", "CachedData", "Code Cache", "GPUCache", "logs") });
            list.Add(new() { Id = "devcache", Group = "Aplicativos", Name = "Cache de desenvolvedor (npm, pip, NuGet)", DefaultOn = false,
                             Description = "Pacotes baixados por ferramentas de programação",
                             Warning = "Os pacotes serão baixados de novo quando precisar",
                             Targets = { new(Path.Combine(Local, "npm-cache")), new(Path.Combine(Local, @"pip\cache")),
                                         new(Path.Combine(Local, @"NuGet\v3-cache")) } });

            return list.Where(c => c.Available).ToList();
        }

        static List<CleanTarget> Dirs(string root, params string[] subs) =>
            subs.Select(s => new CleanTarget(Path.Combine(root, s))).ToList();

        static void AddChromium(List<CleanCategory> list, string id, string name, string userData, string? cacheRoot)
        {
            if (!Directory.Exists(userData)) return;

            // Opera guarda o perfil direto na pasta; os outros têm Default / Profile N
            var profiles = new List<string>();
            if (File.Exists(Path.Combine(userData, "Preferences"))) profiles.Add(userData);
            try
            {
                profiles.AddRange(Directory.GetDirectories(userData)
                    .Where(d => Path.GetFileName(d) == "Default" || Path.GetFileName(d).StartsWith("Profile ")));
            }
            catch { }

            string proc = id switch { "edge" => "msedge", "operagx" => "opera", _ => id };
            var cache = new List<CleanTarget>();
            var cookies = new List<CleanTarget>();
            var history = new List<CleanTarget>();

            foreach (var p in profiles)
            {
                string c = cacheRoot ?? p;
                foreach (var sub in new[] { @"Cache", @"Code Cache", @"GPUCache", @"Service Worker\CacheStorage", @"Service Worker\ScriptCache" })
                    cache.Add(new(Path.Combine(c, sub)));
                if (cacheRoot != null)
                    foreach (var sub in new[] { @"Code Cache", @"GPUCache", @"Service Worker\CacheStorage" })
                        cache.Add(new(Path.Combine(p, sub)));

                cookies.Add(new(Path.Combine(p, "Network"), "Cookies*", false));
                cookies.Add(new(p, "Cookies*", false));
                history.Add(new(p, "History*", false));
                history.Add(new(p, "Visited Links", false));
                history.Add(new(p, "Top Sites*", false));
            }
            cache.Add(new(Path.Combine(userData, "ShaderCache")));
            cache.Add(new(Path.Combine(userData, "GrShaderCache")));

            var procs = new[] { proc };
            list.Add(new() { Id = id + "_cache", Group = "Navegadores", Name = $"{name} — cache", Processes = procs,
                             Description = "Imagens e arquivos de sites guardados", Targets = cache });
            list.Add(new() { Id = id + "_cookies", Group = "Navegadores", Name = $"{name} — cookies", Processes = procs, DefaultOn = false,
                             Description = "Logins e preferências de sites", Warning = "Você vai sair das contas dos sites", Targets = cookies });
            list.Add(new() { Id = id + "_history", Group = "Navegadores", Name = $"{name} — histórico", Processes = procs, DefaultOn = false,
                             Description = "Sites visitados", Targets = history });
        }

        static void AddFirefox(List<CleanCategory> list)
        {
            string localProfiles = Path.Combine(Local, @"Mozilla\Firefox\Profiles");
            string roamingProfiles = Path.Combine(Roaming, @"Mozilla\Firefox\Profiles");
            if (!Directory.Exists(localProfiles) && !Directory.Exists(roamingProfiles)) return;

            var cache = new List<CleanTarget>();
            var cookies = new List<CleanTarget>();
            try
            {
                if (Directory.Exists(localProfiles))
                    foreach (var p in Directory.GetDirectories(localProfiles))
                    {
                        cache.Add(new(Path.Combine(p, "cache2")));
                        cache.Add(new(Path.Combine(p, "startupCache")));
                        cache.Add(new(Path.Combine(p, "thumbnails")));
                    }
                if (Directory.Exists(roamingProfiles))
                    foreach (var p in Directory.GetDirectories(roamingProfiles))
                        cookies.Add(new(p, "cookies.sqlite*", false));
            }
            catch { }

            var procs = new[] { "firefox" };
            list.Add(new() { Id = "firefox_cache", Group = "Navegadores", Name = "Firefox — cache", Processes = procs,
                             Description = "Imagens e arquivos de sites guardados", Targets = cache });
            list.Add(new() { Id = "firefox_cookies", Group = "Navegadores", Name = "Firefox — cookies", Processes = procs, DefaultOn = false,
                             Description = "Logins e preferências de sites", Warning = "Você vai sair das contas dos sites", Targets = cookies });
        }

        static string? SteamPath()
        {
            try
            {
                using var k = Registry.CurrentUser.OpenSubKey(@"Software\Valve\Steam");
                return (k?.GetValue("SteamPath") as string)?.Replace('/', '\\');
            }
            catch { return null; }
        }

        // =====================================================================
        //  Análise e limpeza
        // =====================================================================

        public static bool IsRunning(CleanCategory c) =>
            c.Processes.Any(p => { var ps = Process.GetProcessesByName(p); bool r = ps.Length > 0; foreach (var x in ps) x.Dispose(); return r; });

        public static void CloseProcesses(CleanCategory c)
        {
            var list = c.Processes.SelectMany(n => Process.GetProcessesByName(n)).ToList();
            foreach (var p in list) { try { p.CloseMainWindow(); } catch { } }
            Thread.Sleep(2500);
            foreach (var p in list)
            {
                try { if (!p.HasExited) p.Kill(true); } catch { }
                p.Dispose();
            }
            Thread.Sleep(500);
        }

        public static (long Size, int Files) Measure(CleanCategory c, AppSettings s, CancellationToken ct)
        {
            if (c.Special == SpecialAction.RecycleBin)
            {
                var (size, items) = Native.RecycleBinInfo();
                return (size, (int)items);
            }
            if (c.Special == SpecialAction.DnsCache) return (0, 0);

            long total = 0; int count = 0;
            foreach (var f in Files(c, s, ct)) { total += f.Length; count++; }
            return (total, count);
        }

        public static (long Freed, int Deleted, int Failed) Clean(CleanCategory c, AppSettings s, CancellationToken ct)
        {
            if (c.Special == SpecialAction.RecycleBin)
            {
                var (size, items) = Native.RecycleBinInfo();
                Native.EmptyRecycleBin();
                var (after, _) = Native.RecycleBinInfo();
                return (Math.Max(0, size - after), (int)items, 0);
            }
            if (c.Special == SpecialAction.DnsCache)
            {
                try
                {
                    using var p = Process.Start(new ProcessStartInfo("ipconfig.exe", "/flushdns") { CreateNoWindow = true, UseShellExecute = false });
                    p?.WaitForExit(10000);
                }
                catch { }
                return (0, 0, 0);
            }

            long freed = 0; int deleted = 0, failed = 0;
            foreach (var f in Files(c, s, ct).ToList())
            {
                if (ct.IsCancellationRequested) break;
                try
                {
                    long len = f.Length;
                    if (f.IsReadOnly) f.IsReadOnly = false;
                    f.Delete();
                    freed += len; deleted++;
                }
                catch { failed++; }
            }

            // Remove pastas vazias que sobraram (nunca a pasta raiz)
            foreach (var t in c.Targets.Where(t => t.Recursive && t.Pattern == "*" && Directory.Exists(t.Dir)))
            {
                try
                {
                    var dirs = Directory.EnumerateDirectories(t.Dir, "*", Options(true))
                                        .OrderByDescending(d => d.Length).ToList();
                    foreach (var d in dirs)
                    {
                        if (IsExcluded(d, s)) continue;
                        try { if (!Directory.EnumerateFileSystemEntries(d).Any()) Directory.Delete(d); } catch { }
                    }
                }
                catch { }
            }
            return (freed, deleted, failed);
        }

        static IEnumerable<FileInfo> Files(CleanCategory c, AppSettings s, CancellationToken ct)
        {
            var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            foreach (var t in c.Targets)
            {
                if (!Directory.Exists(t.Dir) || (t.Pattern == "*" && t.Recursive && IsProtected(t.Dir))) continue;
                int minAge = Math.Max(t.MinAgeHours, c.UsesTempAge ? s.TempMinAgeHours : 0);
                DateTime cutoff = DateTime.Now.AddHours(-minAge);

                IEnumerable<string> paths;
                try { paths = Directory.EnumerateFiles(t.Dir, t.Pattern, Options(t.Recursive)); }
                catch { continue; }

                using var e = paths.GetEnumerator();
                while (true)
                {
                    if (ct.IsCancellationRequested) yield break;
                    string path;
                    try { if (!e.MoveNext()) break; path = e.Current; }
                    catch { break; }

                    if (!seen.Add(path) || IsExcluded(path, s)) continue;
                    FileInfo fi;
                    try
                    {
                        fi = new FileInfo(path);
                        if (minAge > 0 && fi.LastWriteTime > cutoff) continue;
                    }
                    catch { continue; }
                    yield return fi;
                }
            }
        }

        static EnumerationOptions Options(bool recursive) => new()
        {
            RecurseSubdirectories = recursive,
            IgnoreInaccessible = true,
            AttributesToSkip = FileAttributes.ReparsePoint,
            ReturnSpecialDirectories = false
        };

        public static bool IsExcluded(string path, AppSettings s) =>
            s.Exclusions.Any(x => x.Length > 2 && path.StartsWith(x.TrimEnd('\\'), StringComparison.OrdinalIgnoreCase));

        /// <summary>Pastas que nunca são limpas inteiras (segurança).</summary>
        static bool IsProtected(string dir)
        {
            string d = Path.GetFullPath(dir).TrimEnd('\\');
            string[] blocked =
            {
                Path.GetPathRoot(d)!.TrimEnd('\\'), Win.TrimEnd('\\'), Path.Combine(Win, "System32"),
                Environment.GetFolderPath(Environment.SpecialFolder.UserProfile).TrimEnd('\\'),
                Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles).TrimEnd('\\'),
                Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86).TrimEnd('\\'),
                Local.TrimEnd('\\'), Roaming.TrimEnd('\\'), ProgData.TrimEnd('\\'),
                Environment.GetFolderPath(Environment.SpecialFolder.Desktop).TrimEnd('\\'),
                Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments).TrimEnd('\\'),
            };
            return blocked.Any(b => string.Equals(b, d, StringComparison.OrdinalIgnoreCase));
        }
    }
}

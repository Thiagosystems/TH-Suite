using System;
using System.Linq;
using System.Threading;
using System.Windows;
using System.Windows.Threading;

namespace THSuite
{
    public partial class App : Application
    {
        Mutex? _mutex;

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            _mutex = new Mutex(false, "THSuite_SingleInstance");
            bool created;
            try { created = _mutex.WaitOne(e.Args.Contains("--restart") ? 15000 : 0); }
            catch (AbandonedMutexException) { created = true; }
            if (!created)
            {
                // Já está aberto: pede para a outra instância aparecer
                try { using var ev = EventWaitHandle.OpenExisting("THSuite_Show"); ev.Set(); } catch { }
                Shutdown();
                return;
            }

            DispatcherUnhandledException += OnUnhandled;
            Memory.MemoryCleaner.EnablePrivileges();
            Memory.Loc.Apply("pt");

            var settings = SuiteSettings.Load();
            Lang.Init(settings.Language);
            Updater.Cleanup();
            ThemeManager.Apply(settings);
            bool hidden = e.Args.Contains("--tray") && settings.StartMinimized;

            var window = new MainWindow(settings, hidden);
            MainWindow = window;
            window.Show();

            // Outra instância pediu para mostrar a janela
            var show = new EventWaitHandle(false, EventResetMode.AutoReset, "THSuite_Show");
            var t = new Thread(() =>
            {
                while (true)
                {
                    show.WaitOne();
                    Dispatcher.Invoke(() => Host.ShowWindow());
                }
            }) { IsBackground = true };
            t.Start();
        }

        protected override void OnExit(ExitEventArgs e)
        {
            try { _mutex?.ReleaseMutex(); } catch { }
            base.OnExit(e);
        }

        void OnUnhandled(object sender, DispatcherUnhandledExceptionEventArgs e)
        {
            // Não derruba o app por causa de um erro inesperado em um módulo
            try
            {
                System.IO.Directory.CreateDirectory(SuiteSettings.DataDir);
                System.IO.File.AppendAllText(System.IO.Path.Combine(SuiteSettings.DataDir, "erros.log"),
                    $"[{DateTime.Now:dd/MM/yyyy HH:mm:ss}] {e.Exception}\r\n\r\n");
            }
            catch { }
            e.Handled = true;
        }
    }
}

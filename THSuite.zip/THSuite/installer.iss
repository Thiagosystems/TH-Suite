; Instalador do TH Suite (Inno Setup 6 - https://jrsoftware.org/isinfo.php)
; O build.bat gera o setup automaticamente se o Inno Setup estiver instalado.

#define AppName "TH Suite"
#define AppVersion "1.1.0"
#define AppExe "THSuite.exe"

[Setup]
AppId={{6F1E2A44-7C3B-4D1A-9B2E-54D3A1C7E9F0}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher=Thiagosystems
AppPublisherURL=https://github.com/Thiagosystems/THSuite
DefaultDirName={autopf}\TH Suite
DefaultGroupName=TH Suite
DisableProgramGroupPage=yes
OutputDir=publish
OutputBaseFilename=THSuite-Setup
SetupIconFile=Assets\app.ico
UninstallDisplayIcon={app}\{#AppExe}
Compression=lzma2/max
SolidCompression=yes
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
WizardStyle=modern
CloseApplications=yes

[Languages]
Name: "pt"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"
Name: "en"; MessagesFile: "compiler:Default.isl"
Name: "es"; MessagesFile: "compiler:Languages\Spanish.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"

[Files]
Source: "publish\{#AppExe}"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\{#AppName}"; Filename: "{app}\{#AppExe}"
Name: "{group}\Desinstalar {#AppName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\{#AppExe}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#AppExe}"; Description: "{cm:LaunchProgram,{#AppName}}"; Flags: nowait postinstall skipifsilent shellexec

[UninstallRun]
Filename: "schtasks.exe"; Parameters: "/Delete /F /TN ""TH Suite"""; Flags: runhidden; RunOnceId: "RemoveTask"

[UninstallDelete]
Type: files; Name: "{app}\THSuite.old.exe"

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows;

namespace THSuite
{
    public class ActivityEntry
    {
        public DateTime Time { get; set; }
        public string Module { get; set; } = "";
        public string Text { get; set; } = "";
        public string TimeText => Time.ToString("dd/MM/yyyy HH:mm");
    }

    /// <summary>Histórico geral: tudo o que o TH Suite fez (limpezas, ajustes, reparos, verificações...).</summary>
    public static class Activity
    {
        const int Max = 1500;
        static readonly object Lock = new();
        static List<ActivityEntry>? _items;

        public static event Action? Changed;

        static string FilePath => Path.Combine(SuiteSettings.DataDir, "historico.json");

        public static List<ActivityEntry> Items
        {
            get
            {
                lock (Lock)
                {
                    if (_items == null)
                    {
                        try { _items = File.Exists(FilePath) ? JsonSerializer.Deserialize<List<ActivityEntry>>(File.ReadAllText(FilePath)) : null; }
                        catch { _items = null; }
                        _items ??= new List<ActivityEntry>();
                    }
                    return _items.ToList();
                }
            }
        }

        public static void Log(string module, string text)
        {
            _ = Items; // garante carregado
            lock (Lock)
            {
                _items!.Insert(0, new ActivityEntry { Time = DateTime.Now, Module = module, Text = text });
                if (_items.Count > Max) _items.RemoveRange(Max, _items.Count - Max);
                Save();
            }
            try { Application.Current?.Dispatcher.BeginInvoke(new Action(() => Changed?.Invoke())); } catch { }
        }

        public static void Clear()
        {
            lock (Lock) { _items = new List<ActivityEntry>(); Save(); }
            Changed?.Invoke();
        }

        static void Save()
        {
            try
            {
                Directory.CreateDirectory(SuiteSettings.DataDir);
                File.WriteAllText(FilePath, JsonSerializer.Serialize(_items));
            }
            catch { }
        }
    }
}

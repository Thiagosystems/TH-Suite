using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace THSuite
{
    /// <summary>
    /// Idiomas (Português / English / Español). Os textos da interface são escritos em português;
    /// a tradução vem de Assets/lang.tsv (colunas: pt, en, es) e é aplicada quando cada elemento aparece.
    /// Para traduzir mais coisas, basta acrescentar linhas no arquivo.
    /// </summary>
    public static class Lang
    {
        static readonly Dictionary<string, (string En, string Es)> D = new(StringComparer.Ordinal);
        public static string Current { get; private set; } = "pt";

        public static void Init(string lang)
        {
            Current = lang is "en" or "es" ? lang : "pt";
            if (Current == "pt") return;
            try
            {
                using var s = Application.GetResourceStream(new Uri("pack://application:,,,/Assets/lang.tsv")).Stream;
                using var r = new StreamReader(s);
                string? line;
                while ((line = r.ReadLine()) != null)
                {
                    var p = line.Split('\t');
                    if (p.Length < 3 || p[0].Length == 0 || p[0].StartsWith("#")) continue;
                    D[Unescape(p[0])] = (Unescape(p[1]), Unescape(p[2]));
                }
            }
            catch { }
            EventManager.RegisterClassHandler(typeof(TextBlock), FrameworkElement.LoadedEvent, new RoutedEventHandler(OnLoaded));
            EventManager.RegisterClassHandler(typeof(ContentControl), FrameworkElement.LoadedEvent, new RoutedEventHandler(OnLoaded));
        }

        static string Unescape(string s) => s.Replace("\\n", "\n");

        /// <summary>Traduz um texto escrito em português (se houver tradução).</summary>
        public static string T(string pt)
        {
            if (Current == "pt" || string.IsNullOrEmpty(pt)) return pt;
            if (D.TryGetValue(pt, out var t)) return (Current == "en" ? t.En : t.Es) is { Length: > 0 } x ? x : pt;
            return pt;
        }

        static bool Mine(DependencyObject d, DependencyProperty p)
        {
            var src = DependencyPropertyHelper.GetValueSource(d, p).BaseValueSource;
            return src is BaseValueSource.Local or BaseValueSource.ParentTemplate;
        }

        static void OnLoaded(object sender, RoutedEventArgs e)
        {
            switch (sender)
            {
                case TextBlock tb when tb.Text.Length > 0 && !BindingOperations.IsDataBound(tb, TextBlock.TextProperty) && Mine(tb, TextBlock.TextProperty):
                    string t = T(tb.Text);
                    if (!ReferenceEquals(t, tb.Text) && t != tb.Text) tb.Text = t;
                    break;
                case ContentControl cc when cc.Content is string s && !BindingOperations.IsDataBound(cc, ContentControl.ContentProperty) && Mine(cc, ContentControl.ContentProperty):
                    string c = T(s);
                    if (c != s) cc.Content = c;
                    break;
            }
            if (sender is FrameworkElement fe && fe.ToolTip is string tip)
            {
                string tt = T(tip);
                if (tt != tip) fe.ToolTip = tt;
            }
        }
    }
}

using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;

namespace THSuite
{
    /// <summary>Atualização automática pelas Releases do GitHub.</summary>
    public static class Updater
    {
        public const string Repo = "Thiagosystems/THSuite";

        public record Release(string Version, string Notes, string Url, string Page);

        static HttpClient Client()
        {
            var c = new HttpClient { Timeout = TimeSpan.FromSeconds(30) };
            c.DefaultRequestHeaders.UserAgent.ParseAdd("THSuite/" + MainWindow.Version);
            return c;
        }

        /// <summary>Retorna a versão nova, ou null se já está na última (ou sem internet).</summary>
        public static async Task<Release?> CheckAsync()
        {
            try
            {
                using var c = Client();
                string json = await c.GetStringAsync($"https://api.github.com/repos/{Repo}/releases/latest");
                using var doc = JsonDocument.Parse(json);
                var root = doc.RootElement;
                string tag = root.GetProperty("tag_name").GetString() ?? "";
                string notes = root.TryGetProperty("body", out var b) ? b.GetString() ?? "" : "";
                string page = root.TryGetProperty("html_url", out var h) ? h.GetString() ?? "" : "";
                string url = "";
                if (root.TryGetProperty("assets", out var assets))
                    foreach (var a in assets.EnumerateArray())
                    {
                        string name = a.GetProperty("name").GetString() ?? "";
                        if (name.EndsWith(".exe", StringComparison.OrdinalIgnoreCase) && !name.Contains("setup", StringComparison.OrdinalIgnoreCase))
                        { url = a.GetProperty("browser_download_url").GetString() ?? ""; break; }
                    }
                if (!Version.TryParse(tag.TrimStart('v', 'V'), out var remote)) return null;
                if (!Version.TryParse(MainWindow.Version, out var local)) return null;
                return remote > local && url.Length > 0 ? new Release(tag.TrimStart('v', 'V'), notes, url, page) : null;
            }
            catch { return null; }
        }

        /// <summary>Baixa o .exe novo, troca pelo atual e reinicia.</summary>
        public static async Task<string?> InstallAsync(Release r, IProgress<double>? progress = null)
        {
            try
            {
                string exe = Environment.ProcessPath!;
                string dir = Path.GetDirectoryName(exe)!;
                string tmp = Path.Combine(dir, "THSuite.new.exe");
                using (var c = Client())
                {
                    c.Timeout = TimeSpan.FromMinutes(10);
                    using var resp = await c.GetAsync(r.Url, HttpCompletionOption.ResponseHeadersRead);
                    resp.EnsureSuccessStatusCode();
                    long total = resp.Content.Headers.ContentLength ?? 0;
                    await using var src = await resp.Content.ReadAsStreamAsync();
                    await using var dst = File.Create(tmp);
                    var buf = new byte[81920];
                    long done = 0; int n;
                    while ((n = await src.ReadAsync(buf)) > 0)
                    {
                        await dst.WriteAsync(buf.AsMemory(0, n));
                        done += n;
                        if (total > 0) progress?.Report(done * 100.0 / total);
                    }
                }
                if (new FileInfo(tmp).Length < 1_000_000) { File.Delete(tmp); return "O arquivo baixado parece incompleto."; }

                // Um .exe em uso pode ser renomeado (não apagado)
                string old = Path.Combine(dir, "THSuite.old.exe");
                if (File.Exists(old)) File.Delete(old);
                File.Move(exe, old);
                File.Move(tmp, exe);
                Activity.Log("TH Suite", $"Atualizado para a versão {r.Version}");
                Process.Start(exe, "--restart");
                Host.Exit();
                return null;
            }
            catch (Exception ex) { return ex.Message; }
        }

        /// <summary>Apaga o executável antigo depois de uma atualização.</summary>
        public static void Cleanup()
        {
            try
            {
                string old = Path.Combine(Path.GetDirectoryName(Environment.ProcessPath!)!, "THSuite.old.exe");
                if (File.Exists(old)) File.Delete(old);
            }
            catch { }
        }
    }
}

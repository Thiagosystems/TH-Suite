using System;
using System.Diagnostics;
using System.IO;
using System.Security;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace THSuite
{
    /// <summary>Executa programas e scripts do PowerShell sem janela, com saída opcional linha a linha.</summary>
    public static class Cmd
    {
        public static async Task<(int Code, string Output)> RunAsync(string exe, string args,
            Action<string>? onLine = null, int timeoutMs = 120000, CancellationToken ct = default)
        {
            var sb = new StringBuilder();
            try
            {
                var psi = new ProcessStartInfo(exe, args)
                {
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    StandardOutputEncoding = Encoding.UTF8,
                    StandardErrorEncoding = Encoding.UTF8
                };
                using var p = new Process { StartInfo = psi, EnableRaisingEvents = true };
                void Line(string? s)
                {
                    if (s == null) return;
                    s = s.Replace("\0", "");
                    lock (sb) sb.AppendLine(s);
                    if (s.Trim().Length > 0) onLine?.Invoke(s);
                }
                p.OutputDataReceived += (_, e) => Line(e.Data);
                p.ErrorDataReceived += (_, e) => Line(e.Data);
                p.Start();
                p.BeginOutputReadLine();
                p.BeginErrorReadLine();

                using var cts = CancellationTokenSource.CreateLinkedTokenSource(ct);
                cts.CancelAfter(timeoutMs);
                try { await p.WaitForExitAsync(cts.Token); }
                catch (OperationCanceledException)
                {
                    try { p.Kill(true); } catch { }
                    Line(ct.IsCancellationRequested ? "Cancelado." : "Tempo esgotado.");
                    return (-1, sb.ToString());
                }
                p.WaitForExit();
                return (p.ExitCode, sb.ToString());
            }
            catch (Exception ex)
            {
                onLine?.Invoke("Erro: " + ex.Message);
                return (-1, ex.Message);
            }
        }

        /// <summary>Roda um script do PowerShell (codificado em Base64, sem problemas com aspas).</summary>
        public static Task<(int Code, string Output)> PowerShellAsync(string script,
            Action<string>? onLine = null, int timeoutMs = 120000, CancellationToken ct = default)
        {
            string full = "$ProgressPreference='SilentlyContinue'; [Console]::OutputEncoding=[Text.Encoding]::UTF8; " + script;
            string b64 = Convert.ToBase64String(Encoding.Unicode.GetBytes(full));
            return RunAsync("powershell.exe", "-NoProfile -NonInteractive -ExecutionPolicy Bypass -EncodedCommand " + b64, onLine, timeoutMs, ct);
        }

        public static void Open(string target)
        {
            try { Process.Start(new ProcessStartInfo(target) { UseShellExecute = true }); } catch { }
        }

        public static void Open(string exe, string args)
        {
            try { Process.Start(new ProcessStartInfo(exe, args) { UseShellExecute = true }); } catch { }
        }

        /// <summary>Reinicia o Explorador (barra de tarefas e área de trabalho) para aplicar mudanças visuais.</summary>
        public static async Task RestartExplorerAsync()
        {
            foreach (var p in Process.GetProcessesByName("explorer"))
            {
                try { p.Kill(); } catch { }
                p.Dispose();
            }
            // O Windows costuma reabrir sozinho; se não reabrir, abre
            await Task.Delay(3000);
            if (Process.GetProcessesByName("explorer").Length == 0)
            {
                try { Process.Start(new ProcessStartInfo("explorer.exe") { UseShellExecute = true }); } catch { }
            }
        }

        /// <summary>Notebook (tem bateria)?</summary>
        public static bool IsLaptop()
        {
            try { return System.Windows.Forms.SystemInformation.PowerStatus.BatteryChargeStatus != System.Windows.Forms.BatteryChargeStatus.NoSystemBattery; }
            catch { return false; }
        }

        /// <summary>Cria um ponto de restauração do Windows. Liga a Proteção do Sistema no C: se estiver desligada.</summary>
        public static async Task<(bool Ok, string Message)> CreateRestorePointAsync(string description, Action<string>? onLine = null)
        {
            string d = description.Replace("'", "");
            string script =
                "try { Enable-ComputerRestore -Drive \"$env:SystemDrive\\\" -ErrorAction SilentlyContinue } catch {}; " +
                // O Windows só aceita 1 ponto a cada 24 h por padrão; zera esse limite
                "New-ItemProperty -Path 'HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\SystemRestore' -Name SystemRestorePointCreationFrequency -Value 0 -PropertyType DWord -Force | Out-Null; " +
                $"try {{ Checkpoint-Computer -Description '{d}' -RestorePointType 'MODIFY_SETTINGS' -ErrorAction Stop; 'OK' }} catch {{ 'ERRO: ' + $_.Exception.Message }}";
            var (_, output) = await PowerShellAsync(script, onLine, 300000);
            bool ok = output.Contains("OK") && !output.Contains("ERRO");
            return (ok, ok ? "Ponto de restauração criado." : "Não foi possível criar o ponto de restauração. " + output.Trim());
        }
    }

    /// <summary>Iniciar com o Windows pelo Agendador de Tarefas (com privilégio de administrador, sem pedir UAC).</summary>
    public static class StartupManager
    {
        const string TaskName = "TH Suite";

        public static async Task SetAsync(bool enabled)
        {
            try
            {
                if (!enabled)
                {
                    await Cmd.RunAsync("schtasks.exe", $"/Delete /F /TN \"{TaskName}\"");
                    return;
                }
                string exe = SecurityElement.Escape(Environment.ProcessPath!)!;
                string user = SecurityElement.Escape(WindowsIdentity.GetCurrent().Name)!;
                string xml = $@"<?xml version=""1.0"" encoding=""UTF-16""?>
<Task version=""1.2"" xmlns=""http://schemas.microsoft.com/windows/2004/02/mit/task"">
  <Triggers><LogonTrigger><Enabled>true</Enabled><UserId>{user}</UserId></LogonTrigger></Triggers>
  <Principals><Principal id=""Author""><UserId>{user}</UserId><LogonType>InteractiveToken</LogonType><RunLevel>HighestAvailable</RunLevel></Principal></Principals>
  <Settings>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
  </Settings>
  <Actions Context=""Author""><Exec><Command>{exe}</Command><Arguments>--tray</Arguments></Exec></Actions>
</Task>";
                string tmp = Path.Combine(Path.GetTempPath(), "thsuite_task.xml");
                File.WriteAllText(tmp, xml, Encoding.Unicode);
                await Cmd.RunAsync("schtasks.exe", $"/Create /F /TN \"{TaskName}\" /XML \"{tmp}\"");
                File.Delete(tmp);
                // Remove tarefas dos apps antigos para não abrir tudo em dobro
                foreach (var old in new[] { "TH Reduct", "TH Control", "TH Guard" })
                    await Cmd.RunAsync("schtasks.exe", $"/Delete /F /TN \"{old}\"");
            }
            catch { }
        }
    }
}

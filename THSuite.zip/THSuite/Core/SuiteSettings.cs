using System;
using System.IO;
using System.Text.Json;

namespace THSuite
{
    /// <summary>Configurações gerais do TH Suite (aparência e comportamento da janela).
    /// Cada módulo guarda as próprias opções em %AppData%\THSuite\.</summary>
    public class SuiteSettings
    {
        // Aparência
        public string Theme { get; set; } = "dark";
        public string AccentA { get; set; } = "#22D3EE";
        public string AccentB { get; set; } = "#8B5CF6";
        public bool LogoUseAccent { get; set; } = false;
        public string LogoPrimary { get; set; } = "#E10600";
        public string LogoSecondary { get; set; } = "#E6E6E6";

        // Sistema
        public bool StartWithWindows { get; set; } = false;
        public bool StartMinimized { get; set; } = true;
        public bool CloseToTray { get; set; } = true;
        public bool TrayHintShown { get; set; } = false;
        public bool ConfirmTweaks { get; set; } = true;
        public bool RestorePointBeforeTweaks { get; set; } = true;
        public string LastPage { get; set; } = "home";
        public double WindowWidth { get; set; } = 1180;
        public double WindowHeight { get; set; } = 740;
        public string Language { get; set; } = "pt";

        // Automático
        public int AutoCleanDays { get; set; } = 0;     // 0 = nunca
        public int AutoScanDays { get; set; } = 0;
        public bool AutoCleanRam { get; set; } = false;
        public DateTime LastAutoClean { get; set; }
        public DateTime LastAutoScan { get; set; }
        public bool CheckUpdates { get; set; } = true;
        public bool FpsCounter { get; set; } = true;

        public static string DataDir => Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "THSuite");
        static string FilePath => Path.Combine(DataDir, "suite.json");

        public static SuiteSettings Current { get; private set; } = new();

        public static SuiteSettings Load()
        {
            try
            {
                if (File.Exists(FilePath))
                    Current = JsonSerializer.Deserialize<SuiteSettings>(File.ReadAllText(FilePath)) ?? new SuiteSettings();
            }
            catch { Current = new SuiteSettings(); }
            return Current;
        }

        public void Save()
        {
            try
            {
                Directory.CreateDirectory(DataDir);
                File.WriteAllText(FilePath, JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true }));
            }
            catch { }
        }
    }
}

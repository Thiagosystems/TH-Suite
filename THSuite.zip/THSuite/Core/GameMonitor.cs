using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Diagnostics.Tracing;
using Microsoft.Diagnostics.Tracing.Session;

namespace THSuite
{
    /// <summary>
    /// Conta quadros (FPS) lendo os eventos de "Present" do DirectX pelo ETW do Windows,
    /// o mesmo método do PresentMon. Não injeta nada no jogo (seguro para anti-cheat).
    /// </summary>
    public sealed class FpsCounter : IDisposable
    {
        static readonly Guid Dxgi = new("CA11C036-0102-4A2D-A6AD-F03CFED5D3C9");
        static readonly Guid D3D9 = new("783ACA0A-790E-4D7F-8451-AA850511C6B9");

        readonly ConcurrentDictionary<int, int> _counts = new();
        TraceEventSession? _session;
        public bool Running { get; private set; }
        public string Error { get; private set; } = "";

        public void Start()
        {
            if (Running) return;
            try
            {
                _session = new TraceEventSession("THSuite-FPS") { StopOnDispose = true };
                _session.EnableProvider(Dxgi, TraceEventLevel.Informational, ulong.MaxValue);
                _session.EnableProvider(D3D9, TraceEventLevel.Informational, ulong.MaxValue);
                _session.Source.AllEvents += OnEvent;
                Running = true;
                Task.Run(() =>
                {
                    try { _session.Source.Process(); }
                    catch (Exception ex) { Error = ex.Message; }
                    Running = false;
                });
            }
            catch (Exception ex)
            {
                Error = ex.Message;
                Running = false;
                try { _session?.Dispose(); } catch { }
                _session = null;
            }
        }

        void OnEvent(TraceEvent e)
        {
            int id = (int)e.ID;
            // DXGI Present_Start = 42, PresentMultiplaneOverlay_Start = 55; D3D9 Present_Start = 1
            bool present = e.ProviderGuid == Dxgi ? id == 42 || id == 55 : e.ProviderGuid == D3D9 && id == 1;
            if (present) _counts.AddOrUpdate(e.ProcessID, 1, (_, v) => v + 1);
        }

        /// <summary>Quadros por processo desde a última chamada.</summary>
        public Dictionary<int, int> TakeCounts()
        {
            var snap = new Dictionary<int, int>();
            foreach (var k in _counts.Keys.ToList())
                if (_counts.TryRemove(k, out int v)) snap[k] = v;
            return snap;
        }

        public void Stop()
        {
            try { _session?.Dispose(); } catch { }
            _session = null;
            Running = false;
        }

        public void Dispose() => Stop();
    }

    public class GameSample
    {
        public int T { get; set; }          // segundos desde o início
        public float Fps { get; set; }
        public float? CpuTemp { get; set; }
        public float? GpuTemp { get; set; }
        public float Cpu { get; set; }
        public float? Gpu { get; set; }
        public float Ram { get; set; }
    }

    public class GameSession
    {
        public string Game { get; set; } = "";
        public DateTime Start { get; set; }
        public int Seconds { get; set; }
        public float AvgFps { get; set; }
        public float LowFps { get; set; }    // 1% low
        public float MaxCpuTemp { get; set; }
        public float MaxGpuTemp { get; set; }
        public float AvgCpu { get; set; }
        public List<GameSample> Samples { get; set; } = new();

        public string Title => $"{Game}  ·  {Start:dd/MM HH:mm}";
        public string Summary => $"{TimeSpan.FromSeconds(Seconds):h\\:mm\\:ss}  ·  " +
                                 (AvgFps > 0 ? $"{AvgFps:0} FPS médio · 1% low {LowFps:0}  ·  " : "") +
                                 (MaxCpuTemp > 0 ? $"CPU máx {MaxCpuTemp:0} °C  ·  " : "") +
                                 (MaxGpuTemp > 0 ? $"GPU máx {MaxGpuTemp:0} °C" : "");
    }

    /// <summary>
    /// Detecta quando um jogo está rodando e grava a sessão: FPS, temperaturas e uso.
    /// </summary>
    public sealed class GameMonitor : IDisposable
    {
        public static GameMonitor? Instance { get; private set; }

        static readonly HashSet<string> NotGames = new(StringComparer.OrdinalIgnoreCase)
        {
            "explorer", "THSuite", "chrome", "msedge", "firefox", "opera", "brave", "vivaldi", "discord", "obs64", "obs32",
            "spotify", "steam", "steamwebhelper", "epicgameslauncher", "battle.net", "riotclientux", "riotclientservices",
            "applicationframehost", "searchhost", "startmenuexperiencehost", "shellexperiencehost", "textinputhost",
            "dwm", "vlc", "mpc-hc64", "potplayermini64", "code", "devenv", "teams", "ms-teams", "whatsapp", "telegram",
            "photoshop", "premiere", "afterfx", "blender", "msedgewebview2", "lockapp", "systemsettings", "taskmgr", "notepad"
        };

        readonly FpsCounter _fps = new();
        readonly List<GameSession> _history;
        GameSession? _current;
        int _pid = -1, _candidatePid = -1, _candidateSecs, _goneSecs;
        DateTime _sessionStart;
        readonly List<float> _fpsWindow = new();

        public Func<(string? Game, int Pid)>? BoosterGame;     // jogo detectado pelo modo jogo
        public Func<(float? CpuTemp, float? GpuTemp, float? GpuLoad)>? Sensors;
        public Func<(float Cpu, float Ram)>? Usage;

        public bool FpsEnabled { get; private set; }
        public string FpsError => _fps.Error;
        public int? Fps { get; private set; }
        public string? Game => _current?.Game;
        public GameSession? Current => _current;
        public IReadOnlyList<GameSession> History => _history;
        public event Action? Updated;
        public event Action<GameSession>? SessionEnded;

        static string FilePath => Path.Combine(SuiteSettings.DataDir, "sessoes-de-jogo.json");

        public GameMonitor()
        {
            Instance = this;
            try { _history = File.Exists(FilePath) ? JsonSerializer.Deserialize<List<GameSession>>(File.ReadAllText(FilePath)) ?? new() : new(); }
            catch { _history = new(); }
        }

        public void SetFps(bool on)
        {
            FpsEnabled = on;
            if (on) _fps.Start(); else { _fps.Stop(); Fps = null; }
        }

        [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
        [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr hwnd, out int pid);

        static string NameOf(int pid)
        {
            try { using var p = Process.GetProcessById(pid); return p.ProcessName; } catch { return ""; }
        }

        static bool Alive(int pid)
        {
            try { using var p = Process.GetProcessById(pid); return !p.HasExited; } catch { return false; }
        }

        /// <summary>Chamar uma vez por segundo (thread da interface).</summary>
        public void Tick()
        {
            var counts = FpsEnabled ? _fps.TakeCounts() : new Dictionary<int, int>();
            GetWindowThreadProcessId(GetForegroundWindow(), out int fg);

            // 1) quem é o jogo?
            var booster = BoosterGame?.Invoke() ?? (null, -1);
            if (_current == null)
            {
                int cand = -1;
                if (booster.Pid > 0) cand = booster.Pid;
                else if (fg > 0 && counts.TryGetValue(fg, out int c) && c >= 25 && !NotGames.Contains(NameOf(fg))) cand = fg;

                if (cand > 0 && cand == _candidatePid) _candidateSecs++;
                else { _candidatePid = cand; _candidateSecs = cand > 0 ? 1 : 0; }

                if (_candidatePid > 0 && (_candidateSecs >= 10 || booster.Pid == _candidatePid))
                {
                    _pid = _candidatePid;
                    string name = booster.Pid == _pid && booster.Game != null ? booster.Game : NameOf(_pid);
                    _current = new GameSession { Game = name, Start = DateTime.Now };
                    _sessionStart = DateTime.Now;
                    _fpsWindow.Clear();
                    _goneSecs = 0;
                }
            }

            // 2) gravação
            if (_current != null)
            {
                bool alive = Alive(_pid);
                _goneSecs = alive ? 0 : _goneSecs + 1;
                if (_goneSecs >= 3) { EndSession(); }
                else
                {
                    if (!FpsEnabled) Fps = null;
                    else Fps = counts.TryGetValue(_pid, out int f) ? f : 0;
                    var (ct, gt, gl) = Sensors?.Invoke() ?? (null, null, null);
                    var (cpu, ram) = Usage?.Invoke() ?? (0, 0);
                    int t = (int)(DateTime.Now - _sessionStart).TotalSeconds;
                    if (Fps is int fv && fg == _pid) _fpsWindow.Add(fv);
                    // guarda 1 amostra a cada 2 s (até 4 horas)
                    if (t % 2 == 0 && _current.Samples.Count < 7200)
                        _current.Samples.Add(new GameSample { T = t, Fps = Fps ?? 0, CpuTemp = ct, GpuTemp = gt, Cpu = cpu, Gpu = gl, Ram = ram });
                    _current.Seconds = t;
                }
            }
            else Fps = FpsEnabled && fg > 0 && counts.TryGetValue(fg, out int ff) && ff > 0 ? ff : (int?)null;

            Updated?.Invoke();
        }

        void EndSession()
        {
            var s = _current!;
            _current = null;
            _pid = -1;
            Fps = null;
            if (s.Seconds < 60) return; // ignora sessões muito curtas
            var fps = _fpsWindow.Where(x => x > 0).OrderBy(x => x).ToList();
            if (fps.Count > 0)
            {
                s.AvgFps = fps.Average();
                s.LowFps = fps.Take(Math.Max(1, fps.Count / 100)).Average();
            }
            s.MaxCpuTemp = s.Samples.Max(x => x.CpuTemp ?? 0);
            s.MaxGpuTemp = s.Samples.Max(x => x.GpuTemp ?? 0);
            s.AvgCpu = s.Samples.Count > 0 ? s.Samples.Average(x => x.Cpu) : 0;
            _history.Insert(0, s);
            if (_history.Count > 40) _history.RemoveRange(40, _history.Count - 40);
            Save();
            Activity.Log("Jogos", $"{s.Game}: {s.Summary}");
            SessionEnded?.Invoke(s);
        }

        public void ClearHistory() { _history.Clear(); Save(); Updated?.Invoke(); }

        void Save()
        {
            try
            {
                Directory.CreateDirectory(SuiteSettings.DataDir);
                File.WriteAllText(FilePath, JsonSerializer.Serialize(_history));
            }
            catch { }
        }

        public void Dispose()
        {
            if (_current != null) { _goneSecs = 99; EndSession(); }
            _fps.Dispose();
        }
    }
}

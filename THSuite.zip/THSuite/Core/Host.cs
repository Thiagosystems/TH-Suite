using System;
using System.Windows;
using WF = System.Windows.Forms;

namespace THSuite
{
    /// <summary>
    /// Ponte entre os módulos e a janela principal: bandeja do sistema, avisos e navegação.
    /// </summary>
    public static class Host
    {
        static WF.NotifyIcon? _tray;
        static Action? _balloonAction;

        /// <summary>Janela dona das caixas de diálogo.</summary>
        public static Window Owner => Application.Current.MainWindow;

        /// <summary>A janela principal está aberta (não minimizada para a bandeja).</summary>
        public static bool WindowVisible => Application.Current.MainWindow?.IsVisible == true;

        /// <summary>Navega para um módulo (e uma aba dele). Definido pela janela principal.</summary>
        public static Action<string, string?>? NavigateHandler;
        public static Action? ShowWindowHandler;

        public static void Navigate(string module, string? tab = null) => NavigateHandler?.Invoke(module, tab);
        public static void ShowWindow() => ShowWindowHandler?.Invoke();

        public static void AttachTray(WF.NotifyIcon tray)
        {
            _tray = tray;
            _tray.BalloonTipClicked += (_, _) =>
            {
                var a = _balloonAction;
                _balloonAction = null;
                Application.Current.Dispatcher.Invoke(() => a?.Invoke());
            };
            _tray.BalloonTipClosed += (_, _) => _balloonAction = null;
        }

        /// <summary>Aviso no canto da tela. <paramref name="onClick"/> roda se o usuário clicar no aviso.</summary>
        public static void Notify(string text, Action? onClick = null, string title = "TH Suite", bool warning = false)
        {
            if (_tray == null) return;
            _balloonAction = onClick;
            try { _tray.ShowBalloonTip(4000, title, text, warning ? WF.ToolTipIcon.Warning : WF.ToolTipIcon.Info); } catch { }
        }

        static readonly System.Collections.Generic.SortedDictionary<string, string> _tip = new();

        /// <summary>Cada módulo informa um pedaço do texto da bandeja (ex.: "RAM 54%", "CPU 60 °C").</summary>
        public static void SetTrayPart(string key, string text)
        {
            if (_tray == null) return;
            if (text.Length == 0) _tip.Remove(key); else _tip[key] = text;
            string full = "TH Suite" + (_tip.Count > 0 ? " — " + string.Join(" · ", _tip.Values) : "");
            _tray.Text = full.Length > 63 ? full[..63] : full;
        }

        public static Action? ExitHandler;
        public static void Exit() => ExitHandler?.Invoke();

        /// <summary>Reinicia o TH Suite (a nova instância espera esta fechar).</summary>
        public static void Restart()
        {
            try { System.Diagnostics.Process.Start(Environment.ProcessPath!, "--restart"); } catch { }
            Exit();
        }

        public static void SetTrayIcon(System.Drawing.Icon icon)
        {
            if (_tray == null) return;
            var old = _tray.Icon;
            _tray.Icon = icon;
            if (old != null && !ReferenceEquals(old, DefaultIcon)) old.Dispose();
        }

        static System.Drawing.Icon? _default;
        public static System.Drawing.Icon DefaultIcon
        {
            get
            {
                if (_default != null) return _default;
                using var s = Application.GetResourceStream(new Uri("pack://application:,,,/Assets/app.ico")).Stream;
                _default = new System.Drawing.Icon(s, 32, 32);
                return _default;
            }
        }

        public static void ResetTrayIcon()
        {
            if (_tray == null || ReferenceEquals(_tray.Icon, DefaultIcon)) return;
            SetTrayIcon(DefaultIcon);
        }

        public static bool Confirm(string text, string title = "TH Suite") =>
            MessageBox.Show(Owner, text, title, MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes;

        public static void Info(string text, string title = "TH Suite") =>
            MessageBox.Show(Owner, text, title, MessageBoxButton.OK, MessageBoxImage.Information);
    }
}

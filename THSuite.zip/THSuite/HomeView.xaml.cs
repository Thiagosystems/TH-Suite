using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Management;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace THSuite
{
    public partial class HomeView : UserControl
    {
        readonly MainWindow _main;
        bool _infoLoaded, _quickBusy;
        DateTime _boot = DateTime.MinValue;

        public HomeView(MainWindow main)
        {
            InitializeComponent();
            _main = main;
            BuildActions();
            Loaded += async (_, _) =>
            {
                if (_infoLoaded) return;
                _infoLoaded = true;
                await LoadSystemInfoAsync();
                Refresh();
            };
            _main.OptimizerPage.StatesChanged += () => Dispatcher.InvokeAsync(Refresh);
        }

        // =====================================================================
        //  Atualização
        // =====================================================================

        /// <summary>Chamado pelo mini monitor da janela (a cada 1,5 s) quando o Início está aberto.</summary>
        public void Tick(double cpu, double ram)
        {
            TxtCpu.Text = $"{cpu:0}%";
            PrgCpu.Value = cpu;
            var hw = _main.HardwarePage.LastSummary;
            TxtCpuSub.Text = hw.CpuTemp.HasValue ? $"Temperatura: {_main.HardwarePage.TempText(hw.CpuTemp)}" : "Uso do processador agora";

            var (total, avail, _) = Memory.MemoryCleaner.GetStatus();
            TxtRam.Text = $"{ram:0}%";
            PrgRam.Value = ram;
            TxtRamSub.Text = $"{Gb(total - avail)} de {Gb(total)} em uso";

            if (_boot != DateTime.MinValue)
            {
                var up = DateTime.Now - _boot;
                InfoUptime.Text = up.TotalDays >= 1 ? $"{(int)up.TotalDays} dia(s) e {up.Hours} h" : $"{up.Hours} h {up.Minutes} min";
            }
        }

        static string Gb(ulong bytes) => $"{bytes / 1024d / 1024 / 1024:0.0} GB";

        public void Refresh()
        {
            if (!IsLoaded) return;
            var issues = new List<(string Text, string Module, string? Tab, bool Bad)>();
            int score = 100;

            // Memória
            double ram = _main.MemoryPage.LoadPercent;
            if (ram >= 90) { score -= 15; issues.Add(($"Memória quase cheia ({ram:0}%)", "memory", null, true)); }
            else if (ram >= 80) { score -= 5; issues.Add(($"Memória bem usada ({ram:0}%)", "memory", null, false)); }

            // Disco
            try
            {
                var d = new DriveInfo(System.IO.Path.GetPathRoot(Environment.SystemDirectory)!);
                double freePct = d.AvailableFreeSpace * 100.0 / d.TotalSize;
                double usedPct = 100 - freePct;
                TxtDiskTitle.Text = $"DISCO {d.Name.TrimEnd('\\')}";
                TxtDisk.Text = $"{d.AvailableFreeSpace / 1024d / 1024 / 1024:0} GB livres";
                PrgDisk.Value = usedPct;
                TxtDiskSub.Text = $"{usedPct:0}% usado de {d.TotalSize / 1024d / 1024 / 1024:0} GB";
                if (freePct < 8) { score -= 20; issues.Add(($"Pouco espaço no disco ({freePct:0}% livre)", "cleaner", "clean", true)); }
                else if (freePct < 15) { score -= 8; issues.Add(($"Espaço no disco ficando curto ({freePct:0}% livre)", "cleaner", "clean", false)); }
            }
            catch { }

            // Otimizador
            if (_main.OptimizerPage.StatesLoaded)
            {
                int rec = _main.OptimizerPage.PendingRecommendedCount;
                if (rec > 0)
                {
                    score -= Math.Min(25, rec * 2);
                    issues.Add(($"{rec} ajuste{(rec > 1 ? "s" : "")} recomendado{(rec > 1 ? "s" : "")} do Windows para fazer", "optimizer", "Recomendados", rec > 6));
                }
            }

            // Segurança
            var def = _main.SecurityPage.DefenderInfo;
            int alerts = _main.SecurityPage.OpenAlerts;
            bool otherAv = def.OtherAntivirus.Count > 0;
            if (alerts > 0)
            {
                score -= 25;
                issues.Add(($"{alerts} alerta(s) de segurança de risco alto", "security", "home", true));
                TxtSec.Text = $"{alerts} alerta(s)";
            }
            else if (def.Available && !def.RealTime && !otherAv)
            {
                score -= 25;
                issues.Add(("Proteção em tempo real do antivírus DESLIGADA", "security", "home", true));
                TxtSec.Text = "Desprotegido";
            }
            else TxtSec.Text = otherAv || def.Available ? "Protegido" : "Verificando...";
            TxtSecSub.Text = otherAv ? string.Join(", ", def.OtherAntivirus) : def.Available ? "Microsoft Defender" : "Clique para abrir";
            TxtSec.SetResourceReference(TextBlock.ForegroundProperty, TxtSec.Text == "Protegido" ? "OkSolidBrush" : TxtSec.Text == "Verificando..." ? "TextBrush" : "DangerSolidBrush");

            score = Math.Clamp(score, 0, 100);
            TxtScore.Text = score.ToString();
            DrawArc(score);
            TxtHealthTitle.Text = score >= 90 ? "Seu PC está ótimo" : score >= 70 ? "Seu PC está bem, mas dá para melhorar" : "Seu PC precisa de atenção";

            IssueList.Children.Clear();
            if (issues.Count == 0)
                IssueList.Children.Add(IssueLine("Tudo certo por aqui. Nenhum problema encontrado.", null, null, false, ok: true));
            foreach (var i in issues.OrderByDescending(x => x.Bad).Take(5))
                IssueList.Children.Add(IssueLine(i.Text, i.Module, i.Tab, i.Bad));
        }

        UIElement IssueLine(string text, string? module, string? tab, bool bad, bool ok = false)
        {
            var sp = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 2, 0, 2), Background = Brushes.Transparent };
            var ico = new TextBlock
            {
                Text = ok ? "" : bad ? "" : "",
                FontFamily = new FontFamily("Segoe MDL2 Assets"),
                FontSize = 12,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 8, 0)
            };
            ico.SetResourceReference(TextBlock.ForegroundProperty, ok ? "OkSolidBrush" : bad ? "DangerSolidBrush" : "WarnSolidBrush");
            var t = new TextBlock { Text = text, FontSize = 12.5, VerticalAlignment = VerticalAlignment.Center };
            t.SetResourceReference(TextBlock.ForegroundProperty, "TextBrush");
            sp.Children.Add(ico);
            sp.Children.Add(t);
            if (module != null)
            {
                var link = new TextBlock { Text = "  Resolver →", FontSize = 12, VerticalAlignment = VerticalAlignment.Center, Cursor = Cursors.Hand };
                link.SetResourceReference(TextBlock.ForegroundProperty, "AccentSolidBrush");
                link.MouseLeftButtonUp += (_, _) => Host.Navigate(module, tab);
                sp.Children.Add(link);
            }
            return sp;
        }

        void DrawArc(double pct)
        {
            const double c = 65, r = 59.5;
            double a = Math.Clamp(pct, 0.5, 99.99) * 3.6 * Math.PI / 180.0;
            var end = new Point(c + r * Math.Sin(a), c - r * Math.Cos(a));
            var fig = new PathFigure { StartPoint = new Point(c, c - r), IsClosed = false };
            fig.Segments.Add(new ArcSegment(end, new Size(r, r), 0, pct > 50, SweepDirection.Clockwise, true));
            ScoreArc.Data = new PathGeometry(new[] { fig });
            ScoreArc.SetResourceReference(Shape.StrokeProperty, pct >= 70 ? "AccentBrush" : "DangerBrush");
        }

        // =====================================================================
        //  Informações do sistema
        // =====================================================================

        async Task LoadSystemInfoAsync()
        {
            var info = await Task.Run(() =>
            {
                var d = new Dictionary<string, string>();
                string Q(string cls, string prop)
                {
                    try
                    {
                        using var s = new ManagementObjectSearcher($"SELECT {prop} FROM {cls}");
                        var vals = new List<string>();
                        foreach (ManagementObject o in s.Get()) { vals.Add((o[prop]?.ToString() ?? "").Trim()); o.Dispose(); }
                        return string.Join(" + ", vals.Where(v => v.Length > 0).Distinct());
                    }
                    catch { return ""; }
                }
                string os = Q("Win32_OperatingSystem", "Caption").Replace("Microsoft ", "");
                string ver = Registry.GetValue(@"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows NT\CurrentVersion", "DisplayVersion", "")?.ToString() ?? "";
                string build = Q("Win32_OperatingSystem", "BuildNumber");
                d["os"] = $"{os} {ver} (build {build})".Trim();
                d["cpu"] = Q("Win32_Processor", "Name");
                d["gpu"] = Q("Win32_VideoController", "Name");
                string brd = (Q("Win32_BaseBoard", "Manufacturer") + " " + Q("Win32_BaseBoard", "Product")).Trim();
                d["board"] = brd.Length > 0 ? brd : (Q("Win32_ComputerSystem", "Manufacturer") + " " + Q("Win32_ComputerSystem", "Model")).Trim();
                try
                {
                    double gb = 0;
                    using (var s = new ManagementObjectSearcher("SELECT Capacity FROM Win32_PhysicalMemory"))
                        foreach (ManagementObject o in s.Get()) { gb += Convert.ToDouble(o["Capacity"]) / 1024 / 1024 / 1024; o.Dispose(); }
                    string speed = Q("Win32_PhysicalMemory", "Speed").Split(" + ").FirstOrDefault() ?? "";
                    d["ram"] = $"{gb:0} GB" + (speed.Length > 0 ? $" · {speed} MHz" : "");
                }
                catch { d["ram"] = ""; }
                try
                {
                    using var s = new ManagementObjectSearcher("SELECT LastBootUpTime FROM Win32_OperatingSystem");
                    foreach (ManagementObject o in s.Get()) { d["boot"] = o["LastBootUpTime"]?.ToString() ?? ""; o.Dispose(); }
                }
                catch { }
                return d;
            });

            InfoOs.Text = Val(info, "os");
            InfoCpu.Text = Val(info, "cpu");
            InfoGpu.Text = Val(info, "gpu");
            InfoRam.Text = Val(info, "ram");
            InfoBoard.Text = Val(info, "board");
            InfoOs.ToolTip = InfoOs.Text; InfoCpu.ToolTip = InfoCpu.Text; InfoGpu.ToolTip = InfoGpu.Text; InfoBoard.ToolTip = InfoBoard.Text;
            if (info.TryGetValue("boot", out var b) && b.Length > 0)
            {
                try { _boot = ManagementDateTimeConverter.ToDateTime(b); } catch { }
            }
        }

        static string Val(Dictionary<string, string> d, string k) => d.TryGetValue(k, out var v) && v.Length > 0 ? v : "—";

        // =====================================================================
        //  Ações rápidas
        // =====================================================================

        void BuildActions()
        {
            AddAction("", "Liberar memória", "Limpa a RAM agora", async () =>
            {
                double before = _main.MemoryPage.LoadPercent;
                await _main.MemoryPage.CleanNowAsync();
                await Task.Delay(1200);
                Host.Notify($"Memória: {before:0}% → {_main.MemoryPage.LoadPercent:0}%");
                Refresh();
            });
            AddAction("", "Limpar arquivos inúteis", "Temporários, caches e lixeira", () => { Host.Navigate("cleaner", "clean"); _main.CleanerPage.QuickAnalyze(); return Task.CompletedTask; });
            AddAction("", "Otimizar o Windows", "Ajustes de desempenho", () => { Host.Navigate("optimizer", "Recomendados"); return Task.CompletedTask; });
            AddAction("", "Turbinar jogos", "Ajustes e modo jogo", () => { Host.Navigate("optimizer", Optimizer.Catalog.CatGames); return Task.CompletedTask; });
            AddAction("", "Verificar vírus", "Verificação inteligente", () => { Host.Navigate("security", null); _main.SecurityPage.StartSmartScan(); return Task.CompletedTask; });
            AddAction("", "Melhorar ping", "DNS e internet para jogos", () => { Host.Navigate("hardware", "net"); return Task.CompletedTask; });
            AddAction("", "Desinstalar programas", "Remove até as sobras", () => { Host.Navigate("cleaner", "programs"); return Task.CompletedTask; });
            AddAction("", "Consertar problemas", "Som, internet, Windows Update...", () => { Host.Navigate("repair", null); return Task.CompletedTask; });
        }

        void AddAction(string icon, string title, string desc, Func<Task> run)
        {
            var sp = new StackPanel();
            var ico = new TextBlock { Text = icon, FontFamily = new FontFamily("Segoe MDL2 Assets"), FontSize = 20, Margin = new Thickness(0, 0, 0, 10) };
            ico.SetResourceReference(TextBlock.ForegroundProperty, "AccentSolidBrush");
            var t = new TextBlock { Text = title, FontSize = 13, FontWeight = FontWeights.SemiBold, TextTrimming = TextTrimming.CharacterEllipsis };
            t.SetResourceReference(TextBlock.ForegroundProperty, "TextBrush");
            var d = new TextBlock { Text = desc, FontSize = 11.5, TextTrimming = TextTrimming.CharacterEllipsis, Margin = new Thickness(0, 2, 0, 0) };
            d.SetResourceReference(TextBlock.ForegroundProperty, "MutedBrush");
            sp.Children.Add(ico); sp.Children.Add(t); sp.Children.Add(d);
            var b = new Button { Style = (Style)FindResource("ActionButton"), Content = sp, HorizontalContentAlignment = HorizontalAlignment.Stretch };
            b.Click += async (_, _) =>
            {
                b.IsEnabled = false;
                try { await run(); } catch { }
                b.IsEnabled = true;
            };
            Actions.Children.Add(b);
        }

        void GoMemory(object sender, MouseButtonEventArgs e) => Host.Navigate("memory", "clean");
        void GoCleaner(object sender, MouseButtonEventArgs e) => Host.Navigate("cleaner", "clean");
        void GoSecurity(object sender, MouseButtonEventArgs e) => Host.Navigate("security", "home");

        // =====================================================================
        //  Otimização rápida
        // =====================================================================

        async void QuickOptimize_Click(object sender, RoutedEventArgs e)
        {
            if (_quickBusy) return;
            var s = SuiteSettings.Current;
            if (!Host.Confirm("A otimização rápida vai:\n\n" +
                              (s.RestorePointBeforeTweaks ? "  1. Criar um ponto de restauração\n" : "") +
                              "  • Liberar a memória RAM\n" +
                              "  • Apagar arquivos temporários e caches (os itens marcados em Limpeza)\n" +
                              "  • Aplicar os ajustes SEGUROS recomendados do Otimizador\n" +
                              "  • Limpar o cache de DNS\n\n" +
                              "Nada pessoal é apagado e os ajustes podem ser desfeitos no Otimizador. Continuar?", "Otimização rápida")) return;

            _quickBusy = true;
            BtnQuick.IsEnabled = false;
            TxtQuickLog.Text = "";
            PrgQuick.Value = 0;
            BtnQuickClose.Visibility = Visibility.Collapsed;
            QuickOverlay.Visibility = Visibility.Visible;
            try
            {
                if (s.RestorePointBeforeTweaks)
                {
                    Step("Criando ponto de restauração...");
                    var (ok, m) = await Cmd.CreateRestorePointAsync("TH Suite - otimização rápida");
                    Log(ok ? "  Ponto de restauração criado." : "  " + m);
                }
                PrgQuick.Value = 1;

                Step("Liberando memória RAM...");
                double before = _main.MemoryPage.LoadPercent;
                await _main.MemoryPage.CleanNowAsync();
                await Task.Delay(1000);
                Log($"  Memória em uso: {before:0}% → {_main.MemoryPage.LoadPercent:0}%");
                PrgQuick.Value = 2;

                Step("Apagando arquivos inúteis...");
                long freed = await _main.CleanerPage.QuickCleanAsync(l => Dispatcher.Invoke(() => Log(l)));
                Log($"  Total liberado no disco: {Cleaner.Fmt.Size(freed)}");
                PrgQuick.Value = 3;

                Step("Aplicando ajustes recomendados...");
                int n = await _main.OptimizerPage.ApplyRecommendedAsync(l => Dispatcher.Invoke(() => Log(l)));
                Log(n == 0 ? "  Todos os ajustes recomendados já estavam aplicados." : $"  {n} ajuste(s) aplicado(s).");
                PrgQuick.Value = 4;

                Step("Limpando cache de DNS...");
                await Cmd.RunAsync("ipconfig.exe", "/flushdns");
                PrgQuick.Value = 5;

                TxtQuick.Text = "Pronto! Seu PC foi otimizado.";
                Log("");
                Log("Alguns ajustes só valem depois de reiniciar o PC.");
            }
            catch (Exception ex)
            {
                TxtQuick.Text = "Erro: " + ex.Message;
            }
            BtnQuickClose.Visibility = Visibility.Visible;
            BtnQuick.IsEnabled = true;
            _quickBusy = false;
            Refresh();
        }

        void Step(string text)
        {
            TxtQuick.Text = text;
            Log(text);
        }

        void Log(string text)
        {
            TxtQuickLog.Text += (TxtQuickLog.Text.Length > 0 ? "\n" : "") + text;
            QuickScroll.ScrollToEnd();
        }

        void QuickClose_Click(object sender, RoutedEventArgs e) => QuickOverlay.Visibility = Visibility.Collapsed;
    }
}

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Text;
using System.Windows.Input;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Interop;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using WF = System.Windows.Forms;

namespace THSuite
{
    public partial class MainWindow : Window
    {
        record PageInfo(FrameworkElement View, RadioButton Nav, string Title, string Sub);

        readonly SuiteSettings _s;
        readonly bool _startHidden;
        readonly Dictionary<string, PageInfo> _pages = new();
        readonly DispatcherTimer _sideTimer = new() { Interval = TimeSpan.FromSeconds(1) };
        readonly GameMonitor _games = new();
        int _ticks;
        readonly Memory.SystemStats _cpu = new();

        WF.NotifyIcon _tray = null!;
        WF.ToolStripMenuItem _trayGame = null!;
        string _current = "";
        bool _exiting, _cpuBusy;

        public HomeView HomePage { get; }
        public Optimizer.OptimizerView OptimizerPage { get; }
        public Memory.MemoryView MemoryPage { get; }
        public Cleaner.CleanerView CleanerPage { get; }
        public Hardware.HardwareView HardwarePage { get; }
        public Security.SecurityView SecurityPage { get; }
        public Repair.RepairView RepairPage { get; }
        public SettingsView SettingsPage { get; }
        public Apps.AppsView AppsPage { get; }
        public HistoryView HistoryPage { get; }

        public static string Version => typeof(MainWindow).Assembly.GetName().Version?.ToString(3) ?? "1.0.0";

        public MainWindow(SuiteSettings settings, bool startHidden)
        {
            InitializeComponent();
            _s = settings;
            _startHidden = startHidden;
            Icon = System.Windows.Media.Imaging.BitmapFrame.Create(new Uri("pack://application:,,,/Assets/app.ico"));
            Width = Math.Max(MinWidth, _s.WindowWidth);
            Height = Math.Max(MinHeight, _s.WindowHeight);
            TxtVersion.Text = "TH Suite v" + Version;
            if (startHidden)
            {
                // Abre escondido (iniciar com o Windows): carrega os módulos sem mostrar a janela
                ShowInTaskbar = false;
                WindowState = WindowState.Minimized;
            }

            SetupTray();

            // Os módulos são criados juntos: monitor de RAM, ventoinhas e mineração rodam em segundo plano
            MemoryPage = new Memory.MemoryView();
            CleanerPage = new Cleaner.CleanerView();
            HardwarePage = new Hardware.HardwareView();
            SecurityPage = new Security.SecurityView();
            OptimizerPage = new Optimizer.OptimizerView();
            RepairPage = new Repair.RepairView();
            AppsPage = new Apps.AppsView();
            HistoryPage = new HistoryView();
            HomePage = new HomeView(this);
            SettingsPage = new SettingsView(this);

            RepairPage.CleanMemory = async () =>
            {
                double before = MemoryPage.LoadPercent;
                await MemoryPage.CleanNowAsync();
                await Task.Delay(1200);
                return $"Memória em uso: {before:0}% → {MemoryPage.LoadPercent:0}%";
            };

            Add("home", HomePage, NavHome, "Início", "Resumo do seu PC e atalhos rápidos");
            Add("optimizer", OptimizerPage, NavOptimizer, "Otimizador", "Ajustes do Windows para desempenho, jogos e privacidade");
            Add("memory", MemoryPage, NavMemory, "Memória RAM", "Limpeza de memória, modo jogo e widget");
            Add("cleaner", CleanerPage, NavCleaner, "Limpeza e desinstalação", "Arquivos inúteis, arquivos grandes e desinstalador completo");
            Add("apps", AppsPage, NavApps, "Programas e drivers", "Atualize, instale programas e confira os drivers");
            Add("hardware", HardwarePage, NavHardware, "Hardware e internet", "Temperaturas, ventoinhas, energia e internet para jogos");
            Add("security", SecurityPage, NavSecurity, "Segurança", "Vírus, programas suspeitos e mineradores escondidos");
            Add("repair", RepairPage, NavRepair, "Reparos e ferramentas", "Conserte problemas comuns do Windows com um clique");
            Add("history", HistoryPage, NavHistory, "Histórico", "Tudo o que o TH Suite fez no seu PC");
            Add("settings", SettingsPage, NavSettings, "Configurações", "Aparência e comportamento do TH Suite");

            // Gravador de sessões de jogo (FPS, temperaturas)
            _games.BoosterGame = () => MemoryPage.ActiveGame;
            _games.Sensors = () => { var h = HardwarePage.LastSummary; return (h.CpuTemp, h.GpuTemp, h.GpuLoad); };
            _games.Usage = () => ((float)_cpu.Cpu, (float)MemoryPage.LoadPercent);
            _games.SetFps(_s.FpsCounter);

            TxtSearch.TextChanged += (_, _) => RunSearch();
            TxtSearch.GotKeyboardFocus += (_, _) => { if (TxtSearch.Text.Length > 0) RunSearch(); };
            TxtSearch.PreviewKeyDown += Search_KeyDown;
            LstSearch.PreviewMouseLeftButtonUp += (_, _) => { if (LstSearch.SelectedItem is SearchItem it) Go(it); };
            LstSearch.PreviewKeyDown += (_, e) => { if (e.Key == Key.Enter && LstSearch.SelectedItem is SearchItem it) { Go(it); e.Handled = true; } };
            PreviewKeyDown += (_, e) =>
            {
                if (e.Key == Key.F && Keyboard.Modifiers == ModifierKeys.Control) { TxtSearch.Focus(); TxtSearch.SelectAll(); e.Handled = true; }
            };

            Host.NavigateHandler = Navigate;
            Host.ShowWindowHandler = ShowFromTray;
            Host.ExitHandler = ExitApp;

            SourceInitialized += (_, _) => HwndSource.FromHwnd(new WindowInteropHelper(this).Handle)?.AddHook(WndProc);
            StateChanged += (_, _) =>
            {
                BtnMax.Content = WindowState == WindowState.Maximized ? "\uE923" : "\uE922";
                FixMaximizedMargin();
                Dispatcher.BeginInvoke(new Action(FixMaximizedMargin), DispatcherPriority.Loaded);
            };
            SizeChanged += (_, _) => { if (WindowState == WindowState.Maximized) FixMaximizedMargin(); };
            Loaded += (_, _) =>
            {
                if (!_startHidden) return;
                Hide();
                ShowInTaskbar = true;
                WindowState = WindowState.Normal;
            };

            _sideTimer.Tick += async (_, _) => await SideTickAsync();
            _sideTimer.Start();

            Navigate(_pages.ContainsKey(_s.LastPage) ? _s.LastPage : "home", null);
        }

        void Add(string id, FrameworkElement view, RadioButton nav, string title, string sub)
        {
            view.Visibility = Visibility.Collapsed;
            PageHost.Children.Add(view);
            nav.DataContext = id;
            _pages[id] = new PageInfo(view, nav, title, sub);
        }

        // =====================================================================
        //  Navegação
        // =====================================================================

        public void Navigate(string id, string? tab)
        {
            if (!_pages.TryGetValue(id, out var page)) return;
            if (_current != id)
            {
                foreach (var p in _pages.Values) p.View.Visibility = p == page ? Visibility.Visible : Visibility.Collapsed;
                _current = id;
                if (page.Nav.IsChecked != true) page.Nav.IsChecked = true;
                TxtPageTitle.Text = Lang.T(page.Title);
                TxtPageSub.Text = Lang.T(page.Sub);
                _s.LastPage = id;
                if (id == "home") HomePage.Refresh();
            }
            if (tab != null)
            {
                switch (page.View)
                {
                    case Memory.MemoryView m: m.ShowTab(tab); break;
                    case Cleaner.CleanerView c: c.ShowTab(tab); break;
                    case Hardware.HardwareView h: h.ShowTab(tab); break;
                    case Security.SecurityView s: s.ShowTab(tab); break;
                    case Optimizer.OptimizerView o: o.ShowTab(tab); break;
                    case Repair.RepairView r: r.ShowTab(tab); break;
                    case Apps.AppsView a: a.ShowTab(tab); break;
                }
            }
        }

        void Nav_Checked(object sender, RoutedEventArgs e)
        {
            if (sender is RadioButton { DataContext: string id }) Navigate(id, null);
        }

        // =====================================================================
        //  Mini monitor do menu lateral
        // =====================================================================

        async Task SideTickAsync()
        {
            if (_cpuBusy) return;
            _cpuBusy = true;
            _ticks++;
            try
            {
                await Task.Run(() => _cpu.Update(false));
                _games.Tick();
                if (_ticks % 600 == 120) _ = RunScheduledAsync();
                if (_ticks == 90 && _s.CheckUpdates) _ = SettingsPage.CheckUpdateAsync(true);
                if (!IsVisible) { _cpuBusy = false; return; }
                double ram = MemoryPage.LoadPercent;
                TxtSideCpu.Text = $"{_cpu.Cpu:0}%";
                PrgSideCpu.Value = _cpu.Cpu;
                TxtSideRam.Text = $"{ram:0}%";
                PrgSideRam.Value = ram;
                var hw = HardwarePage.LastSummary;
                TxtSideTemp.Text = hw.CpuTemp.HasValue || hw.GpuTemp.HasValue
                    ? $"CPU {HardwarePage.TempText(hw.CpuTemp)} · GPU {HardwarePage.TempText(hw.GpuTemp)}"
                    : "";
                if (_current == "home") HomePage.Tick(_cpu.Cpu, ram);
            }
            catch { }
            _cpuBusy = false;
        }

        // =====================================================================
        //  Tarefas automáticas
        // =====================================================================

        bool _schedBusy;

        async Task RunScheduledAsync()
        {
            var now = DateTime.Now;
            if (_schedBusy || _games.Game != null) return; // não atrapalha quem está jogando
            _schedBusy = true;
            try { await RunScheduledCoreAsync(now); } catch { }
            _schedBusy = false;
        }

        async Task RunScheduledCoreAsync(DateTime now)
        {
            if (_s.AutoCleanDays > 0 && (now - _s.LastAutoClean).TotalDays >= _s.AutoCleanDays)
            {
                _s.LastAutoClean = now;
                _s.Save();
                long freed = await CleanerPage.QuickCleanAsync();
                if (_s.AutoCleanRam) await MemoryPage.CleanNowAsync();
                Activity.Log("Automático", $"Limpeza automática: {Cleaner.Fmt.Size(freed)} liberados");
                Host.Notify(Lang.T("Limpeza automática concluída") + $": {Cleaner.Fmt.Size(freed)}");
            }
            if (_s.AutoScanDays > 0 && (now - _s.LastAutoScan).TotalDays >= _s.AutoScanDays)
            {
                _s.LastAutoScan = now;
                _s.Save();
                Activity.Log("Automático", "Verificação de vírus automática iniciada");
                SecurityPage.StartSmartScan();
            }
        }

        // =====================================================================
        //  Busca global
        // =====================================================================

        public record SearchItem(string Title, string Sub, string Keys, Action Run);

        List<SearchItem>? _index;

        static string Norm(string s)
        {
            var d = s.ToLowerInvariant().Normalize(NormalizationForm.FormD);
            var sb = new StringBuilder(d.Length);
            foreach (char c in d)
                if (CharUnicodeInfo.GetUnicodeCategory(c) != UnicodeCategory.NonSpacingMark) sb.Append(c);
            return sb.ToString();
        }

        List<SearchItem> BuildIndex()
        {
            var l = new List<SearchItem>();
            void P(string title, string sub, string module, string? tab, string keys = "") =>
                l.Add(new SearchItem(Lang.T(title), Lang.T(sub), keys, () => Navigate(module, tab)));

            P("Início", "Saúde do PC e otimização rápida", "home", null, "inicio painel nota rapida");
            P("Otimizador", "Ajustes do Windows", "optimizer", null, "tweaks otimizar desempenho");
            P("Remover apps inúteis", "Otimizador", "optimizer", "debloat", "debloat bloatware apps candy crush");
            P("Programas na inicialização", "Segurança", "security", "startup", "startup iniciar com o windows boot lento");
            P("Liberar memória RAM", "Memória RAM", "memory", "clean", "ram limpar memoria");
            P("Modo jogo", "Memória RAM", "memory", "game", "jogo game booster prioridade");
            P("Widget na tela e atalho", "Memória RAM", "memory", "widget", "overlay fps hotkey");
            P("Limpeza de disco", "Limpeza", "cleaner", "clean", "temporarios cache lixo espaco");
            P("Arquivos grandes", "Limpeza", "cleaner", "large", "espaco disco cheio");
            P("Desinstalar programas", "Limpeza", "cleaner", "programs", "desinstalar remover sobras");
            P("Apps da Store", "Limpeza", "cleaner", "store", "microsoft store desinstalar");
            P("Atualizar programas", "Programas e drivers", "apps", "update", "winget update atualizar");
            P("Instalar programas", "Programas e drivers", "apps", "install", "winget ninite instalar chrome discord steam");
            P("Drivers", "Programas e drivers", "apps", "drivers", "driver placa de video nvidia amd intel");
            P("Painel de hardware", "Hardware", "hardware", "dash", "temperatura cpu gpu");
            P("Todos os sensores", "Hardware", "hardware", "sensors", "sensores voltagem clock");
            P("Ventoinhas e energia", "Hardware", "hardware", "fans", "fan cooler perfil energia");
            P("Internet para jogos", "Hardware", "hardware", "net", "dns ping nagle qos lag");
            P("Teste de velocidade", "Hardware", "hardware", "speed", "speedtest velocidade internet download upload");
            P("Jogos e FPS", "Hardware", "hardware", "games", "fps sessao jogo temperatura");
            P("Saúde dos discos", "Hardware", "hardware", "disks", "ssd hd smart desgaste");
            P("Verificar vírus", "Segurança", "security", "scan", "virus antivirus defender malware");
            P("Processos e mineração", "Segurança", "security", "proc", "minerador mineracao cpu processo");
            P("Bloqueio de sites", "Segurança", "security", "blocker", "hosts propaganda anuncios golpes adblock");
            P("Firewall por app", "Segurança", "security", "firewall", "bloquear internet programa");
            P("Quarentena", "Segurança", "security", "quar", "quarentena restaurar");
            P("Ferramentas rápidas", "Reparos", "repair", "tools", "bios reiniciar explorer restauracao");
            P("Histórico", "Tudo o que o TH Suite fez", "history", null, "historico log");
            P("Configurações", "Tema, cores, idioma, atualizações", "settings", null, "tema cor logo idioma language atualizar");

            foreach (var t in OptimizerPage.Tweaks)
            {
                var tw = t;
                l.Add(new SearchItem(tw.Title, Lang.T("Otimizador") + " · " + Lang.T(tw.Category), tw.Description + " " + tw.Details,
                    () => { Navigate("optimizer", null); OptimizerPage.ShowTweak(tw.Id); }));
            }
            foreach (var f in RepairPage.AllFixes)
            {
                var fx = f;
                l.Add(new SearchItem(fx.Title, Lang.T("Reparo") + " · " + Lang.T(fx.Group), fx.Problem, () => Navigate("repair", fx.Id)));
            }
            foreach (var a in AppsPage.Catalog)
                l.Add(new SearchItem(a.Name, Lang.T("Instalar programa") + " · " + Lang.T(a.Category), a.Description, () => Navigate("apps", "install")));
            return l;
        }

        void RunSearch()
        {
            string q = Norm(TxtSearch.Text.Trim());
            if (q.Length < 2) { SearchPopup.IsOpen = false; return; }
            _index ??= BuildIndex();
            var words = q.Split(' ', StringSplitOptions.RemoveEmptyEntries);
            var results = _index
                .Select(i => (Item: i, T: Norm(i.Title), A: Norm(i.Sub + " " + i.Keys)))
                .Where(x => words.All(w => x.T.Contains(w) || x.A.Contains(w)))
                .OrderByDescending(x => words.Count(w => x.T.Contains(w)))
                .ThenByDescending(x => x.T.StartsWith(words[0]))
                .Take(30).Select(x => x.Item).ToList();
            LstSearch.ItemsSource = results;
            TxtSearchEmpty.Visibility = results.Count == 0 ? Visibility.Visible : Visibility.Collapsed;
            SearchPopup.IsOpen = true;
        }

        void Search_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape) { SearchPopup.IsOpen = false; TxtSearch.Clear(); Keyboard.ClearFocus(); e.Handled = true; }
            else if (e.Key == Key.Down && SearchPopup.IsOpen && LstSearch.Items.Count > 0)
            {
                LstSearch.SelectedIndex = 0;
                (LstSearch.ItemContainerGenerator.ContainerFromIndex(0) as ListBoxItem)?.Focus();
                e.Handled = true;
            }
            else if (e.Key == Key.Enter && LstSearch.Items.Count > 0 && LstSearch.Items[0] is SearchItem first) { Go(first); e.Handled = true; }
        }

        void Go(SearchItem it)
        {
            SearchPopup.IsOpen = false;
            TxtSearch.Clear();
            Keyboard.ClearFocus();
            it.Run();
        }

        // =====================================================================
        //  Bandeja
        // =====================================================================

        void SetupTray()
        {
            var menu = new WF.ContextMenuStrip();
            menu.Items.Add(Lang.T("Abrir TH Suite"), null, (_, _) => ShowFromTray());
            menu.Items.Add(new WF.ToolStripSeparator());
            menu.Items.Add(Lang.T("Limpar memória RAM"), null, async (_, _) => await MemoryPage.CleanNowAsync());
            _trayGame = new WF.ToolStripMenuItem(Lang.T("Modo jogo")) { CheckOnClick = true };
            _trayGame.Click += (_, _) => MemoryPage.GameModeOn = _trayGame.Checked;
            menu.Items.Add(_trayGame);

            var fans = new WF.ToolStripMenuItem(Lang.T("Perfil de ventoinha e energia"));
            foreach (var p in Hardware.FanAndPower.Profiles)
            {
                var id = p.Id;
                fans.DropDownItems.Add(p.Name, null, (_, _) => Dispatcher.Invoke(() => HardwarePage.SelectProfile(id)));
            }
            fans.DropDownItems.Add(Lang.T("Padrão do sistema"), null, (_, _) => Dispatcher.Invoke(() => HardwarePage.SelectProfile("none")));
            menu.Items.Add(fans);

            menu.Items.Add(Lang.T("Verificação de vírus inteligente"), null, (_, _) =>
            {
                ShowFromTray();
                Navigate("security", null);
                SecurityPage.StartSmartScan();
            });
            menu.Items.Add(new WF.ToolStripSeparator());
            menu.Items.Add(Lang.T("Sair"), null, (_, _) => ExitApp());
            menu.Opening += (_, _) => _trayGame.Checked = MemoryPage.GameModeOn;

            _tray = new WF.NotifyIcon { Icon = Host.DefaultIcon, Visible = true, Text = "TH Suite", ContextMenuStrip = menu };
            _tray.DoubleClick += (_, _) => ShowFromTray();
            Host.AttachTray(_tray);
        }

        public void ShowFromTray()
        {
            Show();
            if (WindowState == WindowState.Minimized) WindowState = WindowState.Normal;
            Activate();
            Topmost = true;
            Topmost = false;
        }

        void HideToTray()
        {
            Hide();
            if (!_s.TrayHintShown)
            {
                _s.TrayHintShown = true;
                _s.Save();
                Host.Notify("O TH Suite continua na bandeja (perto do relógio) cuidando da memória, das ventoinhas e da segurança. Clique com o botão direito no ícone para sair.");
            }
        }

        public void ExitApp()
        {
            if (_exiting) return;
            _exiting = true;
            _sideTimer.Stop();
            if (WindowState == WindowState.Normal)
            {
                _s.WindowWidth = Width;
                _s.WindowHeight = Height;
            }
            _s.Save();
            foreach (var shutdown in new Action[] { MemoryPage.Shutdown, CleanerPage.Shutdown, HardwarePage.Shutdown, SecurityPage.Shutdown, RepairPage.Shutdown })
            {
                try { shutdown(); } catch { }
            }
            try { _games.Dispose(); } catch { }
            _tray.Visible = false;
            _tray.Dispose();
            Application.Current.Shutdown();
        }


        // =====================================================================
        //  Tela cheia: respeita a barra de tarefas e não corta as bordas
        // =====================================================================

        [StructLayout(LayoutKind.Sequential)] struct POINT { public int X, Y; }
        [StructLayout(LayoutKind.Sequential)] struct RECT { public int Left, Top, Right, Bottom; }
        [StructLayout(LayoutKind.Sequential)] struct MINMAXINFO { public POINT ptReserved, ptMaxSize, ptMaxPosition, ptMinTrackSize, ptMaxTrackSize; }
        [StructLayout(LayoutKind.Sequential)] struct MONITORINFO { public int cbSize; public RECT rcMonitor, rcWork; public int dwFlags; }

        [DllImport("user32.dll")] static extern IntPtr MonitorFromWindow(IntPtr hwnd, int flags);
        [DllImport("user32.dll")] static extern bool GetMonitorInfo(IntPtr hMonitor, ref MONITORINFO info);
        [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr hwnd, out RECT rect);

        static bool WorkArea(IntPtr hwnd, out MONITORINFO mi)
        {
            mi = new MONITORINFO { cbSize = Marshal.SizeOf<MONITORINFO>() };
            IntPtr mon = MonitorFromWindow(hwnd, 2); // MONITOR_DEFAULTTONEAREST
            return mon != IntPtr.Zero && GetMonitorInfo(mon, ref mi);
        }

        IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
        {
            if (msg == 0x0024 && WorkArea(hwnd, out var mi)) // WM_GETMINMAXINFO
            {
                var mmi = Marshal.PtrToStructure<MINMAXINFO>(lParam);
                mmi.ptMaxPosition.X = mi.rcWork.Left - mi.rcMonitor.Left;
                mmi.ptMaxPosition.Y = mi.rcWork.Top - mi.rcMonitor.Top;
                mmi.ptMaxSize.X = mi.rcWork.Right - mi.rcWork.Left;
                mmi.ptMaxSize.Y = mi.rcWork.Bottom - mi.rcWork.Top;
                Marshal.StructureToPtr(mmi, lParam, true);
            }
            return IntPtr.Zero;
        }

        /// <summary>Se a janela maximizada passar da área útil da tela, compensa com margem.</summary>
        void FixMaximizedMargin()
        {
            if (WindowState != WindowState.Maximized) { Root.Margin = new Thickness(0); return; }
            var hwnd = new WindowInteropHelper(this).Handle;
            if (hwnd == IntPtr.Zero || !GetWindowRect(hwnd, out var r) || !WorkArea(hwnd, out var mi)) { Root.Margin = new Thickness(7); return; }
            var m = PresentationSource.FromVisual(this)?.CompositionTarget?.TransformFromDevice ?? System.Windows.Media.Matrix.Identity;
            Root.Margin = new Thickness(
                Math.Max(0, mi.rcWork.Left - r.Left) * m.M11,
                Math.Max(0, mi.rcWork.Top - r.Top) * m.M22,
                Math.Max(0, r.Right - mi.rcWork.Right) * m.M11,
                Math.Max(0, r.Bottom - mi.rcWork.Bottom) * m.M22);
        }

        // =====================================================================
        //  Janela
        // =====================================================================

        void Min_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
        void Max_Click(object sender, RoutedEventArgs e) =>
            WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
        void Close_Click(object sender, RoutedEventArgs e) => Close();

        protected override void OnClosing(CancelEventArgs e)
        {
            if (!_exiting)
            {
                e.Cancel = true;
                if (WindowState == WindowState.Normal) { _s.WindowWidth = Width; _s.WindowHeight = Height; _s.Save(); }
                if (_s.CloseToTray) HideToTray(); else ExitApp();
            }
            base.OnClosing(e);
        }
    }
}

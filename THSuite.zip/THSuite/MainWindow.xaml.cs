using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using WF = System.Windows.Forms;

namespace THSuite
{
    public partial class MainWindow : Window
    {
        record PageInfo(FrameworkElement View, RadioButton Nav, string Title, string Sub);

        readonly SuiteSettings _s;
        readonly bool _startHidden;
        readonly Dictionary<string, PageInfo> _pages = new();
        readonly DispatcherTimer _sideTimer = new() { Interval = TimeSpan.FromSeconds(1.5) };
        readonly Memory.SystemStats _cpu = new();

        WF.NotifyIcon _tray = null!;
        WF.ToolStripMenuItem _trayGame = null!;
        string _current = "";
        bool _exiting, _cpuBusy;

        public HomeView HomePage { get; }
        public Optimizer.OptimizerView OptimizerPage { get; }
        public Memory.MemoryView MemoryPage { get; }
        public Cleaner.CleanerView CleanerPage { get; }
        public Hardware.HardwareView HardwarePage { get; }
        public Security.SecurityView SecurityPage { get; }
        public Repair.RepairView RepairPage { get; }
        public SettingsView SettingsPage { get; }

        public static string Version => typeof(MainWindow).Assembly.GetName().Version?.ToString(3) ?? "1.0.0";

        public MainWindow(SuiteSettings settings, bool startHidden)
        {
            InitializeComponent();
            _s = settings;
            _startHidden = startHidden;
            Icon = System.Windows.Media.Imaging.BitmapFrame.Create(new Uri("pack://application:,,,/Assets/app.ico"));
            Width = Math.Max(MinWidth, _s.WindowWidth);
            Height = Math.Max(MinHeight, _s.WindowHeight);
            TxtVersion.Text = "TH Suite v" + Version;
            if (startHidden)
            {
                // Abre escondido (iniciar com o Windows): carrega os módulos sem mostrar a janela
                ShowInTaskbar = false;
                WindowState = WindowState.Minimized;
            }

            SetupTray();

            // Os módulos são criados juntos: monitor de RAM, ventoinhas e mineração rodam em segundo plano
            MemoryPage = new Memory.MemoryView();
            CleanerPage = new Cleaner.CleanerView();
            HardwarePage = new Hardware.HardwareView();
            SecurityPage = new Security.SecurityView();
            OptimizerPage = new Optimizer.OptimizerView();
            RepairPage = new Repair.RepairView();
            HomePage = new HomeView(this);
            SettingsPage = new SettingsView(this);

            RepairPage.CleanMemory = async () =>
            {
                double before = MemoryPage.LoadPercent;
                await MemoryPage.CleanNowAsync();
                await Task.Delay(1200);
                return $"Memória em uso: {before:0}% → {MemoryPage.LoadPercent:0}%";
            };

            Add("home", HomePage, NavHome, "Início", "Resumo do seu PC e atalhos rápidos");
            Add("optimizer", OptimizerPage, NavOptimizer, "Otimizador", "Ajustes do Windows para desempenho, jogos e privacidade");
            Add("memory", MemoryPage, NavMemory, "Memória RAM", "Limpeza de memória, modo jogo e widget");
            Add("cleaner", CleanerPage, NavCleaner, "Limpeza e desinstalação", "Arquivos inúteis, arquivos grandes e desinstalador completo");
            Add("hardware", HardwarePage, NavHardware, "Hardware e internet", "Temperaturas, ventoinhas, energia e internet para jogos");
            Add("security", SecurityPage, NavSecurity, "Segurança", "Vírus, programas suspeitos e mineradores escondidos");
            Add("repair", RepairPage, NavRepair, "Reparos e ferramentas", "Conserte problemas comuns do Windows com um clique");
            Add("settings", SettingsPage, NavSettings, "Configurações", "Aparência e comportamento do TH Suite");

            Host.NavigateHandler = Navigate;
            Host.ShowWindowHandler = ShowFromTray;
            Host.ExitHandler = ExitApp;

            StateChanged += (_, _) =>
            {
                Root.Margin = WindowState == WindowState.Maximized ? new Thickness(7) : new Thickness(0);
                BtnMax.Content = WindowState == WindowState.Maximized ? "" : "";
            };
            Loaded += (_, _) =>
            {
                if (!_startHidden) return;
                Hide();
                ShowInTaskbar = true;
                WindowState = WindowState.Normal;
            };

            _sideTimer.Tick += async (_, _) => await SideTickAsync();
            _sideTimer.Start();

            Navigate(_pages.ContainsKey(_s.LastPage) ? _s.LastPage : "home", null);
        }

        void Add(string id, FrameworkElement view, RadioButton nav, string title, string sub)
        {
            view.Visibility = Visibility.Collapsed;
            PageHost.Children.Add(view);
            nav.DataContext = id;
            _pages[id] = new PageInfo(view, nav, title, sub);
        }

        // =====================================================================
        //  Navegação
        // =====================================================================

        public void Navigate(string id, string? tab)
        {
            if (!_pages.TryGetValue(id, out var page)) return;
            if (_current != id)
            {
                foreach (var p in _pages.Values) p.View.Visibility = p == page ? Visibility.Visible : Visibility.Collapsed;
                _current = id;
                if (page.Nav.IsChecked != true) page.Nav.IsChecked = true;
                TxtPageTitle.Text = page.Title;
                TxtPageSub.Text = page.Sub;
                _s.LastPage = id;
                if (id == "home") HomePage.Refresh();
            }
            if (tab != null)
            {
                switch (page.View)
                {
                    case Memory.MemoryView m: m.ShowTab(tab); break;
                    case Cleaner.CleanerView c: c.ShowTab(tab); break;
                    case Hardware.HardwareView h: h.ShowTab(tab); break;
                    case Security.SecurityView s: s.ShowTab(tab); break;
                    case Optimizer.OptimizerView o: o.ShowTab(tab); break;
                    case Repair.RepairView r: r.ShowTab(tab); break;
                }
            }
        }

        void Nav_Checked(object sender, RoutedEventArgs e)
        {
            if (sender is RadioButton { DataContext: string id }) Navigate(id, null);
        }

        // =====================================================================
        //  Mini monitor do menu lateral
        // =====================================================================

        async Task SideTickAsync()
        {
            if (_cpuBusy || !IsVisible) return;
            _cpuBusy = true;
            try
            {
                await Task.Run(() => _cpu.Update(false));
                double ram = MemoryPage.LoadPercent;
                TxtSideCpu.Text = $"{_cpu.Cpu:0}%";
                PrgSideCpu.Value = _cpu.Cpu;
                TxtSideRam.Text = $"{ram:0}%";
                PrgSideRam.Value = ram;
                var hw = HardwarePage.LastSummary;
                TxtSideTemp.Text = hw.CpuTemp.HasValue || hw.GpuTemp.HasValue
                    ? $"CPU {HardwarePage.TempText(hw.CpuTemp)} · GPU {HardwarePage.TempText(hw.GpuTemp)}"
                    : "";
                if (_current == "home") HomePage.Tick(_cpu.Cpu, ram);
            }
            catch { }
            _cpuBusy = false;
        }

        // =====================================================================
        //  Bandeja
        // =====================================================================

        void SetupTray()
        {
            var menu = new WF.ContextMenuStrip();
            menu.Items.Add("Abrir TH Suite", null, (_, _) => ShowFromTray());
            menu.Items.Add(new WF.ToolStripSeparator());
            menu.Items.Add("Limpar memória RAM", null, async (_, _) => await MemoryPage.CleanNowAsync());
            _trayGame = new WF.ToolStripMenuItem("Modo jogo") { CheckOnClick = true };
            _trayGame.Click += (_, _) => MemoryPage.GameModeOn = _trayGame.Checked;
            menu.Items.Add(_trayGame);

            var fans = new WF.ToolStripMenuItem("Perfil de ventoinha e energia");
            foreach (var p in Hardware.FanAndPower.Profiles)
            {
                var id = p.Id;
                fans.DropDownItems.Add(p.Name, null, (_, _) => Dispatcher.Invoke(() => HardwarePage.SelectProfile(id)));
            }
            fans.DropDownItems.Add("Padrão do sistema", null, (_, _) => Dispatcher.Invoke(() => HardwarePage.SelectProfile("none")));
            menu.Items.Add(fans);

            menu.Items.Add("Verificação de vírus inteligente", null, (_, _) =>
            {
                ShowFromTray();
                Navigate("security", null);
                SecurityPage.StartSmartScan();
            });
            menu.Items.Add(new WF.ToolStripSeparator());
            menu.Items.Add("Sair", null, (_, _) => ExitApp());
            menu.Opening += (_, _) => _trayGame.Checked = MemoryPage.GameModeOn;

            _tray = new WF.NotifyIcon { Icon = Host.DefaultIcon, Visible = true, Text = "TH Suite", ContextMenuStrip = menu };
            _tray.DoubleClick += (_, _) => ShowFromTray();
            Host.AttachTray(_tray);
        }

        public void ShowFromTray()
        {
            Show();
            if (WindowState == WindowState.Minimized) WindowState = WindowState.Normal;
            Activate();
            Topmost = true;
            Topmost = false;
        }

        void HideToTray()
        {
            Hide();
            if (!_s.TrayHintShown)
            {
                _s.TrayHintShown = true;
                _s.Save();
                Host.Notify("O TH Suite continua na bandeja (perto do relógio) cuidando da memória, das ventoinhas e da segurança. Clique com o botão direito no ícone para sair.");
            }
        }

        public void ExitApp()
        {
            if (_exiting) return;
            _exiting = true;
            _sideTimer.Stop();
            if (WindowState == WindowState.Normal)
            {
                _s.WindowWidth = Width;
                _s.WindowHeight = Height;
            }
            _s.Save();
            foreach (var shutdown in new Action[] { MemoryPage.Shutdown, CleanerPage.Shutdown, HardwarePage.Shutdown, SecurityPage.Shutdown, RepairPage.Shutdown })
            {
                try { shutdown(); } catch { }
            }
            _tray.Visible = false;
            _tray.Dispose();
            Application.Current.Shutdown();
        }

        // =====================================================================
        //  Janela
        // =====================================================================

        void Min_Click(object sender, RoutedEventArgs e) => WindowState = WindowState.Minimized;
        void Max_Click(object sender, RoutedEventArgs e) =>
            WindowState = WindowState == WindowState.Maximized ? WindowState.Normal : WindowState.Maximized;
        void Close_Click(object sender, RoutedEventArgs e) => Close();

        protected override void OnClosing(CancelEventArgs e)
        {
            if (!_exiting)
            {
                e.Cancel = true;
                if (WindowState == WindowState.Normal) { _s.WindowWidth = Width; _s.WindowHeight = Height; _s.Save(); }
                if (_s.CloseToTray) HideToTray(); else ExitApp();
            }
            base.OnClosing(e);
        }
    }
}

using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;

namespace THSuite
{
    public partial class HistoryView : UserControl
    {
        string _mod = "Todos";
        bool _dirty = true;

        public HistoryView()
        {
            InitializeComponent();
            Activity.Changed += () => { _dirty = true; if (IsVisible) Reload(); };
            IsVisibleChanged += (_, _) => { if (IsVisible && _dirty) Reload(); };
            TxtFilter.TextChanged += (_, _) => Reload();
        }

        void Reload()
        {
            _dirty = false;
            var all = Activity.Items;
            var mods = new[] { "Todos" }.Concat(all.Select(a => a.Module).Distinct().OrderBy(x => x)).ToList();
            if (!mods.Contains(_mod)) _mod = "Todos";
            ModPills.Children.Clear();
            foreach (var m in mods)
            {
                var rb = new RadioButton { Style = (Style)FindResource("Pill"), GroupName = "histMod", Content = m, Tag = m, IsChecked = m == _mod, Margin = new Thickness(0, 0, 6, 6) };
                rb.Checked += (_, _) => { _mod = (string)rb.Tag; Reload(); };
                ModPills.Children.Add(rb);
            }
            string q = TxtFilter.Text.Trim();
            var list = all.Where(a => (_mod == "Todos" || a.Module == _mod)
                                      && (q.Length == 0 || a.Text.Contains(q, StringComparison.CurrentCultureIgnoreCase))).ToList();
            LstHist.ItemsSource = list;
            TxtHistSub.Text = all.Count == 0 ? "Nada registrado ainda. Limpezas, ajustes, reparos, verificações e instalações aparecem aqui."
                                             : $"{all.Count} registro(s) desde {all[^1].Time:dd/MM/yyyy}.";
        }

        void Clear_Click(object sender, RoutedEventArgs e)
        {
            if (Host.Confirm("Apagar todo o histórico do TH Suite?")) Activity.Clear();
        }

        void Export_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new SaveFileDialog { Title = "Exportar histórico", FileName = $"historico-thsuite-{DateTime.Now:yyyy-MM-dd}.txt", Filter = "Texto (*.txt)|*.txt" };
            if (dlg.ShowDialog(Host.Owner) != true) return;
            var sb = new StringBuilder();
            foreach (var a in Activity.Items) sb.AppendLine($"{a.TimeText}\t{a.Module}\t{a.Text}");
            File.WriteAllText(dlg.FileName, sb.ToString(), Encoding.UTF8);
        }
    }
}

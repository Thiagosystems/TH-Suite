@echo off
chcp 65001 >nul
cd /d "%~dp0"
title Compilando THSuite

rem --- Verifica se o .NET SDK esta instalado ---
where dotnet >nul 2>nul
if errorlevel 1 goto nosdk
dotnet --list-sdks 2>nul | findstr /r "^[0-9]" >nul
if errorlevel 1 goto nosdk

echo Compilando THSuite (exe unico, ja inclui o .NET)...
echo.
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:DebugType=None -o publish
if errorlevel 1 goto erro

rem --- Instalador (opcional): precisa do Inno Setup 6 ---
set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if exist "%ISCC%" (
  echo.
  echo Gerando o instalador...
  "%ISCC%" /Q installer.iss
  if not errorlevel 1 echo Instalador: publish\THSuite-Setup.exe
) else (
  echo.
  echo  [Opcional] Para gerar tambem o instalador THSuite-Setup.exe,
  echo  instale o Inno Setup 6: https://jrsoftware.org/isdl.php
)

echo.
echo ============================================================
echo  Pronto: publish\THSuite.exe
echo  Esse arquivo funciona em qualquer Windows 10/11 64 bits,
echo  sem precisar instalar nada. Mande so ele para quem for usar.
echo ============================================================
explorer "%~dp0publish"
pause
exit /b 0

:nosdk
echo ============================================================
echo  O .NET SDK nao esta instalado neste PC.
echo.
echo  Este arquivo serve para COMPILAR o programa.
echo  Para so USAR o app, peca o THSuite.exe pronto
echo  (aba Releases do GitHub) - nao precisa deste .bat.
echo.
echo  Para compilar, instale o .NET 8 SDK (x64):
echo  https://dotnet.microsoft.com/download/dotnet/8.0
echo ============================================================
start "" "https://dotnet.microsoft.com/download/dotnet/8.0"
pause
exit /b 1

:erro
echo.
echo ============================================================
echo  ERRO na compilacao. Veja as mensagens em vermelho acima
echo  e mande um print delas.
echo ============================================================
pause
exit /b 1

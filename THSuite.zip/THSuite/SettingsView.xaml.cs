using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using WF = System.Windows.Forms;

namespace THSuite
{
    public partial class SettingsView : UserControl
    {
        readonly MainWindow _main;
        readonly SuiteSettings _s;
        bool _loading = true;

        public SettingsView(MainWindow main)
        {
            InitializeComponent();
            _main = main;
            _s = SuiteSettings.Current;
            TxtAbout.Text = $"Versão {MainWindow.Version} · Otimização completa para Windows 10 e 11.";
            BuildSwatches();
            LoadUi();
            Hook();
            _loading = false;
        }

        void LoadUi()
        {
            bool was = _loading;
            _loading = true;
            RbDark.IsChecked = _s.Theme == "dark";
            RbBlack.IsChecked = _s.Theme == "black";
            RbLight.IsChecked = _s.Theme == "light";
            TxtColorA.Text = _s.AccentA;
            TxtColorB.Text = _s.AccentB;
            ChkLogoAccent.IsChecked = _s.LogoUseAccent;
            TxtLogoP.Text = _s.LogoPrimary;
            TxtLogoS.Text = _s.LogoSecondary;
            ChkStartup.IsChecked = _s.StartWithWindows;
            ChkStartMin.IsChecked = _s.StartMinimized;
            ChkTray.IsChecked = _s.CloseToTray;
            ChkRestore.IsChecked = _s.RestorePointBeforeTweaks;
            ChkConfirm.IsChecked = _s.ConfirmTweaks;
            RbPt.IsChecked = _s.Language == "pt";
            RbEn.IsChecked = _s.Language == "en";
            RbEs.IsChecked = _s.Language == "es";
            foreach (var rb in new[] { RbClean0, RbClean1, RbClean7, RbClean30 }) rb.IsChecked = (string)rb.Tag == _s.AutoCleanDays.ToString();
            foreach (var rb in new[] { RbScan0, RbScan1, RbScan7, RbScan30 }) rb.IsChecked = (string)rb.Tag == _s.AutoScanDays.ToString();
            ChkAutoRam.IsChecked = _s.AutoCleanRam;
            ChkUpdates.IsChecked = _s.CheckUpdates;
            UpdateAutoInfo();
            UpdateLabels();
            RefreshColorUi();
            _loading = was;
        }

        void Hook()
        {
            foreach (var rb in new[] { RbPt, RbEn, RbEs }) rb.Checked += Lang_Checked;
            foreach (var rb in new[] { RbClean0, RbClean1, RbClean7, RbClean30, RbScan0, RbScan1, RbScan7, RbScan30 }) rb.Checked += Auto_Checked;
            foreach (var cb in new[] { ChkStartMin, ChkTray, ChkRestore, ChkConfirm, ChkAutoRam, ChkUpdates })
            {
                cb.Checked += SettingChanged;
                cb.Unchecked += SettingChanged;
            }
            ChkStartup.Checked += async (_, _) => await StartupChanged(true);
            ChkStartup.Unchecked += async (_, _) => await StartupChanged(false);

            foreach (var rb in new[] { RbDark, RbBlack, RbLight }) rb.Checked += Theme_Checked;
            ChkLogoAccent.Checked += (_, _) => CommitColors();
            ChkLogoAccent.Unchecked += (_, _) => CommitColors();
            foreach (var tb in new[] { TxtColorA, TxtColorB, TxtLogoP, TxtLogoS })
            {
                tb.LostFocus += (_, _) => CommitColors();
                tb.KeyDown += (_, e) => { if (e.Key == Key.Enter) CommitColors(); };
            }
            PrevA.MouseLeftButtonUp += (_, _) => PickColor(TxtColorA);
            PrevB.MouseLeftButtonUp += (_, _) => PickColor(TxtColorB);
            PrevLogoP.MouseLeftButtonUp += (_, _) => PickColor(TxtLogoP);
            PrevLogoS.MouseLeftButtonUp += (_, _) => PickColor(TxtLogoS);
        }

        void SettingChanged(object? sender, RoutedEventArgs? e)
        {
            if (_loading) return;
            _s.StartMinimized = ChkStartMin.IsChecked == true;
            _s.CloseToTray = ChkTray.IsChecked == true;
            _s.RestorePointBeforeTweaks = ChkRestore.IsChecked == true;
            _s.ConfirmTweaks = ChkConfirm.IsChecked == true;
            _s.AutoCleanRam = ChkAutoRam.IsChecked == true;
            _s.CheckUpdates = ChkUpdates.IsChecked == true;
            _s.Save();
        }

        async Task StartupChanged(bool on)
        {
            if (_loading) return;
            _s.StartWithWindows = on;
            _s.Save();
            await StartupManager.SetAsync(on);
        }

        void UpdateLabels()
        {
            TxtLogoP.IsEnabled = PrevLogoP.IsEnabled = ChkLogoAccent.IsChecked != true;
            TxtLogoP.Opacity = PrevLogoP.Opacity = ChkLogoAccent.IsChecked == true ? 0.4 : 1;
        }

        // =====================================================================
        //  Cores
        // =====================================================================

        void Theme_Checked(object sender, RoutedEventArgs e)
        {
            if (_loading) return;
            _s.Theme = sender == RbLight ? "light" : sender == RbBlack ? "black" : "dark";
            _s.Save();
            ApplyTheme();
        }

        void ApplyTheme()
        {
            ThemeManager.Apply(_s);
            RefreshColorUi();
            _main.MemoryPage.OnThemeChanged();
        }

        void BuildSwatches()
        {
            foreach (var p in ThemeManager.Presets)
            {
                var b = new Border
                {
                    Width = 28, Height = 28,
                    CornerRadius = new CornerRadius(14),
                    Margin = new Thickness(0, 0, 8, 8),
                    BorderThickness = new Thickness(2),
                    Cursor = Cursors.Hand,
                    ToolTip = p.Name,
                    Tag = p,
                    Background = new LinearGradientBrush(ThemeManager.Parse(p.A, p.A), ThemeManager.Parse(p.B, p.B), new Point(0, 0), new Point(1, 1))
                };
                b.MouseLeftButtonUp += (_, _) =>
                {
                    TxtColorA.Text = p.A;
                    TxtColorB.Text = p.B;
                    CommitColors();
                };
                Swatches.Children.Add(b);
            }
        }

        void CommitColors()
        {
            UpdateLabels();
            if (_loading) return;
            _s.AccentA = Valid(TxtColorA, _s.AccentA);
            _s.AccentB = Valid(TxtColorB, _s.AccentB);
            _s.LogoPrimary = Valid(TxtLogoP, _s.LogoPrimary);
            _s.LogoSecondary = Valid(TxtLogoS, _s.LogoSecondary);
            _s.LogoUseAccent = ChkLogoAccent.IsChecked == true;
            _s.Save();
            ApplyTheme();
        }

        static string Valid(TextBox tb, string fallback)
        {
            string v = ThemeManager.TryParse(tb.Text, out var n) ? n : fallback;
            tb.Text = v;
            return v;
        }

        void PickColor(TextBox target)
        {
            var c = ThemeManager.Parse(target.Text, "#FFFFFF");
            using var dlg = new WF.ColorDialog { FullOpen = true, Color = System.Drawing.Color.FromArgb(c.R, c.G, c.B) };
            if (dlg.ShowDialog() != WF.DialogResult.OK) return;
            target.Text = $"#{dlg.Color.R:X2}{dlg.Color.G:X2}{dlg.Color.B:X2}";
            CommitColors();
        }

        void RefreshColorUi()
        {
            var ring = (Brush)FindResource("TextBrush");
            foreach (Border b in Swatches.Children)
            {
                var p = ((string Name, string A, string B))b.Tag;
                bool sel = string.Equals(p.A, _s.AccentA, StringComparison.OrdinalIgnoreCase)
                        && string.Equals(p.B, _s.AccentB, StringComparison.OrdinalIgnoreCase);
                b.BorderBrush = sel ? ring : Brushes.Transparent;
            }
            PrevA.Background = Solid(_s.AccentA);
            PrevB.Background = Solid(_s.AccentB);
            PrevLogoP.Background = Solid(_s.LogoPrimary);
            PrevLogoS.Background = Solid(_s.LogoSecondary);
        }

        static SolidColorBrush Solid(string hex) => new(ThemeManager.Parse(hex, "#FFFFFF"));

        void ResetLook_Click(object sender, RoutedEventArgs e)
        {
            var d = new SuiteSettings();
            _s.Theme = d.Theme; _s.AccentA = d.AccentA; _s.AccentB = d.AccentB;
            _s.LogoUseAccent = d.LogoUseAccent; _s.LogoPrimary = d.LogoPrimary; _s.LogoSecondary = d.LogoSecondary;
            _s.Save();
            LoadUi();
            ApplyTheme();
        }

        // =====================================================================
        //  Outros
        // =====================================================================

        void OpenData_Click(object sender, RoutedEventArgs e)
        {
            Directory.CreateDirectory(SuiteSettings.DataDir);
            Cmd.Open(SuiteSettings.DataDir);
        }

        void OpenLog_Click(object sender, RoutedEventArgs e)
        {
            string log = Path.Combine(SuiteSettings.DataDir, "erros.log");
            if (File.Exists(log)) Cmd.Open("notepad.exe", $"\"{log}\"");
            else Host.Info("Nenhum erro registrado até agora.");
        }

        // =====================================================================
        //  Idioma, tarefas automáticas e atualizações
        // =====================================================================

        void Lang_Checked(object sender, RoutedEventArgs e)
        {
            if (_loading) return;
            _s.Language = sender == RbEn ? "en" : sender == RbEs ? "es" : "pt";
            _s.Save();
            string msg = _s.Language switch
            {
                "en" => "The language will change after restarting TH Suite. Restart now?",
                "es" => "El idioma cambiará después de reiniciar TH Suite. ¿Reiniciar ahora?",
                _ => "O idioma muda depois de reiniciar o TH Suite. Reiniciar agora?"
            };
            if (Host.Confirm(msg)) Host.Restart();
        }

        void Auto_Checked(object sender, RoutedEventArgs e)
        {
            if (_loading || sender is not RadioButton rb || !int.TryParse((string)rb.Tag, out int days)) return;
            if (rb.GroupName == "autoClean") _s.AutoCleanDays = days; else _s.AutoScanDays = days;
            _s.Save();
            UpdateAutoInfo();
        }

        void UpdateAutoInfo()
        {
            string Last(DateTime d) => d == default ? "nunca" : d.ToString("dd/MM/yyyy HH:mm");
            TxtAutoInfo.Text = $"Roda em segundo plano enquanto o TH Suite estiver aberto (ou na bandeja). Última limpeza: {Last(_s.LastAutoClean)} · última verificação: {Last(_s.LastAutoScan)}.";
        }

        Updater.Release? _release;

        public async void CheckUpdate_Click(object sender, RoutedEventArgs e) => await CheckUpdateAsync(false);

        public async Task CheckUpdateAsync(bool silent)
        {
            BtnCheckUpd.IsEnabled = false;
            if (!silent) TxtUpdate.Text = "Procurando...";
            _release = await Updater.CheckAsync();
            BtnCheckUpd.IsEnabled = true;
            if (_release == null)
            {
                if (!silent) TxtUpdate.Text = $"Você já tem a versão mais recente ({MainWindow.Version}).";
                BtnInstallUpd.Visibility = Visibility.Collapsed;
                return;
            }
            TxtUpdate.Text = $"Versão {_release.Version} disponível (você tem a {MainWindow.Version})." +
                             (_release.Notes.Length > 0 ? "\n" + (_release.Notes.Length > 400 ? _release.Notes[..400] + "..." : _release.Notes) : "");
            BtnInstallUpd.Visibility = Visibility.Visible;
            if (silent) Host.Notify($"TH Suite {_release.Version} disponível. Clique para atualizar.", () => { Host.ShowWindow(); Host.Navigate("settings", null); });
        }

        async void InstallUpdate_Click(object sender, RoutedEventArgs e)
        {
            if (_release == null) return;
            if (!Host.Confirm($"Baixar e instalar o TH Suite {_release.Version}? O app vai reiniciar sozinho.")) return;
            BtnInstallUpd.IsEnabled = false;
            PrgUpdate.Visibility = Visibility.Visible;
            var err = await Updater.InstallAsync(_release, new Progress<double>(p => PrgUpdate.Value = p));
            if (err != null)
            {
                TxtUpdate.Text = "Não foi possível atualizar: " + err;
                PrgUpdate.Visibility = Visibility.Collapsed;
                BtnInstallUpd.IsEnabled = true;
            }
        }

        void GitHub_Click(object sender, RoutedEventArgs e) => Cmd.Open("https://github.com/Thiagosystems");
        void Exit_Click(object sender, RoutedEventArgs e) => Host.Exit();
    }
}
